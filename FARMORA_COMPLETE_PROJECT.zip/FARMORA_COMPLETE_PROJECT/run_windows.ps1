# FARMORA - PowerShell Execution Script
$Host.UI.RawUI.WindowTitle = "FARMORA - Blockchain Organic Platform"

Write-Host "=====================================================================" -ForegroundColor Green
Write-Host "   FARMORA - Blockchain-Based Organic Farm-to-Consumer Platform" -ForegroundColor Green
Write-Host "=====================================================================" -ForegroundColor Green
Write-Host ""

# 1. Check Python
$pythonCmd = if (Get-Command python -ErrorAction SilentlyContinue) { "python" } elseif (Get-Command py -ErrorAction SilentlyContinue) { "py" } else { $null }
if (-not $pythonCmd) {
    Write-Host "[ERROR] Python is not installed or not in your system PATH." -ForegroundColor Red
    Write-Host "Please install Python 3.10+ from https://www.python.org/"
    pause
    exit 1
}

Write-Host "[1/5] Checking Python environment: $pythonCmd" -ForegroundColor Cyan
& $pythonCmd --version

# 2. Virtual Environment
if (-not (Test-Path ".venv")) {
    Write-Host "[2/5] Creating Python virtual environment (.venv)..." -ForegroundColor Cyan
    & $pythonCmd -m venv .venv
} else {
    Write-Host "[2/5] Virtual environment found (.venv)." -ForegroundColor Cyan
}

# 3. Activate
Write-Host "[3/5] Activating virtual environment..." -ForegroundColor Cyan
$activateScript = ".\.venv\Scripts\Activate.ps1"
if (Test-Path $activateScript) {
    & $activateScript
}

# 4. Install Dependencies
Write-Host "[4/5] Checking and installing dependencies..." -ForegroundColor Cyan
python -m pip install --upgrade pip --quiet
python -m pip install -r requirements.txt --quiet

# 5. Initialize Database
Write-Host "[5/5] Checking database initialization..." -ForegroundColor Cyan
if (-not (Test-Path "data\farmora.db")) {
    Write-Host "Seeding initial dataset into database..." -ForegroundColor Yellow
    python -m farmora.cli seed
} else {
    Write-Host "Database file data\farmora.db found. Preserving existing records." -ForegroundColor Green
}

Write-Host ""
Write-Host "=====================================================================" -ForegroundColor Green
Write-Host "   FARMORA Platform is Ready!" -ForegroundColor Green
Write-Host "   Local Application URL : http://localhost:8501" -ForegroundColor Yellow
Write-Host ""
Write-Host "   DEMO ACCOUNTS:" -ForegroundColor Cyan
Write-Host "   - Admin:    admin / admin123"
Write-Host "   - Manager:  manager1 / manager123"
Write-Host "   - Farmer:   farmer1 / farmer123"
Write-Host "   - Customer: customer1 / customer123"
Write-Host "=====================================================================" -ForegroundColor Green
Write-Host ""

streamlit run app\streamlit_app.py
