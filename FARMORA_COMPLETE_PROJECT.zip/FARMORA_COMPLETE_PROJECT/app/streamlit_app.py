"""FARMORA - Streamlit application.   Run from the project root:  streamlit run app/streamlit_app.py"""
import sys
import warnings
from datetime import date, datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
warnings.filterwarnings("ignore")

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from farmora import analytics as an
from farmora import repository as repo
from farmora.cli import build_service
from farmora.config import Settings
from farmora.ledger import LedgerError
from farmora.rules import EVENT_NAMES, EVENT_ROLE, EVENT_TYPES
from farmora.services import TraceError

st.set_page_config(page_title="FARMORA", page_icon="🌿", layout="wide")


# ============================================================================ setup
@st.cache_resource(show_spinner="Connecting to database and ledger ...")
def get_service():
    return build_service(Settings.from_env())


try:
    svc = get_service()
except LedgerError as exc:
    st.error(f"Ledger connection problem: {exc}")
    st.stop()
except Exception as exc:  # database connection etc.
    st.error(f"Could not start FARMORA: {exc}")
    st.info("Check the .env file (DB_BACKEND, DB_HOST, DB_USER, DB_PASSWORD) and that MySQL / the Hardhat node are running.")
    st.stop()

db = svc.db

from farmora.auth import gate, allowed_pages, logout_button
from farmora.portals import page_my_orders, page_orders, page_manage_items, page_farmer, page_users, page_my_profile
from farmora.storefront import render_store

user = gate(svc)


@st.cache_data(ttl=300, show_spinner=False)
def load_all(_db, version: int):
    sales, _ = an.clean_sales(repo.sales(_db))
    return {"sales": sales, "products": repo.products(_db), "orders": repo.orders(_db), "inventory": repo.inventory(_db),
            "batches": repo.batches(_db), "events": repo.events(_db), "certs": repo.certifications(_db),
            "actors": repo.actors(_db)}


if "data_version" not in st.session_state:
    st.session_state["data_version"] = 0


def data():
    return load_all(db, st.session_state["data_version"])


def refresh():
    st.session_state["data_version"] += 1


@st.cache_data(ttl=600, show_spinner="Training forecasting models ...")
def run_forecast(pid: str, horizon: int, _sales, version: int):
    series = an.daily_series(_sales, None if pid == "ALL" else pid)
    return an.forecast_series(series, horizon=horizon)


def has_data() -> bool:
    return bool(db.scalar("SELECT COUNT(*) FROM actors"))


def etherscan(tx):
    base = Settings.from_env().explorer_tx_url
    return f"{base}{tx}" if base and tx else None


STATUS_ICON = {"VERIFIED": "✅", "TAMPERED": "❌", "MISSING_IN_DB": "⚠️", "NOT_ON_CHAIN": "⚠️"}


# ============================================================================ pages
def page_overview():
    st.title("🌿 FARMORA")
    st.caption("Blockchain-based organic food traceability with data science analytics")
    info = svc.ledger.info()
    if not info.get("real_blockchain"):
        st.warning("Running on the SIMULATED development ledger (LEDGER_BACKEND=local). "
                   "Switch to LEDGER_BACKEND=web3 for the real blockchain.")
    if not has_data():
        st.info("The database is empty. Run `python -m farmora.cli seed` to generate demo data, or register actors on the Record page.")
        return
    d = data()
    b, e, a, c = d["batches"], d["events"], d["actors"], d["certs"]
    gas = pd.to_numeric(e["gas_used"], errors="coerce").dropna()
    total_orders = db.scalar("SELECT COUNT(*) FROM store_orders") or 0
    k = st.columns(6)
    k[0].metric("Batches Traced", len(b))
    k[1].metric("Ledger Events", int(info.get("total_events", len(e))))
    k[2].metric("Organic Farmers", int((a["role"] == "farmer").sum()))
    certified = e[e["event_type"] == "CERTIFIED"]["batch_id"].nunique()
    k[3].metric("Batches Certified", f"{certified / max(len(b), 1) * 100:.0f}%")
    k[4].metric("Customer Orders", total_orders)
    k[5].metric("Avg Gas / Event", f"{gas.mean():,.0f}" if len(gas) else "n/a (simulated)")

    left, right = st.columns(2)
    with left:
        st.subheader("Supply-chain progress")
        last = e.sort_values("seq").groupby("batch_id").tail(1)["event_type"].value_counts()
        order = [n for n in EVENT_TYPES if n in last.index]
        fig = px.bar(x=order, y=[int(last[n]) for n in order], labels={"x": "Latest stage", "y": "Batches"})
        st.plotly_chart(fig)
    with right:
        st.subheader("Monthly revenue (all stores)")
        s = d["sales"].copy()
        s["month"] = s["sale_date"].dt.to_period("M").dt.to_timestamp()
        m = s.groupby("month")["revenue"].sum().reset_index()
        st.plotly_chart(px.line(m, x="month", y="revenue", markers=True, labels={"revenue": "Revenue (INR)", "month": ""}))

    st.subheader("Ledger integrity")
    st.caption("Recomputes every record's fingerprint from the database and compares it with the ledger.")
    if st.button("Run full verification"):
        bar = st.progress(0.0)
        df = svc.verify_all(progress=lambda i, n: bar.progress(i / n))
        st.session_state["audit"] = df
    audit = st.session_state.get("audit")
    if audit is not None:
        bad = audit[audit["status"] != "VERIFIED"]
        (st.success if bad.empty else st.error)(f"{len(audit) - len(bad)} of {len(audit)} batches verified" +
                                                  ("" if bad.empty else f" - {len(bad)} with problems"))
        if not bad.empty:
            st.dataframe(bad, hide_index=True)
    with st.expander("Ledger details"):
        st.json(info)


def page_record():
    st.title("Record supply-chain data")
    if not has_data():
        st.info("Add actors and products first (Admin tab), or run the seed command.")
    tab1, tab2, tab3 = st.tabs(["New batch (farmer)", "Add event", "Admin: actors & certificates"])
    farmers, products = svc.list_actors("farmer"), svc.list_products()

    with tab1:
        if farmers.empty or products.empty:
            st.info("Register at least one farmer and one product.")
        else:
            with st.form("new_batch"):
                fid = st.selectbox("Farmer", farmers["actor_id"], format_func=lambda x: f"{x} - {farmers.set_index('actor_id').loc[x, 'name']}")
                pid = st.selectbox("Product", products["product_id"], format_func=lambda x: f"{products.set_index('product_id').loc[x, 'name']}")
                qty = st.number_input("Planned quantity (kg)", min_value=1.0, value=500.0, step=10.0)
                loc = st.text_input("Farm location (optional)")
                go_btn = st.form_submit_button("Register batch on ledger")
            if go_btn:
                try:
                    batch = svc.register_batch(fid, pid, qty, loc or None)
                    refresh()
                    st.success(f"Batch {batch['batch_id']} registered. Transaction: {batch['tx_hash']}")
                    st.image(svc.qr_png(batch["batch_id"]), caption="Consumer QR code", width=200)
                except (TraceError, ImportError) as exc:
                    st.error(str(exc))

    with tab2:
        batches = svc.list_batches()
        if batches.empty:
            st.info("No batches yet.")
        else:
            bid = st.selectbox("Batch", batches["batch_id"], format_func=lambda x: f"{x}  ({batches.set_index('batch_id').loc[x, 'product']})")
            try:
                state = svc.batch_state(bid)
            except TraceError as exc:
                st.error(str(exc))
                state = None
            if state:
                st.caption(f"Certified: {state['certified']}  |  Revoked: {state['revoked']}  |  Events on ledger: {state['event_count']}")
                if not state["next_events"]:
                    st.warning("No further events can be recorded for this batch.")
                else:
                    et_name = st.selectbox("Event type", state["next_events"])
                    role = EVENT_ROLE[EVENT_TYPES[et_name]]
                    batch = svc.get_batch(bid)
                    actors = svc.list_actors(role)
                    if role == "farmer":
                        actors = actors[actors["actor_id"] == batch["farmer_id"]]
                    with st.form("add_event"):
                        actor = st.selectbox(f"Recorded by ({role})", actors["actor_id"], format_func=lambda x: f"{x} - {actors.set_index('actor_id').loc[x, 'name']}")
                        qty = st.number_input("Quantity (kg)", min_value=0.0, value=float(batch["quantity_kg"]), step=10.0)
                        ref = ""
                        if et_name == "CERTIFIED":
                            certs = db.df("SELECT cert_id, valid_until FROM certifications WHERE farmer_id = ?", (batch["farmer_id"],))
                            ref = st.selectbox("Certificate", certs["cert_id"]) if not certs.empty else st.text_input("Certificate id")
                        elif et_name == "SHIPPED":
                            ref = st.text_input("Vehicle / consignment no.")
                        loc = st.text_input("Location (optional)")
                        notes = st.text_area("Notes", height=70)
                        ok = st.form_submit_button("Record on ledger")
                    if ok:
                        try:
                            ev = svc.add_event(bid, et_name, actor, qty, loc or None, notes, ref)
                            refresh()
                            st.success(f"{et_name} recorded. Transaction {ev['tx_hash']}")
                        except TraceError as exc:
                            st.error(str(exc))

    with tab3:
        c1, c2 = st.columns(2)
        with c1:
            st.subheader("Register actor")
            with st.form("actor"):
                aid = st.text_input("Actor id (e.g. FM13)")
                name = st.text_input("Name")
                role = st.selectbox("Role", ["farmer", "processor", "distributor", "retailer", "certifier"])
                loc = st.text_input("Location")
                if st.form_submit_button("Add actor"):
                    try:
                        svc.add_actor(aid.strip(), name.strip(), role, name.strip(), loc.strip())
                        refresh(); st.success("Actor added")
                    except TraceError as exc:
                        st.error(str(exc))
        with c2:
            st.subheader("Issue certificate")
            if farmers.empty:
                st.info("No farmers yet.")
            else:
                with st.form("cert"):
                    fid = st.selectbox("Farmer", farmers["actor_id"], key="cf")
                    std = st.text_input("Standard", value="NPOP (organic)")
                    issued = st.date_input("Issued on", value=date.today())
                    valid = st.date_input("Valid until", value=date(date.today().year + 3, date.today().month, min(date.today().day, 28)))
                    if st.form_submit_button("Issue certificate"):
                        try:
                            cert = svc.issue_certification(fid, std, str(issued), str(valid))
                            refresh(); st.success(f"Issued {cert['cert_id']}")
                        except TraceError as exc:
                            st.error(str(exc))


def page_verify():
    st.title("Verify a product")
    st.caption("Scan the QR code on a pack, or enter the batch id, to see its journey and check it against the blockchain.")
    default = st.query_params.get("batch", "")
    bid = st.text_input("Batch id", value=default).strip()
    if not bid:
        batches = svc.list_batches()
        if not batches.empty:
            st.caption("Example batch ids: " + ", ".join(batches["batch_id"].head(3)))
        return
    batch = svc.get_batch(bid)
    if not batch:
        st.error("No such batch.")
        return
    report = svc.verify_batch(bid)
    if report["ok"]:
        st.success("✅ VERIFIED - every record matches the immutable ledger.")
    else:
        st.error("❌ WARNING - this batch's records do not match the ledger. Do not trust this history.")
        for issue in report["issues"]:
            st.write("•", issue)
    c1, c2 = st.columns([3, 1])
    with c1:
        st.subheader(batch["product_name"])
        st.write(f"**Farmer:** {batch['farmer_name']} - {batch['farm_location']}")
        st.write(f"**Batch quantity:** {float(batch['quantity_kg']):,.0f} kg   |   **Registered:** {batch['created_at']}")
    with c2:
        try:
            st.image(svc.qr_png(bid), caption="Share this batch", width=150)
        except ImportError:
            st.caption("Install qrcode[pil] for QR codes")
    st.subheader("Journey")
    status = {e["seq"]: e["status"] for e in report["events"]}
    events = svc.get_events(bid)
    for ev in events:
        icon = STATUS_ICON.get(status.get(int(ev["seq"])), "❔")
        with st.container(border=True):
            top = st.columns([2, 2, 1])
            top[0].markdown(f"**{icon} {ev['event_type'].title()}**")
            top[1].write(f"{ev['actor_name']} ({ev['actor_role']})")
            top[2].write(f"{float(ev['quantity_kg'] or 0):,.0f} kg")
            st.caption(f"{ev['event_time']}  |  {ev['location'] or ''}  |  {ev['notes'] or ''}"
                       + (f"  |  Ref: {ev['reference']}" if ev["reference"] else ""))
            link = etherscan(ev["tx_hash"])
            st.caption(f"Tx: {ev['tx_hash']}" + (f"  [view]({link})" if link else ""))
    if not events:
        st.info("No events recorded yet for this batch.")


def page_forecast():
    st.title("Demand forecasting")
    if not has_data():
        st.info("No data yet."); return
    d = data()
    prod = d["products"]
    options = ["ALL"] + prod["product_id"].tolist()
    c1, c2 = st.columns(2)
    pid = c1.selectbox("Product", options, format_func=lambda x: "All products" if x == "ALL" else prod.set_index("product_id").loc[x, "name"])
    horizon = c2.slider("Forecast horizon (days)", 7, 90, 28)
    res = run_forecast(pid, horizon, d["sales"], st.session_state["data_version"])
    hist = an.daily_series(d["sales"], None if pid == "ALL" else pid).iloc[-120:]
    fc = res["forecast"]
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=hist.index, y=hist.values, name="Actual demand", line=dict(color="#555")))
    fig.add_trace(go.Scatter(x=fc["date"], y=fc["upper"], line=dict(width=0), showlegend=False, hoverinfo="skip"))
    fig.add_trace(go.Scatter(x=fc["date"], y=fc["lower"], fill="tonexty", line=dict(width=0), name="95% interval", fillcolor="rgba(15,110,86,0.2)"))
    fig.add_trace(go.Scatter(x=fc["date"], y=fc["forecast"], name=f"Forecast ({res['best_model']})", line=dict(color="#0F6E56")))
    fig.update_layout(yaxis_title="kg per day", height=420, legend=dict(orientation="h"))
    st.plotly_chart(fig)
    m = st.columns(3)
    best = res["metrics"].iloc[0]
    m[0].metric("Best model", res["best_model"])
    m[1].metric("Backtest MAPE", f"{best['MAPE %']:.1f}%")
    m[2].metric("RMSE vs naive baseline", f"{res['improvement_vs_naive_pct']:.0f}% better")
    st.subheader("Model comparison (last 28 days held out)")
    st.dataframe(res["metrics"].round(2), hide_index=True)
    st.subheader("Forecast table")
    st.dataframe(fc.round(1), hide_index=True)
    st.download_button("Download forecast CSV", fc.to_csv(index=False), "forecast.csv", "text/csv")


def page_customers():
    st.title("Sales and customer insights")
    if not has_data():
        st.info("No data yet."); return
    d = data()
    sales, prod = d["sales"].merge(d["products"], on="product_id"), d["products"]
    st.subheader("Demand trends (last 90 days vs the 90 days before)")
    tr = an.demand_trends(d["sales"], prod)
    st.dataframe(tr[["name", "category", "last_90d_kg", "prev_90d_kg", "growth_pct", "peak_month", "trend"]].round(1), hide_index=True)
    c1, c2 = st.columns(2)
    with c1:
        st.subheader("Revenue by category")
        s = sales.copy(); s["month"] = s["sale_date"].dt.to_period("M").dt.to_timestamp()
        st.plotly_chart(px.area(s.groupby(["month", "category"])["revenue"].sum().reset_index(), x="month", y="revenue", color="category"))
    with c2:
        st.subheader("Seasonality (1.0 = typical month)")
        si = an.seasonality_index(d["sales"]).rename(index=prod.set_index("product_id")["name"].to_dict())
        st.plotly_chart(px.imshow(si, aspect="auto", color_continuous_scale="Greens", labels=dict(x="Month", y="", color="Index")))
    st.subheader("Weekday pattern")
    wd = sales.assign(day=sales["sale_date"].dt.day_name()).groupby("day")["qty_kg"].mean().reindex(
        ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"])
    st.plotly_chart(px.bar(x=wd.index, y=wd.values, labels={"x": "", "y": "Average kg per store-product-day"}))
    st.subheader("Customer segments (RFM + K-Means)")
    if d["orders"].empty:
        st.info("No customer orders available."); return
    cust, summary = an.rfm_segments(d["orders"])
    st.dataframe(summary.round(1), hide_index=True)
    st.plotly_chart(px.scatter(cust, x="recency_days", y="frequency", size="monetary", color="segment",
                               hover_data=["customer_id", "monetary"], labels={"recency_days": "Days since last order", "frequency": "Order days"}))


def page_inventory():
    st.title("Inventory and compliance")
    if not has_data():
        st.info("No data yet."); return
    d = data()
    st.subheader("Stock cover (forecast-based)")
    fcs = {}
    for pid in d["products"]["product_id"]:
        fcs[pid] = run_forecast(pid, 28, d["sales"], st.session_state["data_version"])["forecast"]
    cover = an.inventory_cover(d["inventory"], d["sales"], fcs)
    names = d["products"].set_index("product_id")["name"]
    cover["product"] = cover["product_id"].map(names)
    counts = cover["status"].value_counts()
    k = st.columns(4)
    for col, s in zip(k, ["Critical", "Low", "OK", "Overstock"]):
        col.metric(s, int(counts.get(s, 0)))
    pick = st.multiselect("Show status", ["Critical", "Low", "OK", "Overstock"], default=["Critical", "Low"])
    st.dataframe(cover[cover["status"].isin(pick)].sort_values("days_of_cover")[
        ["retailer_id", "product", "stock_kg", "forecast_daily_kg", "days_of_cover", "status"]].round(1), hide_index=True)
    st.subheader("Organic certification compliance")
    certs = d["certs"].merge(d["actors"][["actor_id", "name"]], left_on="farmer_id", right_on="actor_id")
    today = pd.Timestamp(date.today())
    certs["valid_until_dt"] = pd.to_datetime(certs["valid_until"])
    certs["days_left"] = (certs["valid_until_dt"] - today).dt.days
    certs["state"] = pd.cut(certs["days_left"], [-10**6, -1, 45, 10**6], labels=["Expired", "Expiring soon", "Valid"])
    active = d["batches"].groupby("farmer_id").size().rename("batches")
    certs = certs.merge(active, left_on="farmer_id", right_index=True, how="left").fillna({"batches": 0})
    st.dataframe(certs.sort_values("days_left")[["farmer_id", "name", "cert_id", "standard", "valid_until", "days_left", "state", "batches"]], hide_index=True)
    risk = certs[(certs["state"] == "Expired") & (certs["batches"] > 0)]
    if len(risk):
        st.error(f"{len(risk)} farmer(s) with an expired certificate still have batches in the system: " + ", ".join(risk["name"]))


def page_anomalies():
    st.title("Anomaly detection")
    if not has_data():
        st.info("No data yet."); return
    d = data()
    st.subheader("Supply-chain batch anomalies")
    st.caption("The ledger proves records were not altered, but it cannot know whether a record is plausible. "
               "These rules and an Isolation Forest flag batches whose numbers or timings look wrong.")
    feats = an.batch_features(d["batches"], d["events"], d["products"], d["certs"])
    res = an.detect_batch_anomalies(feats)
    k = st.columns(3)
    k[0].metric("Batches analysed", len(feats))
    k[1].metric("Flagged", len(res))
    k[2].metric("High severity", int((res["severity"] == "High").sum()) if len(res) else 0)
    st.dataframe(res, hide_index=True)
    if len(res):
        pick = st.selectbox("Inspect flagged batch", res["batch_id"])
        st.write(res.set_index("batch_id").loc[pick, "reasons"])
        st.dataframe(pd.DataFrame(svc.get_events(pick))[["seq", "event_type", "actor_id", "quantity_kg", "event_time", "notes"]], hide_index=True)
    st.subheader("Sales spikes and drops")
    sa = an.detect_sales_anomalies(d["sales"])
    st.write(f"{len(sa)} unusual store-product-days found.")
    st.dataframe(sa.head(50).round(2), hide_index=True)
    if len(sa):
        r = sa.iloc[0]
        g = d["sales"][(d["sales"]["retailer_id"] == r["retailer_id"]) & (d["sales"]["product_id"] == r["product_id"])]
        fig = px.line(g, x="sale_date", y="qty_kg", title=f"Strongest anomaly: {r['product_id']} at {r['retailer_id']}")
        fig.add_trace(go.Scatter(x=[r["sale_date"]], y=[r["qty_kg"]], mode="markers", marker=dict(size=12, color="red"), name="Anomaly"))
        st.plotly_chart(fig)


def page_audit():
    st.title("Integrity audit and tamper demo")
    st.caption("Shows why blockchain matters: edits made directly in the database are detected because the ledger still holds the original fingerprint.")
    batches = svc.list_batches()
    if batches.empty:
        st.info("No batches."); return
    bid = st.selectbox("Batch", batches["batch_id"])
    events = svc.get_events(bid)
    if not events:
        st.info("This batch has no events yet."); return
    report = svc.verify_batch(bid)
    (st.success if report["ok"] else st.error)("Batch verified" if report["ok"] else "Tampering detected")
    st.dataframe(pd.DataFrame(report["events"]).assign(
        chain_hash=lambda x: x["chain_hash"].astype(str).str[:16] + "...", db_hash=lambda x: x["db_hash"].astype(str).str[:16] + "...",
        tx_hash=lambda x: x["tx_hash"].astype(str).str[:18] + "..."), hide_index=True)

    st.subheader("Attack simulation (demo only)")
    st.warning("These buttons change the database directly, bypassing the ledger, exactly like an insider or hacker would.")
    by_seq = {int(e["seq"]): e for e in events}
    seq = st.selectbox("Event #", list(by_seq), format_func=lambda s: f"#{s} {by_seq[s]['event_type']}")
    cur = by_seq[seq]
    c1, c2, c3 = st.columns(3)
    new_q = c1.number_input("Fake quantity (kg)", value=float(cur["quantity_kg"] or 0) * 2 + 100)
    if c1.button("Change quantity"):
        st.session_state["undo"] = ("field", bid, seq, "quantity_kg", svc.tamper_event(bid, seq, "quantity_kg", new_q))
        st.rerun()
    new_loc = c2.text_input("Fake location", value="Unknown")
    if c2.button("Change location"):
        st.session_state["undo"] = ("field", bid, seq, "location", svc.tamper_event(bid, seq, "location", new_loc))
        st.rerun()
    c3.write("Delete evidence")
    if c3.button("Delete this event row"):
        st.session_state["undo"] = ("row", svc.delete_event_row(bid, seq))
        st.rerun()
    undo = st.session_state.get("undo")
    if undo and st.button("↩ Restore original data"):
        if undo[0] == "field":
            svc.restore_event(*undo[1:])
        else:
            svc.reinsert_event_row(undo[1])
        st.session_state.pop("undo")
        st.rerun()


def page_about():
    st.title("About FARMORA")
    st.markdown("""
**FARMORA** records every step of an organic product's life on a blockchain and analyses the supply chain with data science.

**How integrity works**
1. Each record (batch or event) is converted to canonical JSON and hashed with SHA-256.
2. The hash is written to the `FarmoraTrace` smart contract, which also enforces who may record what and in which order.
3. The full record is stored in MySQL. Verification recomputes the hash from MySQL and compares it with the chain.

**Layers:** Streamlit app - Python services - smart contract (Ethereum/Hardhat) + MySQL - analytics (pandas, scikit-learn, Plotly).

**Data note:** supply-chain, sales and customer data are synthetic, generated for demonstration.
""")
    st.json(svc.ledger.info())


PAGES = {
    "Overview": page_overview,
    "Sales & customers": page_customers,
    "Demand forecast": page_forecast,
    "Store": lambda: render_store(svc, refresh, user),
    "My orders": lambda: page_my_orders(svc, user),
    "Orders": lambda: page_orders(svc, refresh, user),
    "Manage items": lambda: page_manage_items(svc, refresh, user),
    "Inventory management": lambda: page_manage_items(svc, refresh, user),
    "Record data": page_record,
    "Farmer portal": lambda: page_farmer(svc, refresh, user),
    "Inventory & compliance": page_inventory,
    "Verify a product": page_verify,
    "Blockchain traceability": page_verify,
    "Integrity audit": page_audit,
    "Anomalies": page_anomalies,
    "Users & access": lambda: page_users(svc, refresh),
    "My profile": lambda: page_my_profile(svc, user),
    "About": page_about,
}

allowed = allowed_pages(user["role"])
ACTIVE_PAGES = {k: PAGES[k] for k in allowed if k in PAGES}

# If consumer scanned QR code directly, take them straight to verification
if ("batch" in st.query_params or "batch_id" in st.query_params) and "Verify a product" in ACTIVE_PAGES:
    st.session_state["page"] = "Verify a product"

if st.session_state.get("page") not in ACTIVE_PAGES:
    st.session_state["page"] = list(ACTIVE_PAGES.keys())[0]

st.sidebar.title("🌿 FARMORA")
choice = st.sidebar.radio("Navigate", list(ACTIVE_PAGES.keys()), key="page")

info = svc.ledger.info()
st.sidebar.caption(("⛓ Real blockchain: " if info.get("real_blockchain") else "🧪 Simulated ledger: ") + str(info.get("network")))
if st.sidebar.button("🔄 Refresh data", use_container_width=True):
    refresh()
    st.rerun()

logout_button(user)
ACTIVE_PAGES[choice]()
