"""Unit tests for Role-Based Access Control (RBAC) page permissions."""
import unittest
from farmora import auth


class RBACTests(unittest.TestCase):
    def test_admin_has_full_access(self):
        admin_pages = auth.allowed_pages("admin")
        self.assertIn("Overview", admin_pages)
        self.assertIn("Store", admin_pages)
        self.assertIn("Manage items", admin_pages)
        self.assertIn("Orders", admin_pages)
        self.assertIn("Farmer portal", admin_pages)
        self.assertIn("Users & access", admin_pages)
        self.assertIn("Blockchain traceability", admin_pages)
        self.assertIn("Integrity audit", admin_pages)
        self.assertIn("Demand forecast", admin_pages)
        self.assertIn("Sales & customers", admin_pages)

    def test_customer_has_restricted_access(self):
        customer_pages = auth.allowed_pages("customer")
        # Allowed
        self.assertIn("Store", customer_pages)
        self.assertIn("My orders", customer_pages)
        self.assertIn("My profile", customer_pages)
        self.assertIn("Verify a product", customer_pages)

        # Prohibited for customer
        self.assertNotIn("Overview", customer_pages)
        self.assertNotIn("Manage items", customer_pages)
        self.assertNotIn("Orders", customer_pages)
        self.assertNotIn("Farmer portal", customer_pages)
        self.assertNotIn("Users & access", customer_pages)
        self.assertNotIn("Integrity audit", customer_pages)
        self.assertNotIn("Demand forecast", customer_pages)
        self.assertNotIn("Sales & customers", customer_pages)
        self.assertNotIn("Anomalies", customer_pages)

    def test_farmer_has_restricted_access(self):
        farmer_pages = auth.allowed_pages("farmer")
        self.assertIn("Farmer portal", farmer_pages)
        self.assertIn("Verify a product", farmer_pages)
        self.assertIn("My profile", farmer_pages)

        # Prohibited for farmer
        self.assertNotIn("Overview", farmer_pages)
        self.assertNotIn("Manage items", farmer_pages)
        self.assertNotIn("Orders", farmer_pages)
        self.assertNotIn("Users & access", farmer_pages)
        self.assertNotIn("Demand forecast", farmer_pages)

    def test_guest_restricted_to_verification_only(self):
        guest_pages = auth.allowed_pages("guest")
        self.assertEqual(guest_pages, ["Verify a product"])

    def test_unknown_role_defaults_to_guest(self):
        unknown_pages = auth.allowed_pages("hacker")
        self.assertEqual(unknown_pages, ["Verify a product"])


if __name__ == "__main__":
    unittest.main()
