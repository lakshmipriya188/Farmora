"""Unit tests for authentication, PBKDF2 hashing, and RBAC permissions."""
import unittest
import tempfile
from pathlib import Path

from farmora.config import Settings
from farmora.db import Database
from farmora import auth


class AuthTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.settings = Settings(db_backend="sqlite", sqlite_path=str(Path(self.tmp) / "test_auth.db"))
        self.db = Database(self.settings)
        self.db.init_schema()

    def test_create_and_check_login(self):
        uid = auth.create_user(self.db, "alice", "secret123", "customer", full_name="Alice Smith", phone="9988776655")
        self.assertGreater(uid, 0)

        # Successful login
        user = auth.check_login(self.db, "alice", "secret123")
        self.assertIsNotNone(user)
        self.assertEqual(user["username"], "alice")
        self.assertEqual(user["role"], "customer")
        self.assertEqual(user["full_name"], "Alice Smith")

        # Wrong password
        self.assertIsNone(auth.check_login(self.db, "alice", "wrongpass"))

        # Non-existent user
        self.assertIsNone(auth.check_login(self.db, "bob", "secret123"))

    def test_unique_username_constraint(self):
        auth.create_user(self.db, "duplicate_user", "pass123", "customer")
        with self.assertRaises(ValueError):
            auth.create_user(self.db, "duplicate_user", "anotherpass", "farmer")

    def test_validation_constraints(self):
        with self.assertRaises(ValueError):
            auth.create_user(self.db, "ab", "validpass123", "customer")  # username too short
        with self.assertRaises(ValueError):
            auth.create_user(self.db, "validuser", "123", "customer")  # password too short
        with self.assertRaises(ValueError):
            auth.create_user(self.db, "validuser", "validpass123", "invalid_role")  # bad role

    def test_password_reset(self):
        uid = auth.create_user(self.db, "charlie", "oldpass123", "farmer")
        self.assertIsNotNone(auth.check_login(self.db, "charlie", "oldpass123"))

        auth.set_password(self.db, uid, "newpass123")
        self.assertIsNone(auth.check_login(self.db, "charlie", "oldpass123"))
        self.assertIsNotNone(auth.check_login(self.db, "charlie", "newpass123"))

    def test_profile_update(self):
        uid = auth.create_user(self.db, "dave", "pass1234", "customer", full_name="Dave Original")
        auth.update_profile(self.db, uid, "Dave Updated", "9123456789", "New Address, Bengaluru")

        user = auth.check_login(self.db, "dave", "pass1234")
        self.assertEqual(user["full_name"], "Dave Updated")
        self.assertEqual(user["phone"], "9123456789")
        self.assertEqual(user["address"], "New Address, Bengaluru")

    def test_ensure_defaults(self):
        auth.ensure_defaults(self.db)
        admin = auth.check_login(self.db, "admin", "admin123")
        self.assertIsNotNone(admin)
        self.assertEqual(admin["role"], "admin")

        customer = auth.check_login(self.db, "customer1", "customer123")
        self.assertIsNotNone(customer)
        self.assertEqual(customer["role"], "customer")


if __name__ == "__main__":
    unittest.main()
