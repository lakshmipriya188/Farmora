"""End-to-end: synthetic data -> ledger -> verification -> analytics, all on the offline stack."""
import tempfile
import unittest
import warnings
from datetime import date

import pandas as pd

from farmora import analytics as an
from farmora import repository as repo
from farmora.datagen import seed_all
from tests.helpers import make_service


class PipelineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        warnings.simplefilter("ignore")
        cls.svc = make_service()
        cls.labels = tempfile.mkdtemp()
        cls.summary = seed_all(cls.svc, n_batches=40, days=420, seed=7, end=date(2026, 6, 30), label_dir=cls.labels)

    def test_seed_counts(self):
        from farmora.datagen import PRODUCTS
        self.assertEqual(self.summary["batches"], 40)
        self.assertEqual(self.svc.db.scalar("SELECT COUNT(*) FROM batches"), 40)
        self.assertEqual(self.svc.db.scalar("SELECT COUNT(*) FROM sales_daily"), 420 * len(PRODUCTS) * 5)
        info = self.svc.ledger.info()
        self.assertEqual(info["total_batches"], 40)
        self.assertEqual(info["total_events"], self.summary["events"])

    def test_everything_verifies_then_tamper_is_caught(self):
        self.assertTrue((self.svc.verify_all()["status"] == "VERIFIED").all())
        bid = self.svc.db.scalar("SELECT batch_id FROM trace_events WHERE event_type = 'PROCESSED' LIMIT 1")
        old = self.svc.tamper_event(bid, 3, "quantity_kg", 12345)
        res = self.svc.verify_all()
        self.assertEqual(res[res["status"] != "VERIFIED"]["batch_id"].tolist(), [bid])
        self.svc.restore_event(bid, 3, "quantity_kg", old)
        self.assertTrue((self.svc.verify_all()["status"] == "VERIFIED").all())

    def test_injected_batch_anomalies_are_found(self):
        d = {k: getattr(repo, k)(self.svc.db) for k in ("batches", "events", "products", "certifications")}
        flagged = an.detect_batch_anomalies(an.batch_features(d["batches"], d["events"], d["products"], d["certifications"]))
        injected = pd.read_csv(f"{self.labels}/injected_batch_anomalies.csv")
        recall = injected["batch_id"].isin(flagged["batch_id"]).mean()
        self.assertGreaterEqual(recall, 0.8, f"recall {recall}")

    def test_injected_sales_anomalies_are_found(self):
        sales, _ = an.clean_sales(repo.sales(self.svc.db))
        det = an.detect_sales_anomalies(sales)
        inj = pd.read_csv(f"{self.labels}/injected_sales_anomalies.csv", parse_dates=["sale_date"])
        merged = inj.merge(det, on=["sale_date", "retailer_id", "product_id"], how="left", indicator=True)
        self.assertGreaterEqual((merged["_merge"] == "both").mean(), 0.9)
        self.assertLessEqual(len(det), len(inj) + 5)  # very few false alarms

    def test_inventory_cover_and_trends(self):
        sales, _ = an.clean_sales(repo.sales(self.svc.db))
        prods = repo.products(self.svc.db)
        fcs = {p: an.forecast_series(an.daily_series(sales, p), horizon=28)["forecast"] for p in prods["product_id"]}
        cover = an.inventory_cover(repo.inventory(self.svc.db), sales, fcs)
        self.assertEqual(len(cover), len(prods) * 5)
        self.assertTrue({"Critical", "Low", "OK", "Overstock"} >= set(cover["status"]))
        self.assertEqual(len(an.demand_trends(sales, prods)), len(prods))


if __name__ == "__main__":
    unittest.main()
