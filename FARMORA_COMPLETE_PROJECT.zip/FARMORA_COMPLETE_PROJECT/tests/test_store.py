"""Unit tests for the Store, Cart with weight options, and Order Management."""
import unittest
import tempfile
from pathlib import Path
from datetime import date

from farmora.config import Settings
from farmora.db import Database
from farmora import auth
from farmora import storefront
from farmora import portals


class StoreAndOrderTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.settings = Settings(db_backend="sqlite", sqlite_path=str(Path(self.tmp) / "test_store.db"))
        self.db = Database(self.settings)
        self.db.init_schema()

        # Seed minimal store data
        self.db.execute(
            "INSERT INTO actors (actor_id, name, role, organization, location, created_at) "
            "VALUES (?,?,?,?,?,?)",
            ("RT01", "Indiranagar Store", "retailer", "Farmora Indiranagar", "Bengaluru", "2026-01-01 10:00:00")
        )
        self.db.execute(
            "INSERT INTO products (product_id, name, category, shelf_life_days, price_per_kg, mrp_per_kg, active) "
            "VALUES (?,?,?,?,?,?,?)",
            ("P01", "Organic Tomato", "Vegetables", 7, 80.0, 95.0, 1)
        )
        self.db.execute(
            "INSERT INTO products (product_id, name, category, shelf_life_days, price_per_kg, mrp_per_kg, active) "
            "VALUES (?,?,?,?,?,?,?)",
            ("P02", "Organic Spinach", "Vegetables", 4, 60.0, 70.0, 1)
        )
        # Allocate initial inventory: 50 kg Tomato, 10 kg Spinach
        self.db.execute(
            "INSERT INTO inventory (retailer_id, product_id, stock_kg, updated_on) VALUES (?,?,?,?)",
            ("RT01", "P01", 50.0, str(date.today()))
        )
        self.db.execute(
            "INSERT INTO inventory (retailer_id, product_id, stock_kg, updated_on) VALUES (?,?,?,?)",
            ("RT01", "P02", 10.0, str(date.today()))
        )

        # Create demo customer
        self.user_id = auth.create_user(self.db, "cust_test", "pass123", "customer", "Test Customer", "9988776655", "Indiranagar")
        self.user = {"user_id": self.user_id, "username": "cust_test", "role": "customer", "full_name": "Test Customer"}

    def test_price_scaling_by_weight(self):
        # 1000g base = 80
        self.assertEqual(storefront.price_for(80.0, 1000), 80.0)
        # 500g = 40
        self.assertEqual(storefront.price_for(80.0, 500), 40.0)
        # 250g = 20
        self.assertEqual(storefront.price_for(80.0, 250), 20.0)

    def test_cart_key_uniqueness(self):
        # Verify that adding different weights for same product are distinct keys
        key_250 = f"P01::{250}"
        key_500 = f"P01::{500}"
        key_other = f"P02::{500}"
        self.assertNotEqual(key_250, key_500)
        self.assertNotEqual(key_500, key_other)

    def test_place_order_and_stock_deduction(self):
        lines = [
            {"product_id": "P01", "name": "Organic Tomato", "grams": 500, "qty": 2, "unit_price": 40.0, "line_total": 80.0},
            {"product_id": "P02", "name": "Organic Spinach", "grams": 250, "qty": 4, "unit_price": 15.0, "line_total": 60.0},
        ]
        # P01 needed: 2 * 0.5kg = 1.0 kg; P02 needed: 4 * 0.25kg = 1.0 kg
        err, oid = storefront.place_order(self.db, self.user, "RT01", lines, "123 Street", "9988776655", "Test Customer")
        self.assertIsNone(err)
        self.assertIsNotNone(oid)

        # Verify stock was deducted: Tomato 50 - 1 = 49; Spinach 10 - 1 = 9
        s_tomato = float(self.db.scalar("SELECT stock_kg FROM inventory WHERE retailer_id = 'RT01' AND product_id = 'P01'"))
        s_spinach = float(self.db.scalar("SELECT stock_kg FROM inventory WHERE retailer_id = 'RT01' AND product_id = 'P02'"))
        self.assertEqual(s_tomato, 49.0)
        self.assertEqual(s_spinach, 9.0)

        # Verify order in store_orders
        order = self.db.one("SELECT * FROM store_orders WHERE order_id = ?", (oid,))
        self.assertEqual(order["status"], "Placed")
        self.assertEqual(order["payment_mode"], "COD")
        # Subtotal 140 < 199 => delivery fee 25 => total 165
        self.assertEqual(float(order["total"]), 165.0)

    def test_insufficient_stock_rejection(self):
        lines = [
            {"product_id": "P02", "name": "Organic Spinach", "grams": 1000, "qty": 15, "unit_price": 60.0, "line_total": 900.0},
        ]
        # Needs 15 kg, but only 10 kg in stock
        err, oid = storefront.place_order(self.db, self.user, "RT01", lines, "123 Street", "9988776655", "Test Customer")
        self.assertIsNotNone(err)
        self.assertIn("Insufficient stock", err)
        self.assertIsNone(oid)

        # Stock remains untouched
        stock = float(self.db.scalar("SELECT stock_kg FROM inventory WHERE retailer_id = 'RT01' AND product_id = 'P02'"))
        self.assertEqual(stock, 10.0)

    def test_order_cancellation_restores_stock(self):
        lines = [
            {"product_id": "P01", "name": "Organic Tomato", "grams": 1000, "qty": 5, "unit_price": 80.0, "line_total": 400.0},
        ]
        err, oid = storefront.place_order(self.db, self.user, "RT01", lines, "123 Street", "9988776655", "Test Customer")
        self.assertIsNone(err)

        # Tomato stock went from 50 to 45
        s_after_order = float(self.db.scalar("SELECT stock_kg FROM inventory WHERE retailer_id = 'RT01' AND product_id = 'P01'"))
        self.assertEqual(s_after_order, 45.0)

        # Customer cancels order
        cancel_err = portals.update_order_status(self.db, oid, "Cancelled")
        self.assertIsNone(cancel_err)

        # Stock restored back to 50
        s_after_cancel = float(self.db.scalar("SELECT stock_kg FROM inventory WHERE retailer_id = 'RT01' AND product_id = 'P01'"))
        self.assertEqual(s_after_cancel, 50.0)


if __name__ == "__main__":
    unittest.main()
