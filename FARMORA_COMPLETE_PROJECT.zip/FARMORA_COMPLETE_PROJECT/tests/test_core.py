import json
import tempfile
import unittest
from datetime import datetime
from decimal import Decimal
from pathlib import Path

from farmora.hashing import canonical_json, event_record, norm_qty, norm_time, sha256_hex
from farmora.ledger import LedgerError, LocalLedger
from farmora.rules import EVENT_TYPES as E, RuleViolation, check_event_allowed, event_type_id, next_allowed_events


class RulesTests(unittest.TestCase):
    def test_order_and_repeatable(self):
        check_event_allowed(E["HARVESTED"], E["CULTIVATED"], False, False)
        check_event_allowed(E["SHIPPED"], E["SHIPPED"], True, False)   # repeatable
        check_event_allowed(E["SOLD"], E["SOLD"], True, False)         # repeatable
        with self.assertRaises(RuleViolation):
            check_event_allowed(E["HARVESTED"], E["HARVESTED"], False, False)
        with self.assertRaises(RuleViolation):
            check_event_allowed(E["CULTIVATED"], E["HARVESTED"], False, False)

    def test_processing_needs_certification(self):
        with self.assertRaises(RuleViolation):
            check_event_allowed(E["PROCESSED"], E["HARVESTED"], False, False)
        check_event_allowed(E["PROCESSED"], E["CERTIFIED"], True, False)

    def test_revocation(self):
        with self.assertRaises(RuleViolation):
            check_event_allowed(E["REVOKED"], E["HARVESTED"], False, False)
        check_event_allowed(E["REVOKED"], E["RECEIVED"], True, False)
        with self.assertRaises(RuleViolation):
            check_event_allowed(E["SOLD"], E["RECEIVED"], True, True)

    def test_next_allowed(self):
        self.assertEqual(next_allowed_events(0, False, False), ["CULTIVATED", "HARVESTED", "CERTIFIED"])
        self.assertEqual(next_allowed_events(E["SOLD"], True, True), [])

    def test_event_type_id(self):
        self.assertEqual(event_type_id("harvested"), 2)
        self.assertEqual(event_type_id(3), 3)
        with self.assertRaises(RuleViolation):
            event_type_id("nonsense")


class HashingTests(unittest.TestCase):
    def test_canonical_is_key_order_independent(self):
        self.assertEqual(canonical_json({"b": 1, "a": 2}), canonical_json({"a": 2, "b": 1}))
        self.assertEqual(len(sha256_hex({"x": 1})), 64)

    def test_normalisation_matches_across_backends(self):
        self.assertEqual(norm_qty(Decimal("12.5")), norm_qty(12.5))
        self.assertEqual(norm_qty("12.500"), "12.500")
        self.assertEqual(norm_time(datetime(2026, 1, 2, 3, 4, 5)), norm_time("2026-01-02 03:04:05"))
        self.assertEqual(norm_time("2026-01-02T03:04:05"), "2026-01-02 03:04:05")

    def test_event_hash_changes_with_any_field(self):
        base = {"batch_id": "B", "seq": 1, "event_type": "HARVESTED", "actor_id": "F1", "location": "x",
                "quantity_kg": 10, "reference": "", "notes": "", "event_time": "2026-01-01 10:00:00"}
        h = sha256_hex(event_record(base))
        for field, val in [("quantity_kg", 11), ("location", "y"), ("notes", "n"), ("seq", 2), ("actor_id", "F2"),
                           ("event_time", "2026-01-01 10:00:01"), ("event_type", "SOLD")]:
            self.assertNotEqual(h, sha256_hex(event_record({**base, field: val})), field)
        self.assertEqual(h, sha256_hex(event_record({**base, "quantity_kg": Decimal("10.000")})))


class LocalLedgerTests(unittest.TestCase):
    def setUp(self):
        self.path = Path(tempfile.mkdtemp()) / "l.jsonl"
        self.l = LocalLedger(str(self.path))
        self.h = "ab" * 32

    def test_flow_and_roles(self):
        self.l.register_batch("B1", self.h, "farmer")
        with self.assertRaises(LedgerError):
            self.l.register_batch("B1", self.h, "farmer")
        with self.assertRaises(LedgerError):
            self.l.register_batch("B2", self.h, "retailer")
        with self.assertRaises(LedgerError):
            self.l.add_event("B1", E["CERTIFIED"], self.h, "farmer")   # wrong role
        self.l.add_event("B1", E["HARVESTED"], self.h, "farmer")
        with self.assertRaises(LedgerError):
            self.l.add_event("B1", E["PROCESSED"], self.h, "processor")  # not certified
        self.l.add_event("B1", E["CERTIFIED"], self.h, "certifier")
        self.l.add_event("B1", E["PROCESSED"], self.h, "processor")
        b = self.l.get_batch("B1")
        self.assertEqual(b["event_count"], 3)
        self.assertTrue(b["certified"])
        self.assertIsNone(self.l.get_batch("nope"))

    def test_persistence_and_tamper_evidence(self):
        self.l.register_batch("B1", self.h, "farmer")
        self.l.add_event("B1", E["HARVESTED"], self.h, "farmer")
        reloaded = LocalLedger(str(self.path))
        self.assertTrue(reloaded.chain_valid)
        self.assertEqual(reloaded.get_batch("B1")["event_count"], 1)
        lines = self.path.read_text().splitlines()
        blk = json.loads(lines[1]); blk["data_hash"] = "cd" * 32
        lines[1] = json.dumps(blk, sort_keys=True)
        self.path.write_text("\n".join(lines) + "\n")
        self.assertFalse(LocalLedger(str(self.path)).chain_valid)


if __name__ == "__main__":
    unittest.main()
