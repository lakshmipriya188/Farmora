import tempfile
from pathlib import Path

from farmora.config import Settings
from farmora.db import Database
from farmora.ledger import LocalLedger
from farmora.services import FarmoraService


def make_service(tmp: str | None = None) -> FarmoraService:
    tmp = tmp or tempfile.mkdtemp()
    s = Settings(db_backend="sqlite", sqlite_path=str(Path(tmp) / "t.db"), ledger_backend="local",
                 local_ledger_path=str(Path(tmp) / "ledger.jsonl"))
    db = Database(s)
    db.init_schema()
    return FarmoraService(db, LocalLedger(s.local_ledger_path), s)


def basic_world(svc: FarmoraService) -> dict:
    """Minimal master data: one actor per role, one product, one valid certificate."""
    svc.db.executemany("INSERT INTO products (product_id, name, category, shelf_life_days) VALUES (?,?,?,?)",
                       [("P1", "Organic Tomato", "Vegetables", 7)])
    for aid, role in [("F1", "farmer"), ("F2", "farmer"), ("PR1", "processor"), ("D1", "distributor"), ("R1", "retailer"), ("C1", "certifier")]:
        svc.add_actor(aid, f"Actor {aid}", role, "Org", "Karnataka")
    cert = svc.issue_certification("F1", "NPOP", "2025-01-01", "2030-01-01")
    return {"cert": cert["cert_id"]}


def full_lifecycle(svc: FarmoraService, cert_id: str, qty: float = 100.0) -> str:
    b = svc.register_batch("F1", "P1", qty)
    bid = b["batch_id"]
    svc.add_event(bid, "CULTIVATED", "F1", qty)
    svc.add_event(bid, "HARVESTED", "F1", qty)
    svc.add_event(bid, "CERTIFIED", "C1", 0, reference=cert_id)
    svc.add_event(bid, "PROCESSED", "PR1", qty * 0.9)
    svc.add_event(bid, "SHIPPED", "D1", qty * 0.89)
    svc.add_event(bid, "RECEIVED", "R1", qty * 0.88)
    svc.add_event(bid, "SOLD", "R1", qty * 0.5)
    return bid
