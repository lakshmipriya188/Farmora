import unittest

from farmora.services import TraceError
from tests.helpers import basic_world, full_lifecycle, make_service


class ServiceTests(unittest.TestCase):
    def setUp(self):
        self.svc = make_service()
        self.world = basic_world(self.svc)

    def test_full_lifecycle_verifies(self):
        bid = full_lifecycle(self.svc, self.world["cert"])
        r = self.svc.verify_batch(bid)
        self.assertTrue(r["ok"], r["issues"])
        self.assertEqual(r["chain_events"], 7)
        self.assertEqual(len(self.svc.get_events(bid)), 7)

    def test_role_and_ownership_rules(self):
        bid = self.svc.register_batch("F1", "P1", 50)["batch_id"]
        with self.assertRaises(TraceError):
            self.svc.add_event(bid, "HARVESTED", "R1", 50)              # retailer cannot harvest
        with self.assertRaises(TraceError):
            self.svc.add_event(bid, "HARVESTED", "F2", 50)              # other farmer
        with self.assertRaises(TraceError):
            self.svc.register_batch("R1", "P1", 50)                     # only farmers register
        with self.assertRaises(TraceError):
            self.svc.register_batch("F1", "NOPE", 50)
        with self.assertRaises(TraceError):
            self.svc.register_batch("F1", "P1", 0)

    def test_order_and_certification_rules(self):
        bid = self.svc.register_batch("F1", "P1", 50)["batch_id"]
        self.svc.add_event(bid, "HARVESTED", "F1", 50)
        with self.assertRaises(TraceError):
            self.svc.add_event(bid, "PROCESSED", "PR1", 45)             # not certified yet
        with self.assertRaises(TraceError):
            self.svc.add_event(bid, "CERTIFIED", "C1", 0)               # no certificate reference
        with self.assertRaises(TraceError):
            self.svc.add_event(bid, "CERTIFIED", "C1", 0, reference="CERT-NOPE")
        self.svc.add_event(bid, "CERTIFIED", "C1", 0, reference=self.world["cert"])
        with self.assertRaises(TraceError):
            self.svc.add_event(bid, "HARVESTED", "F1", 50)              # backwards

    def test_expired_certificate_is_rejected_but_can_be_forced(self):
        exp = self.svc.issue_certification("F2", "NPOP", "2020-01-01", "2021-01-01")["cert_id"]
        self.svc.db.execute("UPDATE actors SET actor_id = actor_id")  # no-op sanity
        bid = self.svc.register_batch("F2", "P1", 50)["batch_id"]
        self.svc.add_event(bid, "HARVESTED", "F2", 50)
        with self.assertRaises(TraceError):
            self.svc.add_event(bid, "CERTIFIED", "C1", 0, reference=exp)
        self.svc.add_event(bid, "CERTIFIED", "C1", 0, reference=exp, strict_cert=False)  # used by the anomaly seeder

    def test_revocation_freezes_batch(self):
        bid = full_lifecycle(self.svc, self.world["cert"])
        self.svc.add_event(bid, "REVOKED", "C1", 0, notes="residue")
        with self.assertRaises(TraceError):
            self.svc.add_event(bid, "SOLD", "R1", 1)
        self.assertEqual(self.svc.batch_state(bid)["next_events"], [])
        self.assertTrue(self.svc.verify_batch(bid)["ok"])

    def test_tampering_is_detected_and_restorable(self):
        bid = full_lifecycle(self.svc, self.world["cert"])
        old = self.svc.tamper_event(bid, 3, "quantity_kg", 999)
        r = self.svc.verify_batch(bid)
        self.assertFalse(r["ok"])
        self.assertEqual([e["status"] for e in r["events"]].count("TAMPERED"), 1)
        self.assertEqual(r["events"][3]["status"], "TAMPERED")
        self.svc.restore_event(bid, 3, "quantity_kg", old)
        self.assertTrue(self.svc.verify_batch(bid)["ok"])
        self.assertEqual(self.svc.verify_all()["status"].tolist(), ["VERIFIED"])

    def test_tampering_with_text_fields(self):
        bid = full_lifecycle(self.svc, self.world["cert"])
        for field, val in (("location", "Somewhere else"), ("notes", "edited")):
            old = self.svc.tamper_event(bid, 2, field, val)
            self.assertFalse(self.svc.verify_batch(bid)["ok"], field)
            self.svc.restore_event(bid, 2, field, old)
        self.assertTrue(self.svc.verify_batch(bid)["ok"])

    def test_deleted_row_detected_and_reinserted(self):
        bid = full_lifecycle(self.svc, self.world["cert"])
        row = self.svc.delete_event_row(bid, 4)
        r = self.svc.verify_batch(bid)
        self.assertFalse(r["ok"])
        self.assertEqual(r["events"][4]["status"], "MISSING_IN_DB")
        self.svc.reinsert_event_row(row)
        self.assertTrue(self.svc.verify_batch(bid)["ok"])

    def test_forged_extra_row_detected(self):
        bid = full_lifecycle(self.svc, self.world["cert"])
        self.svc.db.execute(
            "INSERT INTO trace_events (batch_id, seq, event_type, actor_id, location, quantity_kg, reference, notes, event_time, data_hash)"
            " VALUES (?,?,?,?,?,?,?,?,?,?)", (bid, 7, "SOLD", "R1", "", "10.000", "", "forged", "2026-01-01 00:00:00", "00" * 32))
        r = self.svc.verify_batch(bid)
        self.assertFalse(r["ok"])
        self.assertEqual(r["events"][-1]["status"], "NOT_ON_CHAIN")

    def test_batch_master_data_tamper(self):
        bid = full_lifecycle(self.svc, self.world["cert"], qty=100)
        self.svc.db.execute("UPDATE batches SET quantity_kg = 9999 WHERE batch_id = ?", (bid,))
        r = self.svc.verify_batch(bid)
        self.assertFalse(r["batch_ok"])
        self.assertFalse(r["ok"])

    def test_unknown_batch(self):
        self.assertFalse(self.svc.verify_batch("nope")["found"])
        with self.assertRaises(TraceError):
            self.svc.add_event("nope", "HARVESTED", "F1", 1)

    def test_qr_url(self):
        self.assertIn("?batch=B1", self.svc.batch_url("B1"))


if __name__ == "__main__":
    unittest.main()
