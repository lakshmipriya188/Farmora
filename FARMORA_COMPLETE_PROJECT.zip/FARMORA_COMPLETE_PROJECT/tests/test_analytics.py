import unittest
import warnings

import numpy as np
import pandas as pd

from farmora import analytics as an


def synthetic_series(days=400, seed=1):
    rng = np.random.default_rng(seed)
    idx = pd.date_range("2025-01-01", periods=days, freq="D")
    wk = np.array([0.85, 0.85, 0.9, 0.95, 1.1, 1.35, 1.3])[idx.dayofweek]
    season = 1 + 0.2 * np.cos(2 * np.pi * (idx.dayofyear - 40) / 365.25)
    return pd.Series(50 * wk * season * rng.lognormal(0, 0.1, days), index=idx)


class ForecastTests(unittest.TestCase):
    def test_forecast_beats_naive_and_is_sane(self):
        res = an.forecast_series(synthetic_series(), horizon=14)
        self.assertEqual(len(res["forecast"]), 14)
        self.assertTrue((res["forecast"]["forecast"] >= 0).all())
        self.assertTrue((res["forecast"]["lower"] <= res["forecast"]["upper"]).all())
        self.assertEqual(set(res["metrics"]["model"]), set(an.MODELS))
        self.assertLess(res["metrics"].iloc[0]["MAPE %"], 15)
        self.assertGreater(res["improvement_vs_naive_pct"], 0)

    def test_too_little_history(self):
        with self.assertRaises(ValueError):
            an.forecast_series(synthetic_series(days=60))


class CleaningTests(unittest.TestCase):
    def test_clean_sales(self):
        df = pd.DataFrame({"sale_date": ["2026-01-01"] * 2 + ["2026-01-02", "2026-01-03"], "retailer_id": "R", "product_id": "P",
                           "qty_kg": [5, 5, -1, None], "price_per_kg": 10, "revenue": 50})
        out, rep = an.clean_sales(df)
        self.assertEqual(len(out), 1)
        self.assertEqual(rep["duplicates_removed"], 1)
        self.assertEqual(rep["invalid_removed"], 2)


class AnomalyTests(unittest.TestCase):
    def test_sales_spike_and_drop_found_without_false_alarms(self):
        rng = np.random.default_rng(3)
        idx = pd.date_range("2025-01-01", periods=300, freq="D")
        q = 20 * np.array([0.85, 0.85, 0.9, 0.95, 1.1, 1.35, 1.3])[idx.dayofweek] * rng.lognormal(0, 0.12, 300)
        q[100] *= 4; q[200] *= 0.05
        df = pd.DataFrame({"sale_date": idx, "retailer_id": "R1", "product_id": "P1", "qty_kg": q})
        out = an.detect_sales_anomalies(df)
        self.assertEqual(set(out["sale_date"]), {idx[100], idx[200]})
        self.assertEqual(set(out["type"]), {"Spike", "Drop"})

    def test_batch_rules(self):
        base = dict(product_id="P1", events=7, harvest_kg=100.0, processed_kg=90.0, shipped_kg=89.0, received_kg=88.0, sold_kg=50.0,
                    yield_ratio=0.9, transit_ratio=0.99, end_to_end_loss=0.12, days_harvest_to_received=5.0, days_transit=1.0,
                    hours_harvest_to_cert=48.0, min_gap_hours=10.0, shelf_life_days=7, cert_valid=True)
        rows = [{**base, "batch_id": "ok"},
                {**base, "batch_id": "yield", "yield_ratio": 1.3},
                {**base, "batch_id": "loss", "end_to_end_loss": 0.6},
                {**base, "batch_id": "order", "min_gap_hours": -48.0},
                {**base, "batch_id": "cert", "cert_valid": False},
                {**base, "batch_id": "oversell", "sold_kg": 120.0},
                {**base, "batch_id": "slow", "days_transit": 6.0}]
        out = an.detect_batch_anomalies(pd.DataFrame(rows))
        self.assertEqual(set(out["batch_id"]), {"yield", "loss", "order", "cert", "oversell", "slow"})
        self.assertEqual(out.set_index("batch_id").loc["yield", "severity"], "High")
        self.assertEqual(out.set_index("batch_id").loc["loss", "severity"], "Medium")


class CustomerTests(unittest.TestCase):
    def test_rfm_segments(self):
        rng = np.random.default_rng(0)
        rows = []
        for c in range(120):
            n = int(rng.choice([1, 3, 12, 40]))
            for _ in range(n):
                rows.append({"customer_id": f"C{c}", "order_date": pd.Timestamp("2026-01-01") + pd.Timedelta(days=int(rng.integers(0, 300))),
                             "amount": float(rng.uniform(100, 900))})
        cust, summary = an.rfm_segments(pd.DataFrame(rows))
        self.assertEqual(len(cust), 120)
        self.assertEqual(summary["segment"].tolist(), ["Champions", "Loyal", "Occasional", "At risk / lapsed"])
        self.assertAlmostEqual(summary["revenue_share_pct"].sum(), 100.0)


if __name__ == "__main__":
    warnings.simplefilter("ignore")
    unittest.main()
