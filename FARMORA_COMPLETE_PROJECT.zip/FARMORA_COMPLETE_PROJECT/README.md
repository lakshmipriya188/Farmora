# FARMORA — Complete Blockchain-Based Organic Farm-to-Consumer Platform

**FARMORA** is a full-stack, enterprise-grade platform connecting organic farmers, processors, distributors, retailers, and consumers. It combines an Ethereum-compatible smart contract, relational database storage, machine learning demand forecasting, and a modern quick-commerce organic storefront into **one unified application**.

---

## 🔑 DEMO ACCOUNTS (Viva & Testing Credentials)

The system includes pre-configured demonstration accounts with securely hashed passwords (PBKDF2-HMAC-SHA256, 120,000 iterations):

| Role | Username | Password | Dashboard Features & Access |
|---|---|---|---|
| **Platform Administrator** | `admin` | `admin123` | Complete platform access: Analytics, Forecasts, Orders, Users, Products, Blockchain & Integrity Audit. |
| **Store Manager** | `manager1` | `manager123` | Store management, order status fulfillment, stock updates, sales analytics. |
| **Organic Farmer** | `farmer1` | `farmer123` | Farmer portal: Field registration, harvest batch creation, farm events (`Cultivated`, `Harvested`), organic certificates. |
| **Customer / Consumer** | `customer1` | `customer123` | Organic storefront, multi-weight selection (250g, 500g, 1kg), cart, Cash on Delivery checkout, personal order tracking. |
| **Public Guest** | *(No login required)* | *(QR Scan)* | Direct access to product blockchain provenance and verification by scanning product QR codes. |

---

## 🚀 ONE-CLICK WINDOWS EXECUTION (Fastest Setup)

### Option A: Double-Click Batch File (Recommended)
Simply double-click **`run_windows.bat`** in the project folder.

It will automatically:
1. Detect your Python installation (Python 3.10+).
2. Create and activate a local virtual environment (`.venv`).
3. Install/verify all required packages from `requirements.txt`.
4. Initialize the SQLite database and seed initial demo data if running for the first time.
5. Launch the FARMORA web application at **`http://localhost:8501`**.

### Option B: PowerShell Execution
Open PowerShell in the project directory and run:
```powershell
.\run_windows.ps1
```

---

## ⛓ BLOCKCHAIN SETUP (Real Ethereum / Hardhat Node)

By default, FARMORA runs on the fast local simulated ledger (`LEDGER_BACKEND=local`) for instant offline execution.

To demonstrate the **real Ethereum blockchain** using the Hardhat EVM node:

### Step 1: Double-Click `run_blockchain.bat`
This will automatically:
1. Install Hardhat dependencies in `blockchain/`.
2. Start a local Ethereum blockchain node on `http://127.0.0.1:8545`.
3. Compile and deploy `FarmoraTrace.sol` smart contract with role permissions.
4. Set `LEDGER_BACKEND=web3` in `.env` and seed initial batches directly on-chain.

### Step 2: Start the Web App
Double-click `run_windows.bat` and the application will now run against the live blockchain!

---

## 🏗 SYSTEM ARCHITECTURE

```mermaid
flowchart TB
    subgraph Users
      A[Administrator] --- F[Farmer] --- R[Retailer] --- C[Customer]
    end
    Users --> UI[Streamlit Unified Application<br/>http://localhost:8501]
    UI --> AUTH[Role-Based Authentication<br/>PBKDF2-HMAC-SHA256]
    UI --> STORE[Organic Storefront & Cart<br/>Weight Options: 250g / 500g / 1kg]
    UI --> SVC[Farmora Python Service Layer<br/>Validation, Lifecycle Rules, Hashing]
    SVC -->|SHA-256 Fingerprint| BC[(FarmoraTrace Smart Contract<br/>Hardhat / Ethereum Sepolia)]
    SVC -->|Full Record Details| DB[(Relational Database<br/>SQLite / MySQL)]
    DB --> ML[Data Science Analytics<br/>GBR / Ridge Forecasting, RFM Clustering, Isolation Forest]
    ML --> UI
    BC -. Cryptographic Tamper Verification .-> DB
```

### Key Architectural Highlights
1. **Hybrid On-Chain/Off-Chain Design**: Complete records, images, customer addresses, and order items live off-chain in the relational database. Cryptographic SHA-256 fingerprints are permanently recorded on the blockchain.
2. **Deterministic Tamper Verification**: When verifying a batch, the system recomputes the SHA-256 hash from the database row and compares it with the ledger. Any unauthorized modification (quantity, date, location) is immediately flagged as `TAMPERING DETECTED`.
3. **Cart Key Uniqueness Bug Fix**: Cart line items are uniquely indexed by `f"{product_id}::{grams}"`. Selecting 250g and 500g of the same product or multiple different items coexist independently without overwriting.
4. **Order Status Lifecycle**: Supports `Pending` -> `Confirmed` -> `Processing` -> `Packed` -> `Shipped` -> `Out for Delivery` -> `Delivered` / `Cancelled`. Cancelling an order automatically returns reserved stock to store inventory.

---

## 🧪 TESTING & VERIFICATION

FARMORA includes an automated test suite across all Python modules and Solidity smart contracts:

### 1. Run All Python Unit Tests
```bash
python -m pytest tests/
```
*Executes 49 comprehensive unit tests across:*
- `test_auth.py`: Password hashing, salt randomness, login validation, session updates.
- `test_store.py`: Weight scaling, cart multi-variant isolation, atomic checkout, stock replenishment.
- `test_rbac.py`: Role permission boundaries ensuring strict isolation between customer, farmer, and admin.
- `test_core.py`: Canonical JSON serialization, SHA-256 hashing, supply-chain rules.
- `test_service.py`: Batch registration, event recording, and tamper detection.
- `test_analytics.py`: Demand forecasting backtest, cleaning, and anomaly models.
- `test_pipeline.py`: Full end-to-end simulation.

### 2. Run Smart Contract Tests
```bash
cd blockchain
npx hardhat test
```
*Executes 17 Hardhat smart contract tests validating:*
- Role-based permissions (`Admin`, `Farmer`, `Certifier`, `Processor`, `Distributor`, `Retailer`).
- Agricultural state machine ordering (`Cultivated -> Harvested -> Certified -> Processed -> Shipped -> Received -> Sold`).
- Certification enforcement and batch revocation freezing.

---

## 📖 MCA FINAL-YEAR VIVA PREPARATION

A dedicated, comprehensive viva guide is included in:
👉 **[`docs/VIVA_GUIDE.md`](docs/VIVA_GUIDE.md)**

It provides:
- Exact answers to expected examiner questions.
- Clear explanations of the blockchain consensus, smart contract invariants, and hashing algorithms.
- Step-by-step 5-minute live demonstration flow.
