-- FARMORA MySQL schema (generated from farmora/db.py).
-- The app creates these tables automatically; this file is for documentation / manual setup.
CREATE DATABASE IF NOT EXISTS farmora CHARACTER SET utf8mb4;
USE farmora;

CREATE TABLE IF NOT EXISTS actors (
    actor_id VARCHAR(32) PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    role VARCHAR(20) NOT NULL,
    organization VARCHAR(120),
    location VARCHAR(120),
    created_at DATETIME NOT NULL
);

CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(40) NOT NULL UNIQUE,
    pw_hash VARCHAR(128) NOT NULL,
    salt VARCHAR(32) NOT NULL,
    role VARCHAR(20) NOT NULL,
    full_name VARCHAR(80),
    phone VARCHAR(20),
    address VARCHAR(250),
    actor_id VARCHAR(32),
    active INT NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL,
    FOREIGN KEY (actor_id) REFERENCES actors(actor_id)
);

CREATE TABLE IF NOT EXISTS categories (
    category_id VARCHAR(32) PRIMARY KEY,
    name VARCHAR(60) NOT NULL UNIQUE,
    description VARCHAR(200)
);

CREATE TABLE IF NOT EXISTS products (
    product_id VARCHAR(16) PRIMARY KEY,
    name VARCHAR(80) NOT NULL,
    category VARCHAR(40) NOT NULL,
    shelf_life_days INT NOT NULL,
    emoji VARCHAR(16) DEFAULT '🌿',
    image_url VARCHAR(200) DEFAULT '',
    mrp_per_kg DECIMAL(10,2) DEFAULT 0.0,
    price_per_kg DECIMAL(10,2) DEFAULT 0.0,
    unit_label VARCHAR(20) DEFAULT 'kg',
    active INT NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS product_prices (
    product_id VARCHAR(16) PRIMARY KEY,
    price_per_kg DECIMAL(10,2) NOT NULL,
    active INT NOT NULL DEFAULT 1,
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

CREATE TABLE IF NOT EXISTS certifications (
    cert_id VARCHAR(40) PRIMARY KEY,
    farmer_id VARCHAR(32) NOT NULL,
    standard VARCHAR(40) NOT NULL,
    issued_on DATE NOT NULL,
    valid_until DATE NOT NULL,
    status VARCHAR(12) NOT NULL,
    FOREIGN KEY (farmer_id) REFERENCES actors(actor_id)
);

CREATE TABLE IF NOT EXISTS batches (
    batch_id VARCHAR(64) PRIMARY KEY,
    product_id VARCHAR(16) NOT NULL,
    farmer_id VARCHAR(32) NOT NULL,
    farm_location VARCHAR(120),
    quantity_kg DECIMAL(12,3) NOT NULL,
    created_at DATETIME NOT NULL,
    data_hash CHAR(64) NOT NULL,
    tx_hash VARCHAR(80),
    gas_used INT,
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    FOREIGN KEY (farmer_id) REFERENCES actors(actor_id)
);

CREATE TABLE IF NOT EXISTS trace_events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    batch_id VARCHAR(64) NOT NULL,
    seq INT NOT NULL,
    event_type VARCHAR(20) NOT NULL,
    actor_id VARCHAR(32) NOT NULL,
    location VARCHAR(120),
    quantity_kg DECIMAL(12,3),
    reference VARCHAR(64),
    notes TEXT,
    event_time DATETIME NOT NULL,
    data_hash CHAR(64) NOT NULL,
    tx_hash VARCHAR(80),
    gas_used INT,
    UNIQUE (batch_id, seq),
    FOREIGN KEY (batch_id) REFERENCES batches(batch_id),
    FOREIGN KEY (actor_id) REFERENCES actors(actor_id)
);

CREATE TABLE IF NOT EXISTS sales_daily (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sale_date DATE NOT NULL,
    retailer_id VARCHAR(32) NOT NULL,
    product_id VARCHAR(16) NOT NULL,
    qty_kg DECIMAL(12,3) NOT NULL,
    price_per_kg DECIMAL(10,2) NOT NULL,
    revenue DECIMAL(14,2) NOT NULL,
    UNIQUE (sale_date, retailer_id, product_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    FOREIGN KEY (retailer_id) REFERENCES actors(actor_id)
);

CREATE TABLE IF NOT EXISTS customer_orders (
    order_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id VARCHAR(20) NOT NULL,
    order_date DATE NOT NULL,
    retailer_id VARCHAR(32) NOT NULL,
    product_id VARCHAR(16) NOT NULL,
    qty_kg DECIMAL(10,3) NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    FOREIGN KEY (retailer_id) REFERENCES actors(actor_id)
);

CREATE TABLE IF NOT EXISTS inventory (
    retailer_id VARCHAR(32) NOT NULL,
    product_id VARCHAR(16) NOT NULL,
    stock_kg DECIMAL(12,3) NOT NULL,
    updated_on DATE NOT NULL,
    PRIMARY KEY (retailer_id, product_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    FOREIGN KEY (retailer_id) REFERENCES actors(actor_id)
);

CREATE TABLE IF NOT EXISTS store_orders (
    order_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id VARCHAR(32) NOT NULL,
    user_id INT,
    retailer_id VARCHAR(32) NOT NULL,
    status VARCHAR(30) NOT NULL,
    payment_mode VARCHAR(20) NOT NULL,
    payment_status VARCHAR(20) NOT NULL,
    total DECIMAL(12,2) NOT NULL,
    customer_name VARCHAR(80),
    phone VARCHAR(20),
    address VARCHAR(250),
    order_date DATE NOT NULL,
    placed_at DATETIME NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (retailer_id) REFERENCES actors(actor_id)
);

CREATE TABLE IF NOT EXISTS store_order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id VARCHAR(16) NOT NULL,
    product_name VARCHAR(80) NOT NULL,
    selected_weight INT NOT NULL DEFAULT 500,
    qty INT NOT NULL DEFAULT 1,
    qty_kg DECIMAL(10,3) NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    line_total DECIMAL(12,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES store_orders(order_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

CREATE TABLE IF NOT EXISTS blockchain_transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tx_hash VARCHAR(80) NOT NULL,
    batch_id VARCHAR(64) NOT NULL,
    event_type VARCHAR(30) NOT NULL,
    actor_id VARCHAR(32) NOT NULL,
    gas_used INT,
    block_number INT,
    network VARCHAR(32),
    created_at DATETIME NOT NULL
);

CREATE INDEX idx_events_batch ON trace_events (batch_id);
CREATE INDEX idx_batches_farmer ON batches (farmer_id);
CREATE INDEX idx_sales_date ON sales_daily (sale_date);
CREATE INDEX idx_orders_customer ON customer_orders (customer_id);
CREATE INDEX idx_store_orders_user ON store_orders (user_id);
CREATE INDEX idx_store_orders_customer ON store_orders (customer_id);
CREATE INDEX idx_store_order_items_order ON store_order_items (order_id);
CREATE INDEX idx_users_username ON users (username);

