# FARMORA test plan and results

## Automated tests
| Suite | Command | Covers |
|---|---|---|
| Python (33 tests) | `python -m unittest discover -s tests -t .` | rules, hashing, simulated ledger, service layer, tamper detection (edit / delete / forge / batch data), end-to-end seed + verify + analytics |
| Smart contract | `cd blockchain && npx hardhat test` | roles, batch registration, event order and roles, certification gate, repeatable events, revocation, out-of-range reads, emitted events |

## Manual test cases (record screenshots for the report)
| # | Action | Expected |
|---|---|---|
| M1 | Register batch as farmer | transaction hash shown, QR generated |
| M2 | Record PROCESSED before CERTIFIED | rejected: certification required |
| M3 | Record HARVESTED with a retailer account | rejected: wrong role |
| M4 | Record CERTIFIED with an expired certificate | rejected: certificate not valid |
| M5 | Complete lifecycle, open Verify page | green VERIFIED, 7 events |
| M6 | Integrity audit: change quantity | red banner, exact event flagged TAMPERED |
| M7 | Integrity audit: delete event row | MISSING_IN_DB flagged |
| M8 | Restore | batch verified again |
| M9 | Revoke certificate (certifier) | no further events accepted |
| M10 | Restart app | all data and verification persist |

## Measured results (synthetic dataset, seed 42, 60 batches; reproduce with `python -m farmora.cli evaluate`)
| Measure | Result |
|---|---|
| Forecast MAPE, best model per product (28-day holdout) | 3.5% - 8.4% |
| RMSE improvement over seasonal-naive baseline | 15% - 88% depending on product |
| Sales anomalies: injected / detected / false alarms | 24 / 24 / 0 |
| Batch anomalies: injected / detected | 7 / 7 |
| Ledger verification of untouched data | 60 / 60 batches verified |
| Tampering (edit, delete, forge, batch data) | 100% detected in tests |

Gas per event must be measured on the `web3` backend (`python -m farmora.cli evaluate`); it is not available on the simulated ledger.
