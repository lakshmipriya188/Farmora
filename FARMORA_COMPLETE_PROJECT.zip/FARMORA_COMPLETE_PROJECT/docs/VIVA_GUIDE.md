# FARMORA — MCA Major Project Viva Voce Preparation Guide

This guide provides technical explanations, architecture summaries, and anticipated examiner questions with crisp, high-scoring answers for your MCA final-year project viva.

---

## 1. Project Synopsis

- **Title**: FARMORA – Blockchain-Based Organic Farm-to-Consumer Quick-Commerce Platform with Machine Learning Analytics.
- **Problem Statement**:
  - The organic food supply chain suffers from greenwashing, fraudulent claims, and lack of transparency.
  - Traditional relational databases allow centralized administrators or malicious insiders to alter quantities, dates, and organic certification tags without leaving a trace.
  - Consumers have no reliable, tamper-evident mechanism to verify whether the product on their kitchen counter was truly cultivated organically.
- **Solution Proposed by FARMORA**:
  - **Hybrid On-Chain/Off-Chain Architecture**:
    - **Off-chain Relational Storage (SQLite/MySQL)**: Houses high-volume transactional data, images, order lines, and sensor logs for fast queries.
    - **On-chain Cryptographic Ledger (Solidity Smart Contract on Ethereum/Hardhat)**: Stores cryptographic fingerprints (SHA-256 hashes) of every batch registration and lifecycle event, bound to the actor's verified wallet address and block timestamp.
  - **Data Science Layer**: Implements demand forecasting (Gradient Boosting & Ridge Regression with festive uplift features), customer segmentation (RFM + K-Means clustering), and supply-chain anomaly detection (Isolation Forest + deterministic heuristic rules).
  - **Quick-Commerce Storefront**: A user-friendly organic grocery shop with weight options (250g, 500g, 1000g), unique `<pid>::<grams>` cart keying, and single-click blockchain audit trails for consumers.

---

## 2. Technical Stack Breakdown

| Component | Technologies Used | Key Purpose |
|---|---|---|
| **Smart Contract** | Solidity `^0.8.24`, OpenZeppelin patterns, Hardhat | Role-based permissions, event sequencing state machine, immutable SHA-256 event fingerprinting. |
| **Web3 Middleware** | Python `web3.py` v6+, `eth-account` | Interfacing with the local Hardhat EVM node or Ethereum Sepolia testnet. |
| **Backend & UI** | Python 3.10–3.14, Streamlit, HTML5/CSS3 | Single-port responsive portal for Admin, Customer, and Farmer dashboards. |
| **Database** | SQLite (zero-config) & MySQL Server | Relational persistence of users, actors, products, inventory, orders, and trace logs. |
| **Data Science / ML** | `pandas`, `numpy`, `scikit-learn`, `plotly` | Time-series forecasting (GBR, Ridge, Naive), RFM K-Means, Isolation Forest anomalies. |
| **Security** | PBKDF2-HMAC-SHA256 (120,000 iterations), unique 16-byte salts | Secure user authentication and password storage. |

---

## 3. Frequently Asked Questions by Examiners

### Q1: Why did you choose a hybrid on-chain / off-chain architecture instead of storing everything on the blockchain?
**Answer**:
Storing large volumes of relational data (images, customer names, addresses, itemized order rows) directly on an Ethereum blockchain is cost-prohibitive due to gas fees and severely limits query throughput.
In FARMORA, the database stores the rich off-chain records. We calculate a deterministic SHA-256 hash of the canonical JSON record and write only that 32-byte fingerprint to the `FarmoraTrace` smart contract. During verification, we recompute the SHA-256 hash from the database and compare it with the blockchain ledger. If even a single byte (such as quantity or location) is altered in the database, the hashes will not match, immediately exposing tampering.

### Q2: What smart contract rules are enforced on the blockchain?
**Answer**:
Our contract `FarmoraTrace.sol` enforces three strict invariants:
1. **Role-Based Access Control (RBAC)**: Only accounts holding the `Farmer` role can register batches or record `Cultivated` and `Harvested` events; only an accredited `Certifier` can record `Certified` or `Revoked`; only `Processor` can record `Processed`; only `Distributor` can record `Shipped`; only `Retailer` can record `Received` and `Sold`.
2. **State Machine Sequencing**: Events must follow the logical agricultural lifecycle: `Cultivated -> Harvested -> Certified -> Processed -> Shipped -> Received -> Sold`. An event cannot skip preceding stages.
3. **Certification Gate**: No processing, shipping, or retail distribution is accepted by the smart contract unless the batch has an active `Certified` status. If a certifier triggers `Revoked`, the batch is frozen permanently.

### Q3: How does your demand forecasting model work?
**Answer**:
In `farmora/analytics.py`, we evaluate four competitive models on historical daily sales:
1. **Seasonal Naive** (day-of-week historical mean)
2. **28-Day Moving Average**
3. **Calendar Ridge Regression** (harmonic annual Fourier terms + day-of-week dummies + Indian festival indicators)
4. **Calendar Gradient Boosting Regressor (GBR)** (gradient boosted decision trees on calendar and festival features with linear trend detrending)
The system executes a backtest on the most recent 28-day validation window, measures RMSE, MAE, and MAPE%, selects the top-performing model, and forecasts upcoming demand with a 95% confidence interval.

### Q4: How is the cart quantity and weight bug solved in the storefront?
**Answer**:
In simple e-commerce implementations, carts are often indexed by `product_id`. If a user selects 250g of Organic Tomato and later adds 500g of Organic Tomato, the second entry overwrites the first.
In FARMORA, every cart line item is uniquely keyed by `f"{product_id}::{grams}"` (e.g. `P01::250` and `P01::500`). This ensures separate pack sizes and multiple products coexist independently in the cart with accurate prorated prices.

### Q5: How do you detect anomalies in the supply chain?
**Answer**:
FARMORA applies a two-pronged anomaly detection strategy:
1. **Deterministic Business Rules**: Detects impossible yield ratios (`processed_kg > harvested_kg`), negative event gap hours, uncertified batches, expired farmer certificates, and excessive transit delays.
2. **Unsupervised Machine Learning**: Uses `IsolationForest` from scikit-learn on batch features to isolate multidimensional statistical outliers that deviate from normal supply chain distributions.
3. **Sales Spikes and Drops**: Uses weekday-adjusted rolling median and Median Absolute Deviation (MAD) robust z-scores to flag abnormal retail sales without suffering from false alarms caused by weekly seasonality.

---

## 4. Live Demo Walkthrough (5-Minute Viva Flow)

1. **Step 1 — Show the Store & Customer Order**:
   - Log in as `customer1` / `customer123`.
   - Browse organic groceries, pick weight (250g / 500g / 1kg), add to cart.
   - Proceed to checkout -> place order (COD) -> show balloons & Order ID.
   - Open **My orders** -> show order status is `Placed`.
2. **Step 2 — Show Admin Order Processing & Inventory**:
   - Log in as `admin` / `admin123`.
   - Navigate to **Orders** -> update the order status to `Confirmed` -> `Shipped` -> `Delivered`.
   - Switch back to customer -> order status is live-updated to `Delivered` and payment marked `Paid (COD)`.
3. **Step 3 — Show Farmer Batch Registration**:
   - Log in as `farmer1` / `farmer123`.
   - Open **Farmer portal** -> show organic certificates and registered batches.
   - Register a new harvest batch on the ledger -> display generated QR code and blockchain transaction hash.
4. **Step 4 — Demonstrate Blockchain Verification & Attack Simulation**:
   - Navigate to **Verify a product** -> enter batch ID -> green **VERIFIED** badge.
   - Open **Integrity audit** -> click **Change quantity** (simulates an insider hacker tampering with the MySQL database).
   - Re-verify -> instant red **TAMPERING DETECTED** alert with exact mismatched field!
   - Click **Restore original data** -> status immediately turns green **VERIFIED** again.
5. **Step 5 — Data Science & Analytics**:
   - Open **Demand forecast** -> show 4-model comparison table (MAE, RMSE, MAPE%) and Plotly prediction chart.
   - Open **Anomalies** -> display flagged supply chain anomalies and explainable severity ratings.
