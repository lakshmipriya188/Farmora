# FARMORA architecture

```mermaid
flowchart TB
    subgraph Actors
      F[Farmer] --- P[Processor] --- D[Distributor] --- R[Retailer] --- C[Consumer]
    end
    Actors --> UI[Streamlit app]
    UI --> SVC[Python service layer<br/>rules, hashing, verification]
    SVC -->|SHA-256 fingerprint of each record| BC[(FarmoraTrace smart contract<br/>Ethereum / Hardhat)]
    SVC -->|full record| DB[(MySQL)]
    DB --> DS[Data science layer<br/>pandas, scikit-learn]
    DS --> UI
    BC -. verify: recompute hash and compare .-> DB
```

## Write path (recording an event)
1. UI -> `FarmoraService.add_event`.
2. Validation: actor role, batch ownership, event order, certificate validity (Python mirror of contract rules).
3. The record is converted to canonical JSON and hashed with SHA-256.
4. The hash is sent to `FarmoraTrace.addEvent`; the contract re-checks role, order and certification and stores the hash with the signer address and block timestamp.
5. Only after the transaction succeeds is the full record inserted into MySQL together with the transaction hash and gas used.

## Verification path
For every event index `i` on the ledger the service recomputes the hash from the MySQL row and compares it with `getEvent(batch, i)`. Result per event: `VERIFIED`, `TAMPERED` (row edited), `MISSING_IN_DB` (row deleted), `NOT_ON_CHAIN` (row forged). The batch master record is checked the same way.

## Entity-relationship diagram
```mermaid
erDiagram
    ACTORS ||--o{ CERTIFICATIONS : holds
    ACTORS ||--o{ BATCHES : grows
    PRODUCTS ||--o{ BATCHES : is
    BATCHES ||--|{ TRACE_EVENTS : has
    ACTORS ||--o{ TRACE_EVENTS : records
    ACTORS ||--o{ SALES_DAILY : sells
    PRODUCTS ||--o{ SALES_DAILY : of
    PRODUCTS ||--o{ CUSTOMER_ORDERS : bought
    PRODUCTS ||--o{ INVENTORY : stocked
```

## Smart contract rules
| Event | Recorded by | Rule |
|---|---|---|
| Cultivated, Harvested | farmer | strictly increasing order |
| Certified | certifier | sets `certified` |
| Processed, Shipped, Received, Sold | processor / distributor / retailer | batch must be certified; Shipped and Sold may repeat |
| Revoked | certifier | batch must be certified; freezes the batch |

## Analytics modules (`farmora/analytics.py`)
| Module | Method |
|---|---|
| Preprocessing | type conversion, duplicate/invalid removal, daily resampling |
| Demand forecasting | backtest of seasonal naive, moving average, calendar Ridge, calendar Gradient Boosting on the last 28 days; best RMSE model refit and used; 95% interval from backtest RMSE |
| Trends | 90-day growth, peak month, seasonality index |
| Inventory | days of cover = stock / forecast daily demand share; Critical < 3, Low < 7, Overstock > 30 |
| Customers | RFM features + K-Means (k=4), segments named by centroid |
| Batch anomalies | 7 explainable business rules + Isolation Forest |
| Sales anomalies | weekday-adjusted rolling median / MAD robust z-score |
