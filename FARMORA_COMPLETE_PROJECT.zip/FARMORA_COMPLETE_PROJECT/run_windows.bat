@echo off
setlocal enabledelayedexpansion

title FARMORA - Blockchain Organic Farm-to-Consumer Platform

echo =====================================================================
echo    FARMORA - Blockchain-Based Organic Farm-to-Consumer Platform
echo =====================================================================
echo.

REM 1. Check Python installation
where python >nul 2>nul
if %errorlevel% neq 0 (
    where py >nul 2>nul
    if %errorlevel% neq 0 (
        echo [ERROR] Python is not installed or not in your system PATH.
        echo Please install Python 3.10 or higher from https://www.python.org/
        pause
        exit /b 1
    ) else (
        set PYTHON_CMD=py
    )
) else (
    set PYTHON_CMD=python
)

echo [1/5] Checking Python environment...
%PYTHON_CMD% --version
echo.

REM 2. Setup Virtual Environment
if not exist ".venv" (
    echo [2/5] Creating Python virtual environment (.venv)...
    %PYTHON_CMD% -m venv .venv
    if %errorlevel% neq 0 (
        echo [ERROR] Failed to create virtual environment.
        pause
        exit /b 1
    )
) else (
    echo [2/5] Existing virtual environment found (.venv).
)
echo.

REM 3. Activate Virtual Environment
echo [3/5] Activating virtual environment...
call .venv\Scripts\activate.bat
if %errorlevel% neq 0 (
    echo [WARNING] Could not activate .venv directly. Using system python.
)
echo.

REM 4. Install Dependencies
echo [4/5] Checking and installing Python dependencies...
python -m pip install --upgrade pip --quiet
python -m pip install -r requirements.txt --quiet
if %errorlevel% neq 0 (
    echo [ERROR] Failed to install required packages.
    pause
    exit /b 1
)
echo Dependencies are up to date.
echo.

REM 5. Initialize Database and Seed if needed
echo [5/5] Checking database initialization...
if not exist "data\farmora.db" (
    echo Database not found. Initializing and seeding demo dataset...
    python -m farmora.cli seed
    if %errorlevel% neq 0 (
        echo [WARNING] Automatic seed encountered an issue. Initializing schema...
        python -m farmora.cli init
    )
) else (
    echo Database already exists at data\farmora.db. Preserving records.
)
echo.

echo =====================================================================
echo    FARMORA Platform is Ready!
echo.
echo    Local Application URL : http://localhost:8501
echo.
echo    DEMO ACCOUNTS:
echo    - Admin:    admin / admin123
echo    - Manager:  manager1 / manager123
echo    - Farmer:   farmer1 / farmer123
echo    - Customer: customer1 / customer123
echo.
echo    Press Ctrl+C in this window to stop the server.
echo =====================================================================
echo.

streamlit run app\streamlit_app.py
pause
