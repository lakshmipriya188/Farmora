"""FARMORA - blockchain-based organic food traceability with data science analytics."""
__version__ = "1.0.0"
