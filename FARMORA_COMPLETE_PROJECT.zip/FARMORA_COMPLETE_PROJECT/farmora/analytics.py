"""Data science layer: cleaning, demand forecasting, trends, inventory cover, customer segmentation
and anomaly detection. Everything here is pure pandas/numpy/scikit-learn and takes DataFrames,
so it can be tested without a database."""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.ensemble import GradientBoostingRegressor, IsolationForest
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler

# ====================================================================== cleaning
def clean_sales(df: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Preprocessing step: types, duplicates, negatives, missing values."""
    out = df.copy()
    n0 = len(out)
    out["sale_date"] = pd.to_datetime(out["sale_date"])
    for c in ("qty_kg", "price_per_kg", "revenue"):
        if c in out:
            out[c] = pd.to_numeric(out[c], errors="coerce")
    dups = int(out.duplicated(["sale_date", "retailer_id", "product_id"]).sum())
    out = out.drop_duplicates(["sale_date", "retailer_id", "product_id"])
    bad = int((out["qty_kg"].isna() | (out["qty_kg"] < 0)).sum())
    out = out[out["qty_kg"].notna() & (out["qty_kg"] >= 0)]
    out = out.sort_values(["product_id", "retailer_id", "sale_date"]).reset_index(drop=True)
    return out, {"rows_in": n0, "rows_out": len(out), "duplicates_removed": dups, "invalid_removed": bad}


def daily_series(sales: pd.DataFrame, product_id: str | None = None) -> pd.Series:
    d = sales if product_id is None else sales[sales["product_id"] == product_id]
    s = d.groupby("sale_date")["qty_kg"].sum().sort_index()
    return s.asfreq("D").fillna(0.0)


# ====================================================================== forecasting
def festival_flag(idx: pd.DatetimeIndex) -> np.ndarray:
    """Indian festive-season windows (approximate): Sankranti, Ugadi, Dasara-Deepavali."""
    md = idx.month * 100 + idx.day
    return (((md >= 1010) & (md <= 1016)) | ((md >= 325) & (md <= 410)) | ((md >= 1015) & (md <= 1105))).astype(float)


def _calendar_features(idx: pd.DatetimeIndex, t0: pd.Timestamp, with_trend: bool = True) -> np.ndarray:
    doy = idx.dayofyear.values.astype(float)
    cols = []
    if with_trend:
        cols.append(((idx - t0).days.values / 365.0))
    for k in (1, 2, 3):
        cols += [np.sin(2 * np.pi * k * doy / 365.25), np.cos(2 * np.pi * k * doy / 365.25)]
    dow = idx.dayofweek.values
    cols += [(dow == d).astype(float) for d in range(1, 7)]
    cols.append(festival_flag(idx))
    return np.column_stack(cols)


def _m_seasonal_naive(train: pd.Series, idx: pd.DatetimeIndex) -> np.ndarray:
    last = train.iloc[-28:]
    means = last.groupby(last.index.dayofweek).mean()
    return np.array([means[d] for d in idx.dayofweek])


def _m_moving_average(train: pd.Series, idx: pd.DatetimeIndex) -> np.ndarray:
    return np.full(len(idx), float(train.iloc[-28:].mean()))


def _m_ridge(train: pd.Series, idx: pd.DatetimeIndex) -> np.ndarray:
    t0 = train.index[0]
    model = Ridge(alpha=1.0).fit(_calendar_features(train.index, t0), np.log1p(train.values))
    return np.clip(np.expm1(model.predict(_calendar_features(idx, t0))), 0, None)


def _m_gbr(train: pd.Series, idx: pd.DatetimeIndex) -> np.ndarray:
    t0 = train.index[0]
    # Trend extrapolation is poor for trees, so remove a linear trend first and add it back.
    X_tr = _calendar_features(train.index, t0, with_trend=False)
    X_f = _calendar_features(idx, t0, with_trend=False)
    tt = ((train.index - t0).days.values / 365.0)
    slope, intercept = np.polyfit(tt, np.log1p(train.values), 1)
    resid = np.log1p(train.values) - (slope * tt + intercept)
    model = GradientBoostingRegressor(n_estimators=200, max_depth=3, learning_rate=0.05, subsample=0.8, random_state=0)
    model.fit(X_tr, resid)
    tf = ((idx - t0).days.values / 365.0)
    return np.clip(np.expm1(model.predict(X_f) + slope * tf + intercept), 0, None)


MODELS = {
    "Seasonal naive (weekday mean)": _m_seasonal_naive,
    "Moving average (28 d)": _m_moving_average,
    "Calendar Ridge regression": _m_ridge,
    "Calendar Gradient Boosting": _m_gbr,
}


def _metrics(actual: np.ndarray, pred: np.ndarray) -> dict:
    err = actual - pred
    return {
        "MAE": float(np.mean(np.abs(err))),
        "RMSE": float(np.sqrt(np.mean(err ** 2))),
        "MAPE %": float(np.mean(np.abs(err) / np.maximum(np.abs(actual), 1e-6)) * 100),
    }


def forecast_series(y: pd.Series, horizon: int = 28, holdout: int = 28) -> dict:
    """Backtest four models on the last `holdout` days, pick the lowest RMSE, refit on all data and forecast."""
    y = y.asfreq("D").fillna(0.0)
    if len(y) < holdout + 90:
        raise ValueError("Need at least holdout + 90 days of history")
    train, test = y.iloc[:-holdout], y.iloc[-holdout:]
    rows, backtest = [], pd.DataFrame({"actual": test})
    for name, fn in MODELS.items():
        pred = fn(train, test.index)
        backtest[name] = pred
        rows.append({"model": name, **_metrics(test.values, pred)})
    table = pd.DataFrame(rows).sort_values("RMSE").reset_index(drop=True)
    best = table.loc[0, "model"]
    future_idx = pd.date_range(y.index[-1] + pd.Timedelta(days=1), periods=horizon, freq="D")
    yhat = MODELS[best](y, future_idx)
    sd = float(table.loc[0, "RMSE"])
    fc = pd.DataFrame({"date": future_idx, "forecast": yhat,
                       "lower": np.clip(yhat - 1.96 * sd, 0, None), "upper": yhat + 1.96 * sd})
    baseline_rmse = float(table.loc[table["model"] == "Seasonal naive (weekday mean)", "RMSE"].iloc[0])
    return {"best_model": best, "metrics": table, "forecast": fc, "backtest": backtest.reset_index(names="date"),
            "improvement_vs_naive_pct": float((1 - table.loc[0, "RMSE"] / baseline_rmse) * 100)}


# ====================================================================== trends
def demand_trends(sales: pd.DataFrame, products: pd.DataFrame) -> pd.DataFrame:
    """Last-90-days vs previous-90-days demand growth and the peak month for each product."""
    end = sales["sale_date"].max()
    last = sales[sales["sale_date"] > end - pd.Timedelta(days=90)]
    prev = sales[(sales["sale_date"] <= end - pd.Timedelta(days=90)) & (sales["sale_date"] > end - pd.Timedelta(days=180))]
    a = last.groupby("product_id")["qty_kg"].sum()
    b = prev.groupby("product_id")["qty_kg"].sum()
    m = sales.assign(month=sales["sale_date"].dt.month).groupby(["product_id", "month"])["qty_kg"].mean().unstack()
    peak = m.idxmax(axis=1)
    out = pd.DataFrame({"last_90d_kg": a, "prev_90d_kg": b})
    out["growth_pct"] = (out["last_90d_kg"] / out["prev_90d_kg"] - 1) * 100
    out["peak_month"] = peak
    out = out.reset_index().merge(products[["product_id", "name", "category"]], on="product_id", how="left")
    out["trend"] = np.where(out["growth_pct"] > 5, "Rising", np.where(out["growth_pct"] < -5, "Falling", "Stable"))
    return out.sort_values("growth_pct", ascending=False).reset_index(drop=True)


def seasonality_index(sales: pd.DataFrame) -> pd.DataFrame:
    """Average daily demand per product and month relative to that product's overall mean (1.0 = typical)."""
    m = sales.assign(month=sales["sale_date"].dt.month).groupby(["product_id", "month"])["qty_kg"].mean().unstack()
    return m.div(m.mean(axis=1), axis=0)


# ====================================================================== inventory
def inventory_cover(inventory: pd.DataFrame, sales: pd.DataFrame, product_forecasts: dict, horizon_days: int = 14) -> pd.DataFrame:
    """Days of stock cover per retailer/product using the forecast demand share of each retailer."""
    end = sales["sale_date"].max()
    recent = sales[sales["sale_date"] > end - pd.Timedelta(days=90)]
    share = recent.groupby(["product_id", "retailer_id"])["qty_kg"].sum()
    share = share / share.groupby(level=0).transform("sum")
    rows = []
    for _, r in inventory.iterrows():
        pid, rid = r["product_id"], r["retailer_id"]
        fc = product_forecasts.get(pid)
        if fc is None or (pid, rid) not in share.index:
            continue
        daily = float(fc["forecast"].iloc[:horizon_days].mean()) * float(share[(pid, rid)])
        cover = float(r["stock_kg"]) / daily if daily > 0 else np.inf
        status = "Critical" if cover < 3 else "Low" if cover < 7 else "Overstock" if cover > 30 else "OK"
        rows.append({"retailer_id": rid, "product_id": pid, "stock_kg": float(r["stock_kg"]),
                     "forecast_daily_kg": daily, "days_of_cover": cover, "status": status})
    return pd.DataFrame(rows)


# ====================================================================== customers
def rfm_segments(orders: pd.DataFrame, k: int = 4, seed: int = 0) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Recency-Frequency-Monetary table + KMeans clusters with business labels."""
    o = orders.copy()
    o["order_date"] = pd.to_datetime(o["order_date"])
    o["amount"] = pd.to_numeric(o["amount"])
    asof = o["order_date"].max() + pd.Timedelta(days=1)
    g = o.groupby("customer_id").agg(last=("order_date", "max"), frequency=("order_date", "nunique"), monetary=("amount", "sum"))
    g["recency_days"] = (asof - g["last"]).dt.days
    X = StandardScaler().fit_transform(np.column_stack([np.log1p(g["recency_days"]), np.log1p(g["frequency"]), np.log1p(g["monetary"])]))
    km = KMeans(n_clusters=k, n_init=10, random_state=seed).fit(X)
    g["cluster"] = km.labels_
    # Rank clusters: high frequency/monetary and low recency = best.
    score = g.groupby("cluster").apply(
        lambda d: (-np.log1p(d["recency_days"].mean()) + np.log1p(d["frequency"].mean()) + np.log1p(d["monetary"].mean())),
        include_groups=False)
    names = ["Champions", "Loyal", "Occasional", "At risk / lapsed"][:k]
    label = {c: names[i] for i, c in enumerate(score.sort_values(ascending=False).index)}
    g["segment"] = g["cluster"].map(label)
    g = g.drop(columns=["last", "cluster"]).reset_index()
    summary = g.groupby("segment").agg(customers=("customer_id", "count"), avg_recency_days=("recency_days", "mean"),
                                       avg_orders=("frequency", "mean"), avg_spend=("monetary", "mean"),
                                       total_revenue=("monetary", "sum")).reset_index()
    summary["revenue_share_pct"] = summary["total_revenue"] / summary["total_revenue"].sum() * 100
    order = {n: i for i, n in enumerate(names)}
    return g, summary.sort_values("segment", key=lambda s: s.map(order)).reset_index(drop=True)


# ====================================================================== batch anomalies
def batch_features(batches: pd.DataFrame, events: pd.DataFrame, products: pd.DataFrame, certs: pd.DataFrame) -> pd.DataFrame:
    """One row per batch with the quantities and timings needed by the anomaly rules."""
    if events.empty:
        return pd.DataFrame()
    ev = events.copy()
    ev["event_time"] = pd.to_datetime(ev["event_time"])
    ev["quantity_kg"] = pd.to_numeric(ev["quantity_kg"]).fillna(0.0)
    ev = ev.sort_values(["batch_id", "seq"])
    rows = []
    cert_lookup = {r["cert_id"]: r for _, r in certs.iterrows()}
    shelf = products.set_index("product_id")["shelf_life_days"].to_dict()
    pid_of = batches.set_index("batch_id")["product_id"].to_dict()
    farmer_of = batches.set_index("batch_id")["farmer_id"].to_dict()
    for bid, g in ev.groupby("batch_id"):
        first = lambda t: g[g["event_type"] == t].head(1)
        qty = lambda t: float(first(t)["quantity_kg"].iloc[0]) if len(first(t)) else np.nan
        tm = lambda t: first(t)["event_time"].iloc[0] if len(first(t)) else pd.NaT
        harvest, processed, shipped, received = qty("HARVESTED"), qty("PROCESSED"), qty("SHIPPED"), qty("RECEIVED")
        sold = float(g[g["event_type"] == "SOLD"]["quantity_kg"].sum())
        deltas = g["event_time"].diff().dt.total_seconds().dropna() / 3600.0
        cert_ok = np.nan
        c = first("CERTIFIED")
        if len(c):
            ref = c["reference"].iloc[0]
            cr = cert_lookup.get(ref)
            day = c["event_time"].iloc[0].strftime("%Y-%m-%d")
            cert_ok = bool(cr is not None and cr["farmer_id"] == farmer_of.get(bid) and str(cr["status"]).upper() == "ACTIVE"
                           and str(cr["issued_on"])[:10] <= day <= str(cr["valid_until"])[:10])
        rows.append({
            "batch_id": bid, "product_id": pid_of.get(bid), "events": len(g),
            "harvest_kg": harvest, "processed_kg": processed, "shipped_kg": shipped, "received_kg": received, "sold_kg": sold,
            "yield_ratio": processed / harvest if harvest and not np.isnan(processed) else np.nan,
            "transit_ratio": received / shipped if shipped and not np.isnan(received) else np.nan,
            "end_to_end_loss": 1 - received / harvest if harvest and not np.isnan(received) else np.nan,
            "days_harvest_to_received": (tm("RECEIVED") - tm("HARVESTED")).total_seconds() / 86400 if pd.notna(tm("RECEIVED")) and pd.notna(tm("HARVESTED")) else np.nan,
            "days_transit": (tm("RECEIVED") - tm("SHIPPED")).total_seconds() / 86400 if pd.notna(tm("RECEIVED")) and pd.notna(tm("SHIPPED")) else np.nan,
            "hours_harvest_to_cert": (tm("CERTIFIED") - tm("HARVESTED")).total_seconds() / 3600 if pd.notna(tm("CERTIFIED")) and pd.notna(tm("HARVESTED")) else np.nan,
            "min_gap_hours": float(deltas.min()) if len(deltas) else np.nan,
            "shelf_life_days": shelf.get(pid_of.get(bid)),
            "cert_valid": cert_ok,
        })
    return pd.DataFrame(rows)


def detect_batch_anomalies(f: pd.DataFrame, contamination: float = 0.05) -> pd.DataFrame:
    """Business rules (explainable) + Isolation Forest (statistical outliers)."""
    if f.empty:
        return pd.DataFrame(columns=["batch_id", "severity", "reasons", "rule_hits", "ml_outlier"])
    reasons = {b: [] for b in f["batch_id"]}
    sev = {b: 0 for b in f["batch_id"]}

    def hit(mask, text, level):
        for _, r in f[mask.fillna(False)].iterrows():
            reasons[r["batch_id"]].append(text(r))
            sev[r["batch_id"]] = max(sev[r["batch_id"]], level)

    hit(f["yield_ratio"] > 1.02, lambda r: f"Processed quantity exceeds harvested quantity (yield {r['yield_ratio']:.2f})", 3)
    hit(f["transit_ratio"] > 1.01, lambda r: f"Received more than was shipped (ratio {r['transit_ratio']:.2f})", 3)
    hit(f["sold_kg"] > f["received_kg"] * 1.01, lambda r: f"Sold {r['sold_kg']:.0f} kg but only {r['received_kg']:.0f} kg received", 3)
    hit(f["min_gap_hours"] < 0, lambda r: "Events recorded out of chronological order", 3)
    hit(f["cert_valid"] == False, lambda r: "Certificate invalid or expired when the batch was certified", 3)  # noqa: E712
    hit(f["end_to_end_loss"] > 0.30, lambda r: f"End-to-end loss {r['end_to_end_loss']*100:.0f}% (above 30%)", 2)
    hit(f["days_transit"] > 0.5 * f["shelf_life_days"], lambda r: f"Transit {r['days_transit']:.1f} d exceeds half of shelf life ({r['shelf_life_days']} d)", 2)

    # Isolation Forest on numeric behaviour of all batches that reached the retailer.
    cols = ["yield_ratio", "transit_ratio", "end_to_end_loss", "days_harvest_to_received", "hours_harvest_to_cert"]
    ml = {b: False for b in f["batch_id"]}
    X = f[cols]
    ok = X.notna().all(axis=1)
    if ok.sum() >= 20:
        iso = IsolationForest(n_estimators=200, contamination=contamination, random_state=0)
        pred = iso.fit_predict(StandardScaler().fit_transform(X[ok]))
        for b, p in zip(f.loc[ok, "batch_id"], pred):
            if p == -1:
                ml[b] = True
                if not reasons[b]:
                    reasons[b].append("Statistical outlier compared with other batches (Isolation Forest)")
                    sev[b] = max(sev[b], 1)
    label = {0: "None", 1: "Low", 2: "Medium", 3: "High"}
    out = pd.DataFrame({"batch_id": list(reasons), "severity": [label[sev[b]] for b in reasons],
                        "reasons": ["; ".join(reasons[b]) for b in reasons], "rule_hits": [len(reasons[b]) for b in reasons],
                        "ml_outlier": [ml[b] for b in reasons], "_s": [sev[b] for b in reasons]})
    out = out[out["rule_hits"] > 0].sort_values(["_s", "rule_hits"], ascending=False).drop(columns="_s")
    return out.reset_index(drop=True)


# ====================================================================== sales anomalies
def detect_sales_anomalies(sales: pd.DataFrame, window: int = 21, z_thresh: float = 4.0) -> pd.DataFrame:
    """Robust (median/MAD) spike and drop detection per product x retailer, after removing weekday effects."""
    out = []
    for (rid, pid), g in sales.groupby(["retailer_id", "product_id"]):
        s = g.set_index("sale_date")["qty_kg"].astype(float).sort_index().asfreq("D")
        dow_factor = s.groupby(s.index.dayofweek).transform("mean")
        dow_factor = dow_factor / dow_factor.mean()
        adj = s / dow_factor.replace(0, np.nan)
        med = adj.rolling(window, center=True, min_periods=7).median()
        mad = (adj - med).abs().rolling(window, center=True, min_periods=7).median()
        z = 0.6745 * (adj - med) / mad.replace(0, np.nan)
        ratio = adj / med
        flag = (z.abs() > z_thresh) & ((ratio > 1.8) | (ratio < 0.4))
        for d in s.index[flag.fillna(False)]:
            out.append({"sale_date": d, "retailer_id": rid, "product_id": pid, "qty_kg": float(s[d]),
                        "expected_kg": float(med[d] * dow_factor[d]), "ratio": float(ratio[d]), "z_score": float(z[d]),
                        "type": "Spike" if ratio[d] > 1 else "Drop"})
    cols = ["sale_date", "retailer_id", "product_id", "qty_kg", "expected_kg", "ratio", "z_score", "type"]
    return pd.DataFrame(out, columns=cols).sort_values("z_score", key=lambda s: -s.abs()).reset_index(drop=True)
