"""Business logic: registers batches, records supply-chain events (DB + ledger) and verifies integrity."""
from __future__ import annotations

import io
import uuid
from datetime import datetime

import pandas as pd

from .config import Settings
from .db import Database
from .hashing import batch_record, event_record, norm_qty, norm_time, sha256_hex, strip0x
from .ledger import LedgerBase, LedgerError
from .rules import (ACTOR_ROLES, EVENT_NAMES, EVENT_ROLE, EVENT_TYPES, RuleViolation, check_event_allowed,
                    event_type_id, next_allowed_events)


class TraceError(Exception):
    """User-facing error (validation or ledger problem)."""


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


class FarmoraService:
    def __init__(self, db: Database, ledger: LedgerBase, settings: Settings | None = None):
        self.db = db
        self.ledger = ledger
        self.settings = settings or Settings.from_env()

    # ================================================================== master data
    def add_actor(self, actor_id: str, name: str, role: str, organization: str = "", location: str = "") -> dict:
        role = role.lower()
        if role not in ACTOR_ROLES:
            raise TraceError(f"Role must be one of {', '.join(ACTOR_ROLES)}")
        if not actor_id or not name:
            raise TraceError("Actor id and name are required")
        if self.db.one("SELECT actor_id FROM actors WHERE actor_id = ?", (actor_id,)):
            raise TraceError(f"Actor {actor_id} already exists")
        self.db.execute(
            "INSERT INTO actors (actor_id, name, role, organization, location, created_at) VALUES (?,?,?,?,?,?)",
            (actor_id, name, role, organization, location, _now()),
        )
        return self.get_actor(actor_id)

    def get_actor(self, actor_id: str):
        return self.db.one("SELECT * FROM actors WHERE actor_id = ?", (actor_id,))

    def list_actors(self, role: str | None = None) -> pd.DataFrame:
        if role:
            return self.db.df("SELECT * FROM actors WHERE role = ? ORDER BY actor_id", (role,))
        return self.db.df("SELECT * FROM actors ORDER BY role, actor_id")

    def list_products(self) -> pd.DataFrame:
        return self.db.df("SELECT * FROM products ORDER BY product_id")

    def issue_certification(self, farmer_id: str, standard: str, issued_on: str, valid_until: str) -> dict:
        farmer = self.get_actor(farmer_id)
        if not farmer or farmer["role"] != "farmer":
            raise TraceError("Certification can only be issued to a registered farmer")
        if valid_until <= issued_on:
            raise TraceError("valid_until must be after issued_on")
        n = self.db.scalar("SELECT COUNT(*) FROM certifications WHERE farmer_id = ?", (farmer_id,)) or 0
        cert_id = f"CERT-{farmer_id}-{int(n) + 1:03d}"
        self.db.execute(
            "INSERT INTO certifications (cert_id, farmer_id, standard, issued_on, valid_until, status) VALUES (?,?,?,?,?,?)",
            (cert_id, farmer_id, standard, issued_on, valid_until, "ACTIVE"),
        )
        return self.db.one("SELECT * FROM certifications WHERE cert_id = ?", (cert_id,))

    def certification_valid(self, cert_id: str, farmer_id: str, when: str) -> bool:
        row = self.db.one("SELECT * FROM certifications WHERE cert_id = ?", (cert_id,))
        if not row or row["farmer_id"] != farmer_id or str(row["status"]).upper() != "ACTIVE":
            return False
        day = norm_time(when)[:10]
        return str(row["issued_on"])[:10] <= day <= str(row["valid_until"])[:10]

    # ================================================================== batches
    def new_batch_id(self, farmer_id: str, when: str | None = None) -> str:
        day = norm_time(when or _now())[:10].replace("-", "")
        while True:
            bid = f"B{day}-{farmer_id}-{uuid.uuid4().hex[:4].upper()}"
            if not self.db.one("SELECT batch_id FROM batches WHERE batch_id = ?", (bid,)):
                return bid

    def register_batch(self, farmer_id: str, product_id: str, quantity_kg: float, farm_location: str | None = None,
                       created_at: str | None = None, batch_id: str | None = None) -> dict:
        farmer = self.get_actor(farmer_id)
        if not farmer or farmer["role"] != "farmer":
            raise TraceError("Batches can only be registered by a farmer")
        if not self.db.one("SELECT product_id FROM products WHERE product_id = ?", (product_id,)):
            raise TraceError(f"Unknown product {product_id}")
        if float(quantity_kg) <= 0:
            raise TraceError("Quantity must be greater than zero")
        created_at = norm_time(created_at or _now())
        batch_id = batch_id or self.new_batch_id(farmer_id, created_at)
        row = {"batch_id": batch_id, "product_id": product_id, "farmer_id": farmer_id,
               "farm_location": farm_location or farmer.get("location") or "", "quantity_kg": quantity_kg,
               "created_at": created_at}
        data_hash = sha256_hex(batch_record(row))
        try:
            tx = self.ledger.register_batch(batch_id, data_hash, "farmer")
        except LedgerError as exc:
            raise TraceError(f"Ledger rejected the batch: {exc}")
        self.db.execute(
            "INSERT INTO batches (batch_id, product_id, farmer_id, farm_location, quantity_kg, created_at, data_hash, tx_hash, gas_used)"
            " VALUES (?,?,?,?,?,?,?,?,?)",
            (batch_id, product_id, farmer_id, row["farm_location"], norm_qty(quantity_kg), created_at, data_hash,
             tx["tx_hash"], tx["gas_used"]),
        )
        return self.get_batch(batch_id)

    def get_batch(self, batch_id: str):
        return self.db.one(
            "SELECT b.*, p.name AS product_name, p.category, p.shelf_life_days, a.name AS farmer_name "
            "FROM batches b JOIN products p ON p.product_id = b.product_id JOIN actors a ON a.actor_id = b.farmer_id "
            "WHERE b.batch_id = ?", (batch_id,))

    def list_batches(self) -> pd.DataFrame:
        return self.db.df(
            "SELECT b.batch_id, p.name AS product, a.name AS farmer, b.quantity_kg, b.created_at, "
            "(SELECT COUNT(*) FROM trace_events e WHERE e.batch_id = b.batch_id) AS events "
            "FROM batches b JOIN products p ON p.product_id = b.product_id JOIN actors a ON a.actor_id = b.farmer_id "
            "ORDER BY b.created_at DESC")

    def get_events(self, batch_id: str) -> list[dict]:
        return self.db.query(
            "SELECT e.*, a.name AS actor_name, a.role AS actor_role FROM trace_events e "
            "JOIN actors a ON a.actor_id = e.actor_id WHERE e.batch_id = ? ORDER BY e.seq", (batch_id,))

    def batch_state(self, batch_id: str) -> dict:
        """Current on-chain state (last event, certified, revoked) used to decide what can happen next."""
        cb = self.ledger.get_batch(batch_id)
        if cb is None:
            raise TraceError("Batch is not registered on the ledger")
        cb["next_events"] = next_allowed_events(cb["last_event"], cb["certified"], cb["revoked"])
        return cb

    # ================================================================== events
    def add_event(self, batch_id: str, event_type, actor_id: str, quantity_kg: float | None = None,
                  location: str | None = None, notes: str = "", reference: str = "",
                  event_time: str | None = None, strict_cert: bool = True) -> dict:
        et = event_type_id(event_type)
        batch = self.get_batch(batch_id)
        if not batch:
            raise TraceError(f"Batch {batch_id} not found")
        actor = self.get_actor(actor_id)
        if not actor:
            raise TraceError(f"Actor {actor_id} not found")
        needed_role = EVENT_ROLE[et]
        if actor["role"] != needed_role:
            raise TraceError(f"{EVENT_NAMES[et]} must be recorded by a {needed_role}, not a {actor['role']}")
        if needed_role == "farmer" and actor_id != batch["farmer_id"]:
            raise TraceError("Only the farmer who registered the batch can record farm events for it")

        event_time = norm_time(event_time or _now())
        if et == EVENT_TYPES["CERTIFIED"]:
            if not reference:
                raise TraceError("A certificate id (reference) is required to certify a batch")
            if strict_cert and not self.certification_valid(reference, batch["farmer_id"], event_time):
                raise TraceError(f"Certificate {reference} is not valid for this farmer on {event_time[:10]}")

        cb = self.batch_state(batch_id)
        try:
            check_event_allowed(et, cb["last_event"], cb["certified"], cb["revoked"])
        except RuleViolation as exc:
            raise TraceError(str(exc))

        seq = cb["event_count"]
        row = {"batch_id": batch_id, "seq": seq, "event_type": EVENT_NAMES[et], "actor_id": actor_id,
               "location": location or actor.get("location") or "", "quantity_kg": quantity_kg or 0,
               "reference": reference or "", "notes": notes or "", "event_time": event_time}
        data_hash = sha256_hex(event_record(row))
        try:
            tx = self.ledger.add_event(batch_id, et, data_hash, needed_role)
        except LedgerError as exc:
            raise TraceError(f"Ledger rejected the event: {exc}")
        self.db.execute(
            "INSERT INTO trace_events (batch_id, seq, event_type, actor_id, location, quantity_kg, reference, notes,"
            " event_time, data_hash, tx_hash, gas_used) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
            (batch_id, seq, row["event_type"], actor_id, row["location"], norm_qty(row["quantity_kg"]),
             row["reference"], row["notes"], event_time, data_hash, tx["tx_hash"], tx["gas_used"]),
        )
        return {**row, "data_hash": data_hash, "tx_hash": tx["tx_hash"], "gas_used": tx["gas_used"]}

    # ================================================================== verification
    def verify_batch(self, batch_id: str) -> dict:
        """Recompute every hash from the database and compare with the ledger."""
        batch = self.get_batch(batch_id)
        report = {"batch_id": batch_id, "found": batch is not None, "on_chain": False, "batch_ok": False,
                  "events": [], "issues": [], "ok": False, "chain_events": 0, "db_events": 0}
        if batch is None:
            report["issues"].append("Batch not found in the database")
            return report
        cb = self.ledger.get_batch(batch_id, with_state=False)
        if cb is None:
            report["issues"].append("Batch is not registered on the ledger")
            return report
        report["on_chain"] = True
        report["batch_ok"] = sha256_hex(batch_record(batch)) == strip0x(cb["data_hash"])
        if not report["batch_ok"]:
            report["issues"].append("Batch master data does not match the ledger fingerprint")

        db_events = {int(e["seq"]): e for e in self.get_events(batch_id)}
        n_chain = cb["event_count"]
        report["chain_events"], report["db_events"] = n_chain, len(db_events)
        for i in range(n_chain):
            ce = self.ledger.get_event(batch_id, i)
            de = db_events.get(i)
            item = {"seq": i, "event_type": EVENT_NAMES.get(ce["event_type"], "?"), "chain_hash": ce["data_hash"],
                    "db_hash": None, "tx_hash": de["tx_hash"] if de else None, "status": "VERIFIED"}
            if de is None:
                item["status"] = "MISSING_IN_DB"
                report["issues"].append(f"Event #{i} exists on the ledger but is missing from the database")
            else:
                item["db_hash"] = sha256_hex(event_record(de))
                if item["db_hash"] != strip0x(ce["data_hash"]):
                    item["status"] = "TAMPERED"
                    report["issues"].append(f"Event #{i} ({item['event_type']}) was changed after it was recorded")
            report["events"].append(item)
        for seq in sorted(set(db_events) - set(range(n_chain))):
            report["events"].append({"seq": seq, "event_type": db_events[seq]["event_type"], "chain_hash": None,
                                     "db_hash": sha256_hex(event_record(db_events[seq])), "tx_hash": None,
                                     "status": "NOT_ON_CHAIN"})
            report["issues"].append(f"Event #{seq} is in the database but was never recorded on the ledger")
        report["ok"] = report["batch_ok"] and not report["issues"]
        return report

    def verify_all(self, progress=None) -> pd.DataFrame:
        ids = [r["batch_id"] for r in self.db.query("SELECT batch_id FROM batches ORDER BY created_at")]
        rows = []
        for i, bid in enumerate(ids):
            r = self.verify_batch(bid)
            rows.append({"batch_id": bid, "status": "VERIFIED" if r["ok"] else "TAMPERED",
                         "events_on_chain": r["chain_events"], "events_in_db": r["db_events"],
                         "issues": "; ".join(r["issues"])})
            if progress:
                progress(i + 1, len(ids))
        return pd.DataFrame(rows, columns=["batch_id", "status", "events_on_chain", "events_in_db", "issues"])

    # ================================================================== consumer QR
    def batch_url(self, batch_id: str) -> str:
        return f"{self.settings.app_base_url}/?batch={batch_id}"

    def qr_png(self, batch_id: str) -> bytes:
        import qrcode  # pip install "qrcode[pil]"

        img = qrcode.make(self.batch_url(batch_id))
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        return buf.getvalue()

    # ================================================================== tamper demo (for the viva)
    TAMPER_FIELDS = ("quantity_kg", "location", "notes")

    def tamper_event(self, batch_id: str, seq: int, field: str, value) -> object:
        """DEMO ONLY: edits an event row directly in the database, bypassing the ledger.
        Returns the previous value so it can be restored."""
        if field not in self.TAMPER_FIELDS:
            raise TraceError(f"Only {', '.join(self.TAMPER_FIELDS)} can be edited in the demo")
        row = self.db.one(f"SELECT {field} AS v FROM trace_events WHERE batch_id = ? AND seq = ?", (batch_id, seq))
        if row is None:
            raise TraceError("Event not found")
        self.db.execute(f"UPDATE trace_events SET {field} = ? WHERE batch_id = ? AND seq = ?", (value, batch_id, seq))
        return row["v"]

    def restore_event(self, batch_id: str, seq: int, field: str, value) -> None:
        if field not in self.TAMPER_FIELDS:
            raise TraceError("Unsupported field")
        self.db.execute(f"UPDATE trace_events SET {field} = ? WHERE batch_id = ? AND seq = ?", (value, batch_id, seq))

    def delete_event_row(self, batch_id: str, seq: int) -> dict:
        """DEMO ONLY: removes an event row from the database (simulates deleting evidence)."""
        row = self.db.one("SELECT * FROM trace_events WHERE batch_id = ? AND seq = ?", (batch_id, seq))
        if row is None:
            raise TraceError("Event not found")
        self.db.execute("DELETE FROM trace_events WHERE batch_id = ? AND seq = ?", (batch_id, seq))
        return row

    def reinsert_event_row(self, row: dict) -> None:
        cols = ["batch_id", "seq", "event_type", "actor_id", "location", "quantity_kg", "reference", "notes",
                "event_time", "data_hash", "tx_hash", "gas_used"]
        self.db.execute(
            f"INSERT INTO trace_events ({', '.join(cols)}) VALUES ({', '.join('?' for _ in cols)})",
            tuple(norm_qty(row[c]) if c == "quantity_kg" else
                  (norm_time(row[c]) if c == "event_time" else row[c]) for c in cols))
