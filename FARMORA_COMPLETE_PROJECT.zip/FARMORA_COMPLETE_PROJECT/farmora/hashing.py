"""Canonical record hashing. The SAME function is used when writing and when verifying,
so a hash only matches the ledger if the database record is byte-for-byte unchanged."""
from __future__ import annotations

import hashlib
import json
from datetime import date, datetime
from decimal import Decimal


def canonical_json(obj) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sha256_hex(obj) -> str:
    """64-character lowercase hex SHA-256 of the canonical JSON of obj."""
    return hashlib.sha256(canonical_json(obj).encode("utf-8")).hexdigest()


def norm_qty(value) -> str:
    """Quantities are compared as fixed 3-decimal strings so Decimal/float/str all agree."""
    if value is None or value == "":
        return "0.000"
    return f"{float(Decimal(str(value))):.3f}"


def norm_time(value) -> str:
    """Datetimes (datetime objects from MySQL or strings from SQLite) -> 'YYYY-MM-DD HH:MM:SS'."""
    if value is None:
        return ""
    if isinstance(value, datetime):
        return value.strftime("%Y-%m-%d %H:%M:%S")
    if isinstance(value, date):
        return value.strftime("%Y-%m-%d 00:00:00")
    text = str(value).strip().replace("T", " ")
    return datetime.fromisoformat(text).strftime("%Y-%m-%d %H:%M:%S")


def batch_record(row: dict) -> dict:
    return {
        "kind": "batch",
        "batch_id": row["batch_id"],
        "product_id": row["product_id"],
        "farmer_id": row["farmer_id"],
        "farm_location": row.get("farm_location") or "",
        "quantity_kg": norm_qty(row["quantity_kg"]),
        "created_at": norm_time(row["created_at"]),
    }


def event_record(row: dict) -> dict:
    return {
        "kind": "event",
        "batch_id": row["batch_id"],
        "seq": int(row["seq"]),
        "event_type": str(row["event_type"]).upper(),
        "actor_id": row["actor_id"],
        "location": row.get("location") or "",
        "quantity_kg": norm_qty(row.get("quantity_kg")),
        "reference": row.get("reference") or "",
        "notes": row.get("notes") or "",
        "event_time": norm_time(row["event_time"]),
    }


def to_bytes32(hex_hash: str) -> bytes:
    h = hex_hash[2:] if hex_hash.startswith("0x") else hex_hash
    b = bytes.fromhex(h)
    if len(b) != 32:
        raise ValueError("hash must be 32 bytes")
    return b


def strip0x(h: str) -> str:
    h = str(h).lower()
    return h[2:] if h.startswith("0x") else h
