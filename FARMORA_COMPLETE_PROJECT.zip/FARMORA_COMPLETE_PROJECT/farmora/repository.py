"""Loads analytics-ready DataFrames from the database."""
from __future__ import annotations

import pandas as pd

from .db import Database


def _num(df: pd.DataFrame, cols) -> pd.DataFrame:
    for c in cols:
        if c in df:
            df[c] = pd.to_numeric(df[c])
    return df


def sales(db: Database) -> pd.DataFrame:
    df = db.df("SELECT sale_date, retailer_id, product_id, qty_kg, price_per_kg, revenue FROM sales_daily")
    df["sale_date"] = pd.to_datetime(df["sale_date"])
    return _num(df, ["qty_kg", "price_per_kg", "revenue"])


def orders(db: Database) -> pd.DataFrame:
    df = db.df("SELECT customer_id, order_date, retailer_id, product_id, qty_kg, amount FROM customer_orders")
    df["order_date"] = pd.to_datetime(df["order_date"])
    return _num(df, ["qty_kg", "amount"])


def inventory(db: Database) -> pd.DataFrame:
    return _num(db.df("SELECT retailer_id, product_id, stock_kg, updated_on FROM inventory"), ["stock_kg"])


def products(db: Database) -> pd.DataFrame:
    return db.df("SELECT * FROM products ORDER BY product_id")


def actors(db: Database) -> pd.DataFrame:
    return db.df("SELECT * FROM actors ORDER BY role, actor_id")


def certifications(db: Database) -> pd.DataFrame:
    df = db.df("SELECT * FROM certifications")
    for c in ("issued_on", "valid_until"):
        df[c] = df[c].astype(str).str[:10]
    return df


def batches(db: Database) -> pd.DataFrame:
    return _num(db.df("SELECT * FROM batches"), ["quantity_kg"])


def events(db: Database) -> pd.DataFrame:
    df = db.df("SELECT * FROM trace_events ORDER BY batch_id, seq")
    return _num(df, ["quantity_kg"])
