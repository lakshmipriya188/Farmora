"""Ledger back-ends.

Web3Ledger   - the real thing: talks to the FarmoraTrace smart contract (Hardhat node or Sepolia).
LocalLedger  - a SIMULATED hash-chained ledger for offline development and automated tests.
               It applies the same rules as the contract but is NOT a blockchain network;
               use Web3Ledger for the demo, report and viva.
"""
from __future__ import annotations

import json
import re
import threading
import time
from pathlib import Path

from .config import Settings, private_keys
from .hashing import sha256_hex, strip0x, to_bytes32
from .rules import EVENT_TYPES, RuleViolation, check_event_allowed


class LedgerError(Exception):
    pass


class LedgerBase:
    name = "base"
    is_real_blockchain = False

    def register_batch(self, batch_id: str, data_hash: str, role: str = "farmer") -> dict: ...
    def add_event(self, batch_id: str, event_type: int, data_hash: str, role: str) -> dict: ...
    def get_batch(self, batch_id: str, with_state: bool = True):  # -> dict | None
        ...
    def get_event(self, batch_id: str, index: int) -> dict: ...
    def info(self) -> dict: ...


# ====================================================================== simulated ledger
class LocalLedger(LedgerBase):
    name = "local-sim"
    is_real_blockchain = False

    def __init__(self, path: str):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self.blocks: list[dict] = []
        self._batches: dict[str, dict] = {}
        self.chain_valid = True
        if self.path.exists():
            self._load()

    @staticmethod
    def _block_hash(block: dict) -> str:
        return "0x" + sha256_hex({k: v for k, v in block.items() if k != "hash"})

    def _load(self) -> None:
        prev = "0x" + "0" * 64
        for line in self.path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            blk = json.loads(line)
            if blk["prev_hash"] != prev or blk["hash"] != self._block_hash(blk):
                self.chain_valid = False
            prev = blk["hash"]
            self.blocks.append(blk)
            self._apply(blk)

    def _apply(self, blk: dict) -> None:
        if blk["kind"] == "register":
            self._batches[blk["batch_id"]] = {
                "creator": blk["role"], "created_at": blk["timestamp"], "data_hash": blk["data_hash"],
                "certified": False, "revoked": False, "last_event": 0, "events": [],
            }
            return
        b = self._batches[blk["batch_id"]]
        et = blk["event_type"]
        if et == EVENT_TYPES["CERTIFIED"]:
            b["certified"] = True
        if et == EVENT_TYPES["REVOKED"]:
            b["revoked"] = True
        else:
            b["last_event"] = et
        b["events"].append({"event_type": et, "actor": blk["role"], "timestamp": blk["timestamp"], "data_hash": blk["data_hash"]})

    def _append(self, block: dict) -> dict:
        prev = self.blocks[-1]["hash"] if self.blocks else "0x" + "0" * 64
        block.update({"height": len(self.blocks) + 1, "timestamp": int(time.time()), "prev_hash": prev})
        block["hash"] = self._block_hash(block)
        with self.path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(block, sort_keys=True) + "\n")
        self.blocks.append(block)
        self._apply(block)
        return {"tx_hash": block["hash"], "gas_used": None, "block": block["height"], "timestamp": block["timestamp"]}

    def register_batch(self, batch_id, data_hash, role="farmer"):
        with self._lock:
            if role != "farmer":
                raise LedgerError("FarmoraTrace: missing role")
            if not batch_id or len(batch_id) > 64:
                raise LedgerError("FarmoraTrace: bad batch id")
            if batch_id in self._batches:
                raise LedgerError("FarmoraTrace: batch exists")
            return self._append({"kind": "register", "batch_id": batch_id, "data_hash": strip0x(data_hash), "role": role})

    def add_event(self, batch_id, event_type, data_hash, role):
        from .rules import EVENT_ROLE

        with self._lock:
            b = self._batches.get(batch_id)
            if b is None:
                raise LedgerError("FarmoraTrace: batch not found")
            if EVENT_ROLE.get(event_type) != role:
                raise LedgerError("FarmoraTrace: missing role for event")
            try:
                check_event_allowed(event_type, b["last_event"], b["certified"], b["revoked"])
            except RuleViolation as exc:
                raise LedgerError(str(exc))
            return self._append({"kind": "event", "batch_id": batch_id, "event_type": event_type,
                                 "data_hash": strip0x(data_hash), "role": role})

    def get_batch(self, batch_id, with_state=True):
        b = self._batches.get(batch_id)
        if b is None:
            return None
        return {"exists": True, "creator": b["creator"], "created_at": b["created_at"], "data_hash": b["data_hash"],
                "certified": b["certified"], "revoked": b["revoked"], "event_count": len(b["events"]),
                "last_event": b["last_event"]}

    def get_event(self, batch_id, index):
        events = self._batches[batch_id]["events"]
        if index >= len(events):
            raise LedgerError("FarmoraTrace: index out of range")
        return dict(events[index])

    def info(self):
        return {"backend": self.name, "real_blockchain": False, "network": "simulated (development only)",
                "blocks": len(self.blocks), "chain_valid": self.chain_valid,
                "total_batches": len(self._batches),
                "total_events": sum(len(b["events"]) for b in self._batches.values()),
                "contract": "n/a"}


# ====================================================================== real blockchain
def _clean_revert(exc: Exception) -> str:
    text = str(exc)
    m = re.search(r"reason string '([^']+)'", text) or re.search(r"revert(?:ed)?:? ([^\n]+)", text)
    return m.group(1).strip() if m else text


class Web3Ledger(LedgerBase):
    name = "web3"
    is_real_blockchain = True

    def __init__(self, rpc_url: str, deployment_file: str, keys: dict | None = None, network: str = ""):
        from web3 import Web3

        self._Web3 = Web3
        self.network = network
        self.w3 = Web3(Web3.HTTPProvider(rpc_url, request_kwargs={"timeout": 30}))
        if not self.w3.is_connected():
            raise LedgerError(
                f"Cannot reach the blockchain node at {rpc_url}. Start it with 'npx hardhat node' (local) "
                "or check WEB3_RPC_URL (Sepolia)."
            )
        path = Path(deployment_file)
        if not path.exists():
            raise LedgerError(f"Deployment file not found: {path}. Run 'npm run deploy:local' in the blockchain folder.")
        dep = json.loads(path.read_text(encoding="utf-8"))
        self.address = Web3.to_checksum_address(dep["address"])
        if not self.w3.eth.get_code(self.address):
            raise LedgerError(
                "No contract found at the saved address. If you restarted the Hardhat node you must deploy again "
                "(npm run deploy:local) and re-seed the database (python -m farmora.cli seed --reset)."
            )
        self.contract = self.w3.eth.contract(address=self.address, abi=dep["abi"])
        self.role_addr = {k: Web3.to_checksum_address(v) for k, v in dep["roleAddresses"].items()}
        self.keys = keys or {}

    # ---------------------------------------------------------------- helpers
    def _key_for(self, role: str, addr: str):
        if role in self.keys:
            return self.keys[role]
        if "admin" in self.keys and addr == self.role_addr.get("admin"):
            return self.keys["admin"]
        return None

    def _send(self, fn, role: str) -> dict:
        addr = self.role_addr.get(role)
        if addr is None:
            raise LedgerError(f"No account configured for role '{role}'")
        key = self._key_for(role, addr)
        try:
            if key:
                tx = fn.build_transaction({"from": addr, "nonce": self.w3.eth.get_transaction_count(addr, "pending")})
                signed = self.w3.eth.account.sign_transaction(tx, key)
                raw = getattr(signed, "raw_transaction", None) or signed.rawTransaction
                tx_hash = self.w3.eth.send_raw_transaction(raw)
            else:
                tx_hash = fn.transact({"from": addr})  # unlocked account on a local Hardhat node
            receipt = self.w3.eth.wait_for_transaction_receipt(tx_hash, timeout=180)
        except Exception as exc:  # contract revert, connection problem, insufficient funds ...
            raise LedgerError(_clean_revert(exc))
        if receipt["status"] != 1:
            raise LedgerError("Transaction reverted")
        block = self.w3.eth.get_block(receipt["blockNumber"])
        h = tx_hash.hex()
        return {"tx_hash": h if h.startswith("0x") else "0x" + h, "gas_used": int(receipt["gasUsed"]),
                "block": int(receipt["blockNumber"]), "timestamp": int(block["timestamp"])}

    @staticmethod
    def _hex(value) -> str:
        h = value.hex() if isinstance(value, (bytes, bytearray)) else str(value)
        return strip0x(h)

    # ---------------------------------------------------------------- writes
    def register_batch(self, batch_id, data_hash, role="farmer"):
        return self._send(self.contract.functions.registerBatch(batch_id, to_bytes32(data_hash)), role)

    def add_event(self, batch_id, event_type, data_hash, role):
        return self._send(self.contract.functions.addEvent(batch_id, int(event_type), to_bytes32(data_hash)), role)

    # ---------------------------------------------------------------- reads
    def get_batch(self, batch_id, with_state=True):
        exists, creator, created_at, data_hash, certified, revoked, count = self.contract.functions.getBatch(batch_id).call()
        if not exists:
            return None
        last = 0
        if count and with_state:
            last = self.get_event(batch_id, count - 1)["event_type"]
            # REVOKED does not move the "last event" pointer in the contract.
            if last == EVENT_TYPES["REVOKED"]:
                for i in range(count - 2, -1, -1):
                    t = self.get_event(batch_id, i)["event_type"]
                    if t != EVENT_TYPES["REVOKED"]:
                        last = t
                        break
        return {"exists": True, "creator": creator, "created_at": int(created_at), "data_hash": self._hex(data_hash),
                "certified": bool(certified), "revoked": bool(revoked), "event_count": int(count), "last_event": last}

    def get_event(self, batch_id, index):
        et, actor, ts, data_hash = self.contract.functions.getEvent(batch_id, int(index)).call()
        return {"event_type": int(et), "actor": actor, "timestamp": int(ts), "data_hash": self._hex(data_hash)}

    def info(self):
        c = self.contract.functions
        return {"backend": self.name, "real_blockchain": True, "network": self.network or "unknown",
                "chain_id": int(self.w3.eth.chain_id), "block_number": int(self.w3.eth.block_number),
                "contract": self.address, "total_batches": int(c.totalBatches().call()),
                "total_events": int(c.totalEvents().call())}


# ====================================================================== factory
def get_ledger(settings: Settings) -> LedgerBase:
    if settings.ledger_backend == "web3":
        deployment = Path(settings.deployments_dir) / f"{settings.network}.json"
        return Web3Ledger(settings.rpc_url, str(deployment), keys=private_keys(), network=settings.network)
    if settings.ledger_backend == "local":
        return LocalLedger(settings.local_ledger_path)
    raise LedgerError("LEDGER_BACKEND must be 'web3' or 'local'")
