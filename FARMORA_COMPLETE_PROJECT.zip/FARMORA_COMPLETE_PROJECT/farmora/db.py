"""Database access layer. MySQL is the project database; SQLite is supported for zero-setup runs/tests.
SQL in the code base uses '?' placeholders, converted to '%s' for MySQL."""
from __future__ import annotations

import sqlite3
import threading
from pathlib import Path

import pandas as pd

from .config import Settings

SCHEMA = [
    """CREATE TABLE IF NOT EXISTS actors (
        actor_id VARCHAR(32) PRIMARY KEY,
        name VARCHAR(120) NOT NULL,
        role VARCHAR(20) NOT NULL,
        organization VARCHAR(120),
        location VARCHAR(120),
        created_at DATETIME NOT NULL
    )""",
    """CREATE TABLE IF NOT EXISTS users (
        user_id {PK},
        username VARCHAR(40) NOT NULL UNIQUE,
        pw_hash VARCHAR(128) NOT NULL,
        salt VARCHAR(32) NOT NULL,
        role VARCHAR(20) NOT NULL,
        full_name VARCHAR(80),
        phone VARCHAR(20),
        address VARCHAR(250),
        actor_id VARCHAR(32),
        active INT NOT NULL DEFAULT 1,
        created_at DATETIME NOT NULL
    )""",
    """CREATE TABLE IF NOT EXISTS categories (
        category_id VARCHAR(32) PRIMARY KEY,
        name VARCHAR(60) NOT NULL UNIQUE,
        description VARCHAR(200)
    )""",
    """CREATE TABLE IF NOT EXISTS products (
        product_id VARCHAR(16) PRIMARY KEY,
        name VARCHAR(80) NOT NULL,
        category VARCHAR(40) NOT NULL,
        shelf_life_days INT NOT NULL,
        emoji VARCHAR(16) DEFAULT '🌿',
        image_url VARCHAR(200) DEFAULT '',
        mrp_per_kg DECIMAL(10,2) DEFAULT 0.0,
        price_per_kg DECIMAL(10,2) DEFAULT 0.0,
        unit_label VARCHAR(20) DEFAULT 'kg',
        active INT NOT NULL DEFAULT 1
    )""",
    """CREATE TABLE IF NOT EXISTS product_prices (
        product_id VARCHAR(16) PRIMARY KEY,
        price_per_kg DECIMAL(10,2) NOT NULL,
        active INT NOT NULL DEFAULT 1
    )""",
    """CREATE TABLE IF NOT EXISTS certifications (
        cert_id VARCHAR(40) PRIMARY KEY,
        farmer_id VARCHAR(32) NOT NULL,
        standard VARCHAR(40) NOT NULL,
        issued_on DATE NOT NULL,
        valid_until DATE NOT NULL,
        status VARCHAR(12) NOT NULL,
        FOREIGN KEY (farmer_id) REFERENCES actors(actor_id)
    )""",
    """CREATE TABLE IF NOT EXISTS batches (
        batch_id VARCHAR(64) PRIMARY KEY,
        product_id VARCHAR(16) NOT NULL,
        farmer_id VARCHAR(32) NOT NULL,
        farm_location VARCHAR(120),
        quantity_kg DECIMAL(12,3) NOT NULL,
        created_at DATETIME NOT NULL,
        data_hash CHAR(64) NOT NULL,
        tx_hash VARCHAR(80),
        gas_used INT,
        FOREIGN KEY (product_id) REFERENCES products(product_id),
        FOREIGN KEY (farmer_id) REFERENCES actors(actor_id)
    )""",
    """CREATE TABLE IF NOT EXISTS trace_events (
        id {PK},
        batch_id VARCHAR(64) NOT NULL,
        seq INT NOT NULL,
        event_type VARCHAR(20) NOT NULL,
        actor_id VARCHAR(32) NOT NULL,
        location VARCHAR(120),
        quantity_kg DECIMAL(12,3),
        reference VARCHAR(64),
        notes TEXT,
        event_time DATETIME NOT NULL,
        data_hash CHAR(64) NOT NULL,
        tx_hash VARCHAR(80),
        gas_used INT,
        UNIQUE (batch_id, seq),
        FOREIGN KEY (batch_id) REFERENCES batches(batch_id),
        FOREIGN KEY (actor_id) REFERENCES actors(actor_id)
    )""",
    """CREATE TABLE IF NOT EXISTS sales_daily (
        id {PK},
        sale_date DATE NOT NULL,
        retailer_id VARCHAR(32) NOT NULL,
        product_id VARCHAR(16) NOT NULL,
        qty_kg DECIMAL(12,3) NOT NULL,
        price_per_kg DECIMAL(10,2) NOT NULL,
        revenue DECIMAL(14,2) NOT NULL,
        UNIQUE (sale_date, retailer_id, product_id)
    )""",
    """CREATE TABLE IF NOT EXISTS customer_orders (
        order_id {PK},
        customer_id VARCHAR(20) NOT NULL,
        order_date DATE NOT NULL,
        retailer_id VARCHAR(32) NOT NULL,
        product_id VARCHAR(16) NOT NULL,
        qty_kg DECIMAL(10,3) NOT NULL,
        amount DECIMAL(12,2) NOT NULL
    )""",
    """CREATE TABLE IF NOT EXISTS inventory (
        retailer_id VARCHAR(32) NOT NULL,
        product_id VARCHAR(16) NOT NULL,
        stock_kg DECIMAL(12,3) NOT NULL,
        updated_on DATE NOT NULL,
        PRIMARY KEY (retailer_id, product_id)
    )""",
    """CREATE TABLE IF NOT EXISTS store_orders (
        order_id {PK},
        customer_id VARCHAR(32) NOT NULL,
        user_id INT,
        retailer_id VARCHAR(32) NOT NULL,
        status VARCHAR(30) NOT NULL,
        payment_mode VARCHAR(20) NOT NULL,
        payment_status VARCHAR(20) NOT NULL,
        total DECIMAL(12,2) NOT NULL,
        customer_name VARCHAR(80),
        phone VARCHAR(20),
        address VARCHAR(250),
        order_date DATE NOT NULL,
        placed_at DATETIME NOT NULL
    )""",
    """CREATE TABLE IF NOT EXISTS store_order_items (
        id {PK},
        order_id INT NOT NULL,
        product_id VARCHAR(16) NOT NULL,
        product_name VARCHAR(80) NOT NULL,
        selected_weight INT NOT NULL DEFAULT 500,
        qty INT NOT NULL DEFAULT 1,
        qty_kg DECIMAL(10,3) NOT NULL,
        unit_price DECIMAL(10,2) NOT NULL,
        line_total DECIMAL(12,2) NOT NULL
    )""",
    """CREATE TABLE IF NOT EXISTS blockchain_transactions (
        id {PK},
        tx_hash VARCHAR(80) NOT NULL,
        batch_id VARCHAR(64) NOT NULL,
        event_type VARCHAR(30) NOT NULL,
        actor_id VARCHAR(32) NOT NULL,
        gas_used INT,
        block_number INT,
        network VARCHAR(32),
        created_at DATETIME NOT NULL
    )""",
]

INDEXES = [
    "CREATE INDEX idx_events_batch ON trace_events (batch_id)",
    "CREATE INDEX idx_batches_farmer ON batches (farmer_id)",
    "CREATE INDEX idx_sales_date ON sales_daily (sale_date)",
    "CREATE INDEX idx_orders_customer ON customer_orders (customer_id)",
    "CREATE INDEX idx_store_orders_user ON store_orders (user_id)",
    "CREATE INDEX idx_store_orders_customer ON store_orders (customer_id)",
    "CREATE INDEX idx_store_order_items_order ON store_order_items (order_id)",
    "CREATE INDEX idx_users_username ON users (username)",
]

DROP_ORDER = [
    "blockchain_transactions", "store_order_items", "store_orders",
    "trace_events", "batches", "certifications", "customer_orders",
    "sales_daily", "inventory", "product_prices", "products", "categories", "users", "actors",
]


class Database:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.backend = settings.db_backend.lower()
        if self.backend not in ("mysql", "sqlite"):
            raise ValueError("DB_BACKEND must be 'mysql' or 'sqlite'")
        self._lock = threading.RLock()
        self._conn = None
        self._connect()

    # ------------------------------------------------------------------ connection
    def _connect(self) -> None:
        s = self.settings
        if self.backend == "mysql":
            import mysql.connector  # pip install mysql-connector-python

            boot = mysql.connector.connect(host=s.db_host, port=s.db_port, user=s.db_user, password=s.db_password)
            cur = boot.cursor()
            cur.execute(f"CREATE DATABASE IF NOT EXISTS `{s.db_name}` CHARACTER SET utf8mb4")
            boot.commit()
            cur.close()
            boot.close()
            self._conn = mysql.connector.connect(
                host=s.db_host, port=s.db_port, user=s.db_user, password=s.db_password, database=s.db_name
            )
        else:
            Path(s.sqlite_path).parent.mkdir(parents=True, exist_ok=True)
            self._conn = sqlite3.connect(s.sqlite_path, check_same_thread=False)
            self._conn.execute("PRAGMA foreign_keys=ON")

    def _ensure_alive(self) -> None:
        if self.backend == "mysql":
            self._conn.ping(reconnect=True, attempts=3, delay=1)

    def close(self) -> None:
        with self._lock:
            if self._conn is not None:
                self._conn.close()
                self._conn = None

    def _ph(self, sql: str) -> str:
        return sql.replace("?", "%s") if self.backend == "mysql" else sql

    # ------------------------------------------------------------------ execution
    def _run(self, sql, params=(), many=False, fetch=False):
        with self._lock:
            self._ensure_alive()
            cur = self._conn.cursor()
            try:
                if many:
                    cur.executemany(self._ph(sql), params)
                else:
                    cur.execute(self._ph(sql), params)
                rows = cols = None
                if fetch:
                    cols = [d[0] for d in cur.description]
                    rows = cur.fetchall()
                self._conn.commit()
                return rows, cols, cur.lastrowid
            except Exception:
                self._conn.rollback()
                raise
            finally:
                cur.close()

    def execute(self, sql: str, params=()):
        return self._run(sql, params)[2]

    def executemany(self, sql: str, rows) -> None:
        rows = list(rows)
        if rows:
            self._run(sql, rows, many=True)

    def query(self, sql: str, params=()) -> list[dict]:
        rows, cols, _ = self._run(sql, params, fetch=True)
        return [dict(zip(cols, r)) for r in rows]

    def one(self, sql: str, params=()):
        res = self.query(sql, params)
        return res[0] if res else None

    def scalar(self, sql: str, params=()):
        rows, _, _ = self._run(sql, params, fetch=True)
        return rows[0][0] if rows else None

    def df(self, sql: str, params=()) -> pd.DataFrame:
        rows, cols, _ = self._run(sql, params, fetch=True)
        return pd.DataFrame(rows, columns=cols)

    # ------------------------------------------------------------------ schema
    def init_schema(self) -> None:
        pk = "INT AUTO_INCREMENT PRIMARY KEY" if self.backend == "mysql" else "INTEGER PRIMARY KEY AUTOINCREMENT"
        for stmt in SCHEMA:
            self.execute(stmt.replace("{PK}", pk))
        for stmt in INDEXES:
            try:
                self.execute(stmt)
            except Exception:
                pass  # index already exists
        # Ensure products table has all extended columns if table already existed
        for col_name, col_def in [
            ("emoji", "VARCHAR(16) DEFAULT '🌿'"),
            ("image_url", "VARCHAR(200) DEFAULT ''"),
            ("mrp_per_kg", "DECIMAL(10,2) DEFAULT 0.0"),
            ("price_per_kg", "DECIMAL(10,2) DEFAULT 0.0"),
            ("unit_label", "VARCHAR(20) DEFAULT 'kg'"),
            ("active", "INT NOT NULL DEFAULT 1"),
        ]:
            try:
                self.execute(f"ALTER TABLE products ADD COLUMN {col_name} {col_def}")
            except Exception:
                pass

    def reset(self) -> None:
        if self.backend == "mysql":
            self.execute("SET FOREIGN_KEY_CHECKS=0")
        for table in DROP_ORDER:
            self.execute(f"DROP TABLE IF EXISTS {table}")
        if self.backend == "mysql":
            self.execute("SET FOREIGN_KEY_CHECKS=1")
        self.init_schema()
