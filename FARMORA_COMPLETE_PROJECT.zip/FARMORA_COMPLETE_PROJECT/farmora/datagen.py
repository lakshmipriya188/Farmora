"""Synthetic data generator. Real organic supply-chain data is not publicly available, so FARMORA is
demonstrated on realistic SYNTHETIC data. Supply-chain batches are written through the real service
layer, so every event is hashed and recorded on the ledger exactly like live data."""
from __future__ import annotations

import csv
from datetime import date, datetime, timedelta
from pathlib import Path

import numpy as np

from .analytics import festival_flag
from .config import ROOT
from .db import Database
from .services import FarmoraService, TraceError

import pandas as pd

# id, name, category, shelf_life_days, kg/day per retailer, price/kg (INR), seasonal amplitude, peak day-of-year, festive uplift, yearly growth, mrp, emoji, image_name
PRODUCTS = [
    ("P01", "Organic Tomato", "Vegetables", 7, 14, 80, 0.20, 40, 1.05, 0.05, 95, "🍅", "Tomato.png"),
    ("P02", "Organic Spinach", "Vegetables", 4, 8, 60, 0.15, 30, 1.00, 0.08, 70, "🥬", "Spinach.png"),
    ("P03", "Organic Banana", "Fruits", 6, 12, 70, 0.10, 150, 1.15, 0.02, 80, "🍌", "Banana.png"),
    ("P04", "Organic Mango", "Fruits", 8, 10, 160, 0.90, 140, 1.00, 0.04, 190, "🥭", "Mango.png"),
    ("P05", "Organic Ragi", "Millets", 365, 6, 75, 0.08, 20, 1.10, 0.18, 85, "🌾", "BrownTop_Millets.png"),
    ("P06", "Organic Sona Masuri Rice", "Grains", 365, 18, 85, 0.05, 300, 1.25, 0.03, 95, "🍚", "Brown_Rice.png"),
    ("P07", "Organic Turmeric Powder", "Spices", 540, 2, 320, 0.10, 330, 1.20, 0.10, 360, "🧂", "Turmeric_Powder.png"),
    ("P08", "Organic Jaggery", "Sweeteners", 365, 5, 110, 0.25, 320, 1.45, 0.06, 125, "🍯", ""),
    ("P09", "Organic Honey", "Sweeteners", 730, 3, 520, 0.12, 100, 1.30, 0.12, 580, "🍯", ""),
    ("P10", "Cold-pressed Coconut Oil", "Oils", 365, 4, 450, 0.06, 330, 1.35, -0.04, 500, "🥥", "Coconut_Oil.png"),
    ("P11", "Organic Carrot", "Vegetables", 10, 9, 65, 0.15, 50, 1.05, 0.06, 75, "🥕", "Carrot.png"),
    ("P12", "Organic Guava", "Fruits", 7, 7, 90, 0.25, 200, 1.10, 0.03, 105, "🍈", "Guava.png"),
    ("P13", "Organic Green Gram (Moong)", "Pulses", 365, 5, 140, 0.05, 280, 1.15, 0.05, 160, "🫘", "Chickpeas.png"),
    ("P14", "Organic Toor Dal", "Pulses", 365, 7, 150, 0.05, 290, 1.20, 0.04, 170, "🫘", "Toor_Dal.png"),
    ("P15", "Organic A2 Ghee", "Dairy", 180, 4, 950, 0.10, 310, 1.30, 0.08, 1050, "🧈", "Butter.png"),
]

FARMERS = [
    ("FM01", "Ramesh Gowda", "Mandya"), ("FM02", "Lakshmi Devi", "Mysuru"), ("FM03", "Suresh Naik", "Hassan"),
    ("FM04", "Kavitha Reddy", "Kolar"), ("FM05", "Manjunath Hegde", "Chikkamagaluru"), ("FM06", "Savitha Patil", "Belagavi"),
    ("FM07", "Basavaraj Kumar", "Tumakuru"), ("FM08", "Anitha Shetty", "Udupi"), ("FM09", "Prakash Rao", "Shivamogga"),
    ("FM10", "Geetha Murthy", "Chamarajanagar"), ("FM11", "Venkatesh Gowda", "Ramanagara"), ("FM12", "Nagaraj Bhat", "Kodagu"),
]
PROCESSORS = [("PR01", "Green Valley Processing", "Mysuru"), ("PR02", "Sahyadri Agro Foods", "Hassan"), ("PR03", "Malnad Organic Packers", "Shivamogga")]
DISTRIBUTORS = [("DS01", "Karnataka Cold Chain Logistics", "Bengaluru"), ("DS02", "Southern Fresh Transport", "Bengaluru")]
RETAILERS = [("RT01", "Farmora Partner Store Indiranagar", "Indiranagar, Bengaluru", 1.4),
             ("RT02", "Farmora Partner Store Koramangala", "Koramangala, Bengaluru", 1.1),
             ("RT03", "Farmora Partner Store Jayanagar", "Jayanagar, Bengaluru", 1.0),
             ("RT04", "Farmora Partner Store Whitefield", "Whitefield, Bengaluru", 0.8),
             ("RT05", "Farmora Partner Store Malleshwaram", "Malleshwaram, Bengaluru", 0.7)]
CERTIFIER = ("CB01", "Demo Organic Certification Body", "Bengaluru")

WEEKDAY = np.array([0.85, 0.85, 0.90, 0.95, 1.10, 1.35, 1.30])  # Mon..Sun
PRACTICES = ["Compost and vermiwash, neem-based pest control", "Green manure and crop rotation", "Cow-dung manure, no synthetic inputs",
             "Mulching and drip irrigation, bio-pesticide only", "Jeevamrutha applied, mixed cropping"]
SOLD_NOTES = ["Counter sales", "Weekend market sales", "Online order fulfilment"]


def _d(x) -> str:
    return x.strftime("%Y-%m-%d")


def _dt(x: datetime) -> str:
    return x.strftime("%Y-%m-%d %H:%M:%S")


def seed_master_data(svc: FarmoraService, end: date) -> None:
    db = svc.db
    # Categories
    categories = sorted({p[2] for p in PRODUCTS})
    for cat in categories:
        cid = f"CAT_{cat.upper()[:4]}"
        if not db.one("SELECT category_id FROM categories WHERE category_id = ?", (cid,)):
            db.execute("INSERT INTO categories (category_id, name, description) VALUES (?,?,?)",
                       (cid, cat, f"Certified organic {cat.lower()}"))

    # Products & Prices
    for p in PRODUCTS:
        pid, name, cat, shelf, base_kg, price, amp, peak, uplift, growth, mrp, emoji, img = p
        db.execute(
            "INSERT INTO products (product_id, name, category, shelf_life_days, emoji, image_url, mrp_per_kg, price_per_kg, unit_label, active) "
            "VALUES (?,?,?,?,?,?,?,?,?,?)",
            (pid, name, cat, int(shelf), emoji, img, float(mrp), float(price), "kg", 1)
        )
        db.execute(
            "INSERT INTO product_prices (product_id, price_per_kg, active) VALUES (?,?,?)",
            (pid, float(price), 1)
        )

    for aid, name, loc in FARMERS:
        svc.add_actor(aid, name, "farmer", f"{name} Organic Farm", f"{loc}, Karnataka")
    for aid, name, loc in PROCESSORS:
        svc.add_actor(aid, name, "processor", name, loc)
    for aid, name, loc in DISTRIBUTORS:
        svc.add_actor(aid, name, "distributor", name, loc)
    for aid, name, loc, _ in RETAILERS:
        svc.add_actor(aid, name, "retailer", name, loc)
    svc.add_actor(*CERTIFIER[:1], CERTIFIER[1], "certifier", CERTIFIER[1], CERTIFIER[2])

    for i, (fid, _, _) in enumerate(FARMERS):
        if i in (10,):
            issued, valid = end - timedelta(days=1200), end - timedelta(days=60)
        elif i in (11,):
            issued, valid = end - timedelta(days=1090), end - timedelta(days=10)
        elif i in (8, 9):
            issued, valid = end - timedelta(days=1060), end + timedelta(days=20 + 10 * (i - 8))
        else:
            issued, valid = end - timedelta(days=400 + 40 * i), end + timedelta(days=700 - 20 * i)
        svc.issue_certification(fid, "NPOP (organic)", _d(issued), _d(valid))

    from . import auth
    auth.ensure_defaults(db)


def seed_sales(db: Database, end: date, days: int, rng: np.random.Generator) -> list[dict]:
    """Daily sales per retailer and product with trend, annual + weekly seasonality, festive uplift and injected anomalies."""
    dates = pd.date_range(end - timedelta(days=days - 1), end, freq="D")
    doy = dates.dayofyear.values.astype(float)
    wk = WEEKDAY[dates.dayofweek.values]
    fest = festival_flag(dates)
    rows, grid = [], {}
    for p in PRODUCTS:
        pid, _, _, _, base, price, amp, peak, uplift, growth = p[:10]
        season = 1 + amp * np.cos(2 * np.pi * (doy - peak) / 365.25)
        trend = 1 + growth * (np.arange(days) / 365.0)
        festive = 1 + (uplift - 1) * fest
        for rid, _, _, scale in RETAILERS:
            noise = rng.lognormal(0, 0.12, days)
            q = np.clip(base * scale * season * trend * festive * wk * noise, 0.2, None)
            p_val = price * (1 + 0.04 * (np.arange(days) / 365.0)) * rng.lognormal(0, 0.02, days)
            grid[(pid, rid)] = [q, p_val]
    # Inject anomalies (recorded so detection accuracy can be measured).
    keys = list(grid)
    injected = []
    for kind, n, mult in (("Spike", 14, 3.8), ("Drop", 10, 0.08)):
        for _ in range(n):
            pid, rid = keys[rng.integers(len(keys))]
            i = int(rng.integers(40, days - 20))
            grid[(pid, rid)][0][i] *= mult
            injected.append({"sale_date": _d(dates[i]), "retailer_id": rid, "product_id": pid, "type": kind})
    for (pid, rid), (q, p_val) in grid.items():
        for i in range(days):
            rows.append((_d(dates[i]), rid, pid, round(float(q[i]), 3), round(float(p_val[i]), 2), round(float(q[i] * p_val[i]), 2)))
    db.executemany("INSERT INTO sales_daily (sale_date, retailer_id, product_id, qty_kg, price_per_kg, revenue) VALUES (?,?,?,?,?,?)", rows)
    # Current stock levels, deliberately mixed (critical / low / ok / overstock).
    inv = []
    for p in PRODUCTS:
        pid, base = p[0], p[4]
        for rid, _, _, scale in RETAILERS:
            cover = float(rng.choice([rng.uniform(1, 3), rng.uniform(3, 7), rng.uniform(8, 25), rng.uniform(35, 60)], p=[.1, .15, .6, .15]))
            inv.append((rid, pid, round(base * scale * cover, 3), _d(end)))
    db.executemany("INSERT INTO inventory (retailer_id, product_id, stock_kg, updated_on) VALUES (?,?,?,?)", inv)
    return injected


def seed_customers(db: Database, end: date, rng: np.random.Generator, n_customers: int = 400) -> int:
    price = {p[0]: p[5] for p in PRODUCTS}
    kinds = rng.choice(["heavy", "regular", "occasional", "lapsed"], size=n_customers, p=[0.12, 0.30, 0.38, 0.20])
    rate = {"heavy": 8.0, "regular": 3.0, "occasional": 1.0, "lapsed": 2.5}
    qmul = {"heavy": 1.8, "regular": 1.2, "occasional": 0.9, "lapsed": 1.0}
    rows = []
    for c in range(n_customers):
        kind = str(kinds[c])
        active_days = 365 if kind != "lapsed" else 365 - int(rng.integers(130, 220))
        n = int(rng.poisson(rate[kind] * active_days / 30.0))
        home = RETAILERS[int(rng.integers(len(RETAILERS)))][0]
        favourites = list(rng.choice([p[0] for p in PRODUCTS], size=int(rng.integers(2, 5)), replace=False))
        for _ in range(n):
            # Lapsed customers were active early in the year and then stopped ordering.
            day = end - timedelta(days=365 - int(rng.integers(0, active_days)))
            rid = home if rng.random() < 0.7 else RETAILERS[int(rng.integers(len(RETAILERS)))][0]
            for pid in rng.choice(favourites, size=int(rng.integers(1, 3)), replace=False):
                qty = float(np.clip(rng.lognormal(0.1, 0.5) * qmul[kind], 0.25, 12))
                rows.append((f"C{c + 1:04d}", _d(day), rid, str(pid), round(qty, 3), round(qty * price[str(pid)], 2)))
    db.executemany("INSERT INTO customer_orders (customer_id, order_date, retailer_id, product_id, qty_kg, amount) VALUES (?,?,?,?,?,?)", rows)
    return len(rows)


ANOMALY_MODES = ["overyield", "heavy_loss", "slow_transit", "time_disorder", "expired_cert", "oversell"]


def seed_batches(svc: FarmoraService, end: date, n_batches: int, rng: np.random.Generator, progress=None) -> dict:
    """Creates supply-chain batches with full lifecycles through the real service/ledger path."""
    certs = {r["farmer_id"]: r["cert_id"] for r in svc.db.query("SELECT cert_id, farmer_id FROM certifications ORDER BY cert_id")}
    good_farmers = [f[0] for f in FARMERS[:10]]
    prod_by_id = {p[0]: p for p in PRODUCTS}
    end_dt = datetime(end.year, end.month, end.day, 18, 0, 0)
    stages = ["harvested", "certified", "processed", "shipped", "received", "sold"]
    stage_p = [0.06, 0.06, 0.08, 0.10, 0.15, 0.55]
    n_anom = max(2, round(n_batches * 0.12))
    anomaly_slots = set(rng.choice(n_batches, size=min(n_anom, n_batches), replace=False).tolist())
    revoked_slots = set(rng.choice([i for i in range(n_batches) if i not in anomaly_slots], size=min(2, max(0, n_batches - n_anom)), replace=False).tolist()) if n_batches > n_anom else set()
    mode_i, made, anomalies, ev_count = 0, 0, [], 0

    for i in range(n_batches):
        anomaly = ANOMALY_MODES[mode_i % len(ANOMALY_MODES)] if i in anomaly_slots else None
        if anomaly:
            mode_i += 1
        farmer = FARMERS[10][0] if anomaly == "expired_cert" else str(rng.choice(good_farmers))
        pid = str(rng.choice([p[0] for p in PRODUCTS]))
        product = prod_by_id[pid]
        shelf = product[3]
        stage = "sold" if anomaly else str(rng.choice(stages, p=stage_p))
        revoke = i in revoked_slots
        if revoke:
            stage = "received"
        stage_idx = stages.index(stage)

        q0 = float(rng.uniform(200, 2000))
        harvest_gap = float(rng.uniform(20, 90))  # days from cultivation to harvest
        t = {}
        offs = {"cult": 0.0, "harv": harvest_gap, "cert": harvest_gap + rng.uniform(1, 4), "proc": 0, "ship": 0, "recv": 0}
        offs["proc"] = offs["cert"] + rng.uniform(0.5, 3)
        offs["ship"] = offs["proc"] + rng.uniform(0.5, 2)
        transit = rng.uniform(0.5, 2.0) if anomaly != "slow_transit" else max(shelf * 0.8, 5) + rng.uniform(0, 3)
        offs["recv"] = offs["ship"] + transit
        sold_start = offs["recv"] + rng.uniform(1, 4)
        last = sold_start + 8
        base = end_dt - timedelta(days=float(last + rng.uniform(1, 25)))  # cultivation start
        for k, v in offs.items():
            t[k] = base + timedelta(days=float(v), hours=float(rng.uniform(-3, 3)))
        t["cult"] = base
        if t["recv"] + timedelta(days=1) > end_dt:  # keep everything in the past
            delta = t["recv"] + timedelta(days=12) - end_dt
            for k in t:
                t[k] -= delta

        yield_r = float(rng.uniform(0.86, 0.97))
        loss_r = float(rng.uniform(0.96, 0.995))
        q_proc, q_ship = q0 * yield_r, q0 * yield_r * 0.995
        q_recv = q_ship * loss_r
        if anomaly == "overyield":
            q_proc = q0 * float(rng.uniform(1.12, 1.35)); q_ship = q_proc * 0.99; q_recv = q_ship * 0.97
        if anomaly == "heavy_loss":
            q_recv = q_ship * float(rng.uniform(0.45, 0.62))
        if anomaly == "time_disorder":
            t["proc"] = t["harv"] - timedelta(days=2)
        cert_ref = certs[farmer]

        try:
            b = svc.register_batch(farmer, pid, round(q0, 1), created_at=_dt(t["cult"]))
            bid = b["batch_id"]
            ev = lambda et, actor, q, when, **kw: svc.add_event(bid, et, actor, q, event_time=_dt(when), strict_cert=False, **kw)
            ev("CULTIVATED", farmer, round(q0, 1), t["cult"], notes=str(rng.choice(PRACTICES)))
            ev("HARVESTED", farmer, round(q0, 1), t["harv"], notes="Hand harvested, field-graded")
            n_ev = 2
            if stage_idx >= 1:
                ev("CERTIFIED", CERTIFIER[0], 0, t["cert"], reference=cert_ref, notes="Farm and batch inspection passed"); n_ev += 1
            if stage_idx >= 2:
                pr = str(rng.choice([p[0] for p in PROCESSORS]))
                ev("PROCESSED", pr, round(q_proc, 1), t["proc"], notes="Cleaned, graded and packed"); n_ev += 1
            if stage_idx >= 3:
                ds = str(rng.choice([d[0] for d in DISTRIBUTORS]))
                ev("SHIPPED", ds, round(q_ship, 1), t["ship"], reference=f"KA-{int(rng.integers(1, 60)):02d}-{chr(65 + int(rng.integers(26)))}{chr(65 + int(rng.integers(26)))}-{int(rng.integers(1000, 9999))}",
                   notes="Cold chain 8 C" if shelf <= 10 else "Ambient transport"); n_ev += 1
            rt = str(rng.choice([r[0] for r in RETAILERS]))
            if stage_idx >= 4:
                ev("RECEIVED", rt, round(q_recv, 1), t["recv"], notes="Received in good condition"); n_ev += 1
            if stage_idx >= 5:
                total = q_recv * float(rng.uniform(0.75, 0.98))
                if anomaly == "oversell":
                    total = q_recv * float(rng.uniform(1.10, 1.30))
                parts = int(rng.integers(1, 4))
                for j in range(parts):
                    ev("SOLD", rt, round(total / parts, 1), min(t["recv"] + timedelta(days=2 + 2 * j), end_dt), notes=str(rng.choice(SOLD_NOTES))); n_ev += 1
            if revoke:
                svc.add_event(bid, "REVOKED", CERTIFIER[0], 0, notes="Residue test failed - certificate withdrawn (demo)",
                              event_time=_dt(min(t["recv"] + timedelta(days=1), end_dt)), strict_cert=False); n_ev += 1
            made += 1
            ev_count += n_ev
            if anomaly:
                anomalies.append({"batch_id": bid, "mode": anomaly})
        except TraceError as exc:
            raise RuntimeError(f"Seeding failed on batch {i}: {exc}")
        if progress:
            progress(i + 1, n_batches)
    return {"batches": made, "events": ev_count, "injected_batch_anomalies": anomalies}


def seed_all(svc: FarmoraService, n_batches: int = 60, days: int = 540, seed: int = 42, end: date | None = None, progress=None,
             label_dir: Path | None = None) -> dict:
    """label_dir: where the CSV files listing injected anomalies are written (default: <project>/data)."""
    end = end or date.today()
    rng = np.random.default_rng(seed)
    seed_master_data(svc, end)
    injected = seed_sales(svc.db, end, days, rng)
    orders = seed_customers(svc.db, end, rng)
    bsum = seed_batches(svc, end, n_batches, rng, progress)
    out_dir = Path(label_dir) if label_dir else ROOT / "data"
    out_dir.mkdir(parents=True, exist_ok=True)
    with (out_dir / "injected_sales_anomalies.csv").open("w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=["sale_date", "retailer_id", "product_id", "type"])
        w.writeheader(); w.writerows(injected)
    with (out_dir / "injected_batch_anomalies.csv").open("w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=["batch_id", "mode"])
        w.writeheader(); w.writerows(bsum["injected_batch_anomalies"])
    return {"sales_rows": days * len(PRODUCTS) * len(RETAILERS), "orders": orders, "injected_sales_anomalies": len(injected),
            "label_dir": str(out_dir), **bsum}
