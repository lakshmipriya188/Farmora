"""Authentication, password security (PBKDF2-HMAC-SHA256) and Role-Based Access Control."""
from __future__ import annotations

import hashlib
import hmac
import os
from datetime import datetime

import streamlit as st

ROLES = ("admin", "manager", "farmer", "customer", "certifier", "processor", "distributor", "retailer", "guest")

# Navigation permissions per role
PAGES_BY_ROLE = {
    "admin": [
        "Overview", "Sales & customers", "Demand forecast",
        "Store", "Manage items", "Orders", "Inventory management",
        "Record data", "Farmer portal", "Inventory & compliance", "Verify a product",
        "Blockchain traceability", "Integrity audit", "Anomalies",
        "Users & access", "My profile", "About"
    ],
    "manager": [
        "Store", "Orders", "Manage items", "Inventory management",
        "Inventory & compliance", "Sales & customers", "Verify a product", "My profile", "About"
    ],
    "farmer": [
        "Farmer portal", "Verify a product", "My profile", "About"
    ],
    "customer": [
        "Store", "My orders", "Verify a product", "My profile", "About"
    ],
    "certifier": [
        "Record data", "Inventory & compliance", "Verify a product", "My profile", "About"
    ],
    "processor": [
        "Record data", "Verify a product", "My profile", "About"
    ],
    "distributor": [
        "Record data", "Verify a product", "My profile", "About"
    ],
    "retailer": [
        "Orders", "Inventory management", "Record data", "Verify a product", "My profile", "About"
    ],
    "guest": [
        "Verify a product"
    ],
}


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _hash(pw: str, salt: str) -> str:
    return hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"), bytes.fromhex(salt), 120_000).hex()


def create_user(db, username: str, password: str, role: str, full_name: str = "",
                phone: str = "", address: str = "", actor_id: str | None = None) -> int:
    username = username.strip().lower()
    if role not in ROLES:
        raise ValueError(f"Unknown role '{role}'")
    if len(username) < 3:
        raise ValueError("Username must be at least 3 characters long")
    if len(password) < 6:
        raise ValueError("Password must be at least 6 characters long")
    if db.one("SELECT user_id FROM users WHERE username = ?", (username,)):
        raise ValueError(f"Username '{username}' is already taken")

    salt = os.urandom(16).hex()
    pw_hash = _hash(password, salt)
    return db.execute(
        "INSERT INTO users (username, pw_hash, salt, role, full_name, phone, address, actor_id, active, created_at) "
        "VALUES (?,?,?,?,?,?,?,?,?,?)",
        (username, pw_hash, salt, role, full_name.strip(), phone.strip(), address.strip(), actor_id, 1, _now())
    )


def set_password(db, user_id: int, password: str) -> None:
    if len(password) < 6:
        raise ValueError("Password must be at least 6 characters long")
    salt = os.urandom(16).hex()
    pw_hash = _hash(password, salt)
    db.execute("UPDATE users SET pw_hash = ?, salt = ? WHERE user_id = ?", (pw_hash, salt, user_id))


def update_profile(db, user_id: int, full_name: str, phone: str, address: str) -> None:
    db.execute(
        "UPDATE users SET full_name = ?, phone = ?, address = ? WHERE user_id = ?",
        (full_name.strip(), phone.strip(), address.strip(), user_id)
    )


def check_login(db, username: str, password: str) -> dict | None:
    u = db.one("SELECT * FROM users WHERE username = ?", (username.strip().lower(),))
    if not u or not int(u["active"]):
        return None
    computed = _hash(password, u["salt"])
    if not hmac.compare_digest(computed, u["pw_hash"]):
        return None
    return {
        "user_id": u["user_id"],
        "username": u["username"],
        "role": u["role"],
        "full_name": u["full_name"],
        "phone": u["phone"],
        "address": u["address"],
        "actor_id": u["actor_id"],
    }


def ensure_defaults(db) -> None:
    """Creates safe demonstration accounts if users table is empty."""
    if db.scalar("SELECT COUNT(*) FROM users"):
        return
    create_user(db, "admin", "admin123", "admin", "Platform Administrator", "9900112233", "FARMORA Central Office, Bengaluru")
    store = db.one("SELECT actor_id, name FROM actors WHERE role = 'retailer' ORDER BY actor_id LIMIT 1")
    farmer = db.one("SELECT actor_id, name FROM actors WHERE role = 'farmer' ORDER BY actor_id LIMIT 1")
    if store:
        create_user(db, "manager1", "manager123", "manager", f"Store Manager, {store['name']}",
                    "9845012345", store.get("location", "Bengaluru"), actor_id=store["actor_id"])
    if farmer:
        create_user(db, "farmer1", "farmer123", "farmer", farmer["name"],
                    "9880011223", farmer.get("location", "Mandya"), actor_id=farmer["actor_id"])
    create_user(db, "customer1", "customer123", "customer", "Demo Customer",
                "9876543210", "12 MG Road, Bengaluru 560001")


def allowed_pages(role: str) -> list[str]:
    return PAGES_BY_ROLE.get(role, PAGES_BY_ROLE["guest"])


def gate(svc) -> dict:
    db = svc.db
    if not st.session_state.get("fm_schema_ready"):
        db.init_schema()
        ensure_defaults(db)
        st.session_state["fm_schema_ready"] = True

    user = st.session_state.get("fm_user")
    if user:
        return user

    # Public QR Code Verification bypass: consumers can scan QR without creating an account
    qp = st.query_params
    if "batch" in qp or "batch_id" in qp:
        return {"role": "guest", "username": "guest", "full_name": "Public Guest", "actor_id": None, "user_id": 0}

    # Brand Login / Signup View
    c1, c2, c3 = st.columns([1, 2, 1])
    with c2:
        st.markdown(
            """
            <div style="text-align:center; padding: 20px 0 10px;">
                <span style="font-size: 3.5rem;">🌿</span>
                <h1 style="color:#0f5c3a; margin: 4px 0 0; font-family:'Poppins',sans-serif; font-weight:800;">FARMORA</h1>
                <p style="color:#4b6354; font-size:1.05rem; margin-top:2px;">
                    Blockchain-Verified Organic Farm-to-Consumer Platform
                </p>
            </div>
            """,
            unsafe_allow_html=True,
        )

        tab_login, tab_signup = st.tabs(["🔐 Log In", "📝 New Customer? Sign Up"])

        with tab_login:
            with st.form("fm_login_form"):
                username = st.text_input("Username", placeholder="e.g. admin or customer1")
                password = st.text_input("Password", type="password", placeholder="Enter your password")
                submitted = st.form_submit_button("Sign In to FARMORA", use_container_width=True)
                if submitted:
                    found = check_login(db, username, password)
                    if found:
                        st.session_state["fm_user"] = found
                        st.session_state.pop("page", None)
                        st.success(f"Welcome back, {found.get('full_name') or found['username']}!")
                        st.rerun()
                    else:
                        st.error("Invalid username or password, or your account has been disabled.")

        with tab_signup:
            with st.form("fm_signup_form"):
                full_name = st.text_input("Full Name", placeholder="Your full name")
                phone = st.text_input("Phone Number", placeholder="10-digit mobile number")
                address = st.text_area("Delivery Address", placeholder="Apartment, Street, Area, Pincode")
                un = st.text_input("Choose Username", placeholder="At least 3 characters")
                pw = st.text_input("Choose Password", type="password", placeholder="At least 6 characters")
                signup_btn = st.form_submit_button("Create Customer Account", use_container_width=True)
                if signup_btn:
                    try:
                        create_user(db, un, pw, "customer", full_name, phone, address)
                        st.success("✅ Account created successfully! Switch to the 'Log In' tab to sign in.")
                    except ValueError as exc:
                        st.error(str(exc))

        with st.expander("🔑 Viva Demo Accounts (Click to view test credentials)"):
            st.markdown(
                """
                | Role | Username | Password | Access Rights |
                |---|---|---|---|
                | **Admin** | `admin` | `admin123` | Full Platform & Blockchain Access |
                | **Store Manager** | `manager1` | `manager123` | Orders, Inventory & Storefront |
                | **Organic Farmer** | `farmer1` | `farmer123` | Farm Batches, Harvest & Certs |
                | **Customer** | `customer1` | `customer123` | Organic Store, Cart & My Orders |
                """
            )

    st.stop()


def logout_button(user: dict) -> None:
    st.sidebar.divider()
    role_badges = {
        "admin": "👑 Administrator",
        "manager": "🏬 Store Manager",
        "farmer": "👨‍🌾 Organic Farmer",
        "customer": "🛒 Customer",
        "certifier": "📜 Certifier",
        "processor": "⚙️ Processor",
        "distributor": "🚚 Distributor",
        "retailer": "🏪 Retailer",
        "guest": "👤 Guest",
    }
    st.sidebar.markdown(
        f"""
        <div style="background:rgba(15,92,58,0.08); border: 1px solid rgba(15,92,58,0.2); border-radius:10px; padding:10px; margin-bottom:8px;">
            <div style="font-weight:700; color:#0f5c3a; font-size:0.95rem;">{user.get('full_name') or user['username']}</div>
            <div style="font-size:0.8rem; color:#4a6354;">{role_badges.get(user['role'], user['role'].title())}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )
    if user["role"] != "guest":
        if st.sidebar.button("🚪 Log Out", use_container_width=True):
            for key in ("fm_user", "fm_cart", "page", "data_version"):
                st.session_state.pop(key, None)
            st.rerun()
