"""Command line tools:  python -m farmora.cli <command>

  status            show configuration and ledger health
  init [--reset]    create (or recreate) the database tables
  seed              fill the database with synthetic data and record batches on the ledger
  verify            verify every batch against the ledger
  demo              scripted end-to-end run: record -> verify -> tamper -> detect -> restore
  evaluate          measure forecast accuracy and anomaly-detection recall (numbers for the report)
"""
from __future__ import annotations

import argparse
import sys
import time

from .config import Settings
from .db import Database
from .ledger import LedgerError, get_ledger
from .services import FarmoraService


def build_service(settings: Settings | None = None) -> FarmoraService:
    settings = settings or Settings.from_env()
    db = Database(settings)
    db.init_schema()
    return FarmoraService(db, get_ledger(settings), settings)


def _progress(label):
    state = {"t": time.time()}

    def cb(i, n):
        if i == n or time.time() - state["t"] > 1.0:
            print(f"\r{label}: {i}/{n}", end="", flush=True)
            state["t"] = time.time()
        if i == n:
            print()
    return cb


def cmd_status(args):
    s = Settings.from_env()
    print(f"Database : {s.db_backend}" + (f" ({s.db_host}:{s.db_port}/{s.db_name})" if s.db_backend == "mysql" else f" ({s.sqlite_path})"))
    print(f"Ledger   : {s.ledger_backend}")
    svc = build_service(s)
    for k, v in svc.ledger.info().items():
        print(f"  {k}: {v}")
    print(f"Batches in DB: {svc.db.scalar('SELECT COUNT(*) FROM batches')}")


def cmd_init(args):
    s = Settings.from_env()
    db = Database(s)
    if args.reset:
        db.reset()
        print("Database reset.")
    else:
        db.init_schema()
        print("Database tables ready.")


def cmd_seed(args):
    from .datagen import seed_all

    s = Settings.from_env()
    db = Database(s)
    if args.reset:
        db.reset()
    else:
        db.init_schema()
    if db.scalar("SELECT COUNT(*) FROM actors"):
        print("Database already contains data. Use --reset to start again (and redeploy the contract / delete the local ledger).")
        sys.exit(1)
    svc = FarmoraService(db, get_ledger(s), s)
    started = time.time()
    summary = seed_all(svc, n_batches=args.batches, days=args.days, seed=args.seed, progress=_progress("Recording batches on ledger"))
    print(f"Done in {time.time() - started:.1f}s: {summary['batches']} batches, {summary['events']} ledger events, "
          f"{summary['sales_rows']} daily sales rows, {summary['orders']} customer order lines.")


def cmd_verify(args):
    svc = build_service()
    df = svc.verify_all(progress=_progress("Verifying"))
    bad = df[df["status"] != "VERIFIED"]
    print(f"{len(df) - len(bad)}/{len(df)} batches verified.")
    for _, r in bad.iterrows():
        print(f"  ! {r['batch_id']}: {r['issues']}")
    sys.exit(1 if len(bad) else 0)


def cmd_demo(args):
    svc = build_service()
    farmers = svc.list_actors("farmer")
    if farmers.empty:
        print("No data. Run: python -m farmora.cli seed")
        sys.exit(1)
    fid = farmers.iloc[0]["actor_id"]
    cert = svc.db.one("SELECT cert_id FROM certifications WHERE farmer_id = ?", (fid,))["cert_id"]
    pid = svc.list_products().iloc[0]["product_id"]
    proc = svc.list_actors("processor").iloc[0]["actor_id"]
    dist = svc.list_actors("distributor").iloc[0]["actor_id"]
    ret = svc.list_actors("retailer").iloc[0]["actor_id"]
    cb = svc.list_actors("certifier").iloc[0]["actor_id"]

    print("1. Registering a batch and recording its lifecycle ...")
    b = svc.register_batch(fid, pid, 500.0)
    bid = b["batch_id"]
    steps = [("CULTIVATED", fid, 500, {}), ("HARVESTED", fid, 500, {}), ("CERTIFIED", cb, 0, {"reference": cert}),
             ("PROCESSED", proc, 470, {}), ("SHIPPED", dist, 468, {}), ("RECEIVED", ret, 460, {}), ("SOLD", ret, 300, {})]
    for et, actor, q, kw in steps:
        e = svc.add_event(bid, et, actor, q, **kw)
        print(f"   {et:<10} tx={str(e['tx_hash'])[:18]}... gas={e['gas_used']}")
    print(f"2. Verifying {bid}: ", "VERIFIED" if svc.verify_batch(bid)["ok"] else "PROBLEM")
    print("3. Tampering: changing the PROCESSED quantity directly in the database (470 -> 900 kg) ...")
    old = svc.tamper_event(bid, 3, "quantity_kg", 900)
    r = svc.verify_batch(bid)
    print("4. Verifying again:", "VERIFIED" if r["ok"] else "TAMPERING DETECTED")
    for issue in r["issues"]:
        print("   -", issue)
    svc.restore_event(bid, 3, "quantity_kg", old)
    print("5. Restored original value:", "VERIFIED" if svc.verify_batch(bid)["ok"] else "STILL BROKEN")
    print(f"Batch id: {bid}")


def cmd_evaluate(args):
    import warnings

    import pandas as pd

    from . import analytics as an
    from . import repository as repo
    from .config import ROOT

    warnings.filterwarnings("ignore")
    svc = build_service()
    sales, rep = an.clean_sales(repo.sales(svc.db))
    prods = repo.products(svc.db)
    print(f"Cleaning: {rep}\n\nDEMAND FORECASTING (28-day holdout)")
    rows = []
    for _, p in prods.iterrows():
        res = an.forecast_series(an.daily_series(sales, p["product_id"]))
        m = res["metrics"].set_index("model")
        rows.append({"product": p["name"], "best_model": res["best_model"], "best_MAPE_%": round(m.iloc[0]["MAPE %"], 1),
                     "naive_MAPE_%": round(m.loc["Seasonal naive (weekday mean)", "MAPE %"], 1),
                     "RMSE_gain_vs_naive_%": round(res["improvement_vs_naive_pct"], 1)})
    print(pd.DataFrame(rows).to_string(index=False))

    print("\nSALES ANOMALY DETECTION")
    det = an.detect_sales_anomalies(sales)
    path = ROOT / "data" / "injected_sales_anomalies.csv"
    if path.exists():
        inj = pd.read_csv(path, parse_dates=["sale_date"])
        hit = inj.merge(det, on=["sale_date", "retailer_id", "product_id"], how="left", indicator=True)["_merge"].eq("both").sum()
        fp = len(det) - hit
        print(f"injected={len(inj)} detected={hit} recall={hit / len(inj):.0%} false_alarms={fp}")

    print("\nBATCH ANOMALY DETECTION")
    feats = an.batch_features(repo.batches(svc.db), repo.events(svc.db), prods, repo.certifications(svc.db))
    flagged = an.detect_batch_anomalies(feats)
    path = ROOT / "data" / "injected_batch_anomalies.csv"
    if path.exists():
        inj = pd.read_csv(path)
        hit = inj["batch_id"].isin(flagged["batch_id"]).sum()
        print(f"batches={len(feats)} injected={len(inj)} flagged_total={len(flagged)} injected_found={hit} recall={hit / max(len(inj), 1):.0%}")

    print("\nLEDGER")
    df = svc.verify_all()
    print(f"verified {int((df['status'] == 'VERIFIED').sum())}/{len(df)} batches")
    gas = pd.to_numeric(svc.db.df("SELECT gas_used FROM trace_events")["gas_used"], errors="coerce").dropna()
    if len(gas):
        print(f"gas per event: mean={gas.mean():,.0f} min={gas.min():,.0f} max={gas.max():,.0f}")
    else:
        print("gas per event: n/a on the simulated ledger (use LEDGER_BACKEND=web3 for real gas figures)")


def main(argv=None):
    p = argparse.ArgumentParser(prog="farmora")
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("status").set_defaults(fn=cmd_status)
    i = sub.add_parser("init"); i.add_argument("--reset", action="store_true"); i.set_defaults(fn=cmd_init)
    s = sub.add_parser("seed")
    s.add_argument("--batches", type=int, default=60)
    s.add_argument("--days", type=int, default=540)
    s.add_argument("--seed", type=int, default=42)
    s.add_argument("--reset", action="store_true")
    s.set_defaults(fn=cmd_seed)
    sub.add_parser("verify").set_defaults(fn=cmd_verify)
    sub.add_parser("demo").set_defaults(fn=cmd_demo)
    sub.add_parser("evaluate").set_defaults(fn=cmd_evaluate)
    args = p.parse_args(argv)
    try:
        args.fn(args)
    except LedgerError as exc:
        print(f"Ledger error: {exc}")
        sys.exit(2)


if __name__ == "__main__":
    main()
