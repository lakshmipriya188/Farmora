"""Role portals: My Orders (Customer), Orders Management (Admin/Manager), Manage Items,
Farmer Portal, Users & Access Management, and My Profile."""
from __future__ import annotations

from datetime import date, datetime
import pandas as pd
import streamlit as st

from . import auth

ORDER_STATUSES = [
    "Pending", "Confirmed", "Processing", "Packed",
    "Shipped", "Out for Delivery", "Delivered", "Cancelled"
]


def _now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# ------------------------------------------------------------------ Orders Helper
def list_orders(db, user_id=None, retailer_id=None) -> list[dict]:
    where, params = [], []
    if user_id is not None:
        where.append("o.user_id = ?")
        params.append(user_id)
    if retailer_id is not None:
        where.append("o.retailer_id = ?")
        params.append(retailer_id)

    query = (
        "SELECT o.*, COALESCE(u.full_name, o.customer_name) AS customer, "
        "COALESCE(u.phone, o.phone) AS phone_no, a.name AS store_name "
        "FROM store_orders o "
        "LEFT JOIN users u ON u.user_id = o.user_id "
        "LEFT JOIN actors a ON a.actor_id = o.retailer_id"
    )
    if where:
        query += " WHERE " + " AND ".join(where)
    query += " ORDER BY o.order_id DESC LIMIT 300"

    orders = db.query(query, tuple(params))
    if orders:
        oids = [o["order_id"] for o in orders]
        placeholders = ",".join("?" for _ in oids)
        items = db.query(
            f"SELECT i.*, p.category FROM store_order_items i "
            f"LEFT JOIN products p ON p.product_id = i.product_id "
            f"WHERE i.order_id IN ({placeholders})",
            tuple(oids),
        )
        for o in orders:
            o["items"] = [i for i in items if i["order_id"] == o["order_id"]]
    return orders


def update_order_status(db, order_id: int, new_status: str) -> str | None:
    order = db.one("SELECT * FROM store_orders WHERE order_id = ?", (order_id,))
    if not order:
        return "Order not found."
    current = order["status"]
    if current in ("Delivered", "Cancelled"):
        return f"Order #{order_id} is already marked as {current.lower()}."

    pay_status = order["payment_status"]
    if new_status == "Delivered":
        pay_status = "Paid (COD)"
    elif new_status == "Cancelled":
        pay_status = "Cancelled"
        # Replenish stock in inventory
        items = db.query("SELECT product_id, qty_kg FROM store_order_items WHERE order_id = ?", (order_id,))
        for it in items:
            db.execute(
                "UPDATE inventory SET stock_kg = stock_kg + ?, updated_on = ? "
                "WHERE retailer_id = ? AND product_id = ?",
                (float(it["qty_kg"]), str(date.today()), order["retailer_id"], it["product_id"]),
            )

    db.execute(
        "UPDATE store_orders SET status = ?, payment_status = ? WHERE order_id = ?",
        (new_status, pay_status, order_id),
    )
    return None


# ------------------------------------------------------------------ Customer: My Orders
def page_my_orders(svc, user: dict):
    st.title("📦 My Orders")
    st.caption("Track your organic grocery orders from farm packaging to your doorstep.")

    orders = list_orders(svc.db, user_id=user["user_id"])
    if not orders:
        st.info("You haven't placed any orders yet. Visit the **Store** to order fresh organic produce!")
        return

    status_colors = {
        "Pending": "orange", "Placed": "orange", "Confirmed": "blue",
        "Processing": "blue", "Packed": "violet", "Shipped": "violet",
        "Out for Delivery": "orange", "Delivered": "green", "Cancelled": "red"
    }

    for o in orders:
        badge_color = status_colors.get(o["status"], "gray")
        header = f"Order #{o['order_id']} · :{badge_color}[{o['status']}] · ₹{float(o['total']):.0f} · {str(o['placed_at'])[:16]}"
        with st.expander(header, expanded=(o["status"] not in ("Delivered", "Cancelled"))):
            st.markdown(f"**Delivering Store**: {o.get('store_name') or o['retailer_id']}")
            st.markdown(f"**Delivery Address**: {o.get('address') or 'N/A'}")
            st.markdown(f"**Payment**: {o.get('payment_mode', 'COD')} ({o.get('payment_status', 'Pending')})")

            st.markdown("##### Order Items")
            lines_data = []
            for item in o.get("items", []):
                lines_data.append({
                    "Product": item["product_name"],
                    "Weight": f"{item['selected_weight']} g",
                    "Quantity": item["qty"],
                    "Unit Price": f"₹{float(item['unit_price']):.0f}",
                    "Total": f"₹{float(item['line_total']):.0f}",
                })
            st.dataframe(pd.DataFrame(lines_data), hide_index=True)

            # Cancel order button if pending/placed
            if o["status"] in ("Placed", "Pending", "Confirmed"):
                if st.button(f"Cancel Order #{o['order_id']}", key=f"cancel_ord_{o['order_id']}"):
                    err = update_order_status(svc.db, o["order_id"], "Cancelled")
                    if err:
                        st.error(err)
                    else:
                        st.success(f"Order #{o['order_id']} cancelled. Reserved stock released.")
                        st.rerun()


# ------------------------------------------------------------------ Admin & Manager: Orders
def page_orders(svc, refresh, user: dict):
    st.title("📋 Order Management")
    st.caption("Manage, track, and update fulfillment statuses for all customer orders.")

    store_filter = user["actor_id"] if user["role"] == "manager" else None
    orders = list_orders(svc.db, retailer_id=store_filter)
    if not orders:
        st.info("No orders found in the database.")
        return

    c1, c2 = st.columns([3, 2])
    with c1:
        f_status = st.multiselect(
            "Filter by Status",
            ORDER_STATUSES,
            default=["Pending", "Confirmed", "Processing", "Packed", "Shipped", "Out for Delivery"],
        )
    with c2:
        search = st.text_input("Search Customer or Order #", placeholder="Filter by customer name, phone, or ID")

    shown = [o for o in orders if o["status"] in f_status]
    if search.strip():
        s = search.lower().strip()
        shown = [
            o for o in shown
            if s in str(o["order_id"]) or s in str(o.get("customer", "")).lower() or s in str(o.get("phone_no", "")).lower()
        ]

    st.subheader(f"Matching Orders ({len(shown)})")
    if shown:
        table_rows = []
        for o in shown:
            table_rows.append({
                "Order #": o["order_id"],
                "Customer": o.get("customer") or "Customer",
                "Phone": o.get("phone_no") or "N/A",
                "Store": o.get("store_name") or o["retailer_id"],
                "Total Amount": f"₹{float(o['total']):.0f}",
                "Payment": f"{o['payment_mode']} ({o['payment_status']})",
                "Status": o["status"],
                "Placed At": str(o["placed_at"])[:16],
            })
        st.dataframe(pd.DataFrame(table_rows), hide_index=True)

        st.divider()
        st.subheader("Update Order Status")
        with st.form("fm_update_order_status"):
            u1, u2 = st.columns(2)
            pick_id = u1.selectbox("Select Order", [o["order_id"] for o in shown], format_func=lambda i: f"Order #{i}")
            new_st = u2.selectbox("Set New Status", ORDER_STATUSES)
            submit_upd = st.form_submit_button("Update Status", use_container_width=True)

        if submit_upd:
            err = update_order_status(svc.db, pick_id, new_st)
            if err:
                st.error(err)
            else:
                refresh()
                st.success(f"Order #{pick_id} status updated to **{new_st}**.")
                st.rerun()


# ------------------------------------------------------------------ Admin & Manager: Manage Items
def page_manage_items(svc, refresh, user: dict):
    st.title("🛒 Manage Store Items")
    st.caption("Update product pricing, add new organic inventory items, and adjust store stock levels.")

    db = svc.db
    tab_prices, tab_add, tab_stock = st.tabs(["🏷 Pricing & Availability", "➕ Add New Product", "📦 Store Stock"])

    # Tab 1: Prices & Availability
    with tab_prices:
        rows = db.query(
            "SELECT p.product_id, p.name, p.category, "
            "COALESCE(pp.price_per_kg, p.price_per_kg, 80.0) AS price_per_kg, "
            "COALESCE(p.mrp_per_kg, p.price_per_kg * 1.15, 95.0) AS mrp_per_kg, "
            "COALESCE(pp.active, p.active, 1) AS on_sale "
            "FROM products p "
            "LEFT JOIN product_prices pp ON pp.product_id = p.product_id "
            "ORDER BY p.category, p.name"
        )
        df = pd.DataFrame([
            {
                "product_id": r["product_id"],
                "name": r["name"],
                "category": r["category"],
                "price_per_kg": float(r["price_per_kg"]),
                "mrp_per_kg": float(r["mrp_per_kg"]),
                "on_sale": bool(int(r["on_sale"])),
            }
            for r in rows
        ])
        ed = st.data_editor(df, hide_index=True, disabled=["product_id", "name", "category"], key="prod_price_editor")
        if st.button("💾 Save Pricing Changes"):
            for _, r in ed.iterrows():
                pid = r["product_id"]
                price = round(float(r["price_per_kg"]), 2)
                mrp = round(float(r["mrp_per_kg"]), 2)
                active = 1 if r["on_sale"] else 0
                db.execute(
                    "UPDATE products SET price_per_kg = ?, mrp_per_kg = ?, active = ? WHERE product_id = ?",
                    (price, mrp, active, pid),
                )
                if db.one("SELECT product_id FROM product_prices WHERE product_id = ?", (pid,)):
                    db.execute(
                        "UPDATE product_prices SET price_per_kg = ?, active = ? WHERE product_id = ?",
                        (price, active, pid),
                    )
                else:
                    db.execute(
                        "INSERT INTO product_prices (product_id, price_per_kg, active) VALUES (?,?,?)",
                        (pid, price, active),
                    )
            refresh()
            st.success("✅ Changes saved! The Store is now updated with the latest prices.")

    # Tab 2: Add Product
    with tab_add:
        with st.form("fm_add_product_form"):
            p_name = st.text_input("Product Name", placeholder="e.g. Organic Pomegranate")
            p_cat = st.selectbox(
                "Category",
                ["Vegetables", "Fruits", "Grains", "Millets", "Pulses", "Spices", "Sweeteners", "Oils", "Dairy", "Beverages"],
            )
            p_shelf = st.number_input("Shelf Life (days)", min_value=1, max_value=730, value=7)
            p_price = st.number_input("Selling Price per kg (₹)", min_value=1.0, max_value=10000.0, value=90.0)
            p_mrp = st.number_input("MRP per kg (₹)", min_value=1.0, max_value=10000.0, value=110.0)
            p_emoji = st.text_input("Display Emoji", value="🌿")
            submit_add = st.form_submit_button("Add Product to Catalog")

        if submit_add:
            if not p_name.strip():
                st.error("Product name is required.")
            else:
                n = int(db.scalar("SELECT COUNT(*) FROM products") or 0) + 1
                while db.one("SELECT product_id FROM products WHERE product_id = ?", (f"P{n:02d}",)):
                    n += 1
                pid = f"P{n:02d}"
                db.execute(
                    "INSERT INTO products (product_id, name, category, shelf_life_days, emoji, mrp_per_kg, price_per_kg, unit_label, active) "
                    "VALUES (?,?,?,?,?,?,?,?,?)",
                    (pid, p_name.strip(), p_cat.strip(), int(p_shelf), p_emoji.strip(), float(p_mrp), float(p_price), "kg", 1),
                )
                db.execute(
                    "INSERT INTO product_prices (product_id, price_per_kg, active) VALUES (?,?,?)",
                    (pid, float(p_price), 1),
                )
                refresh()
                st.success(f"✅ Product **{p_name}** added with ID `{pid}`! You can now allocate stock in the 'Store Stock' tab.")

    # Tab 3: Store Stock
    with tab_stock:
        stores = db.query("SELECT actor_id, name, location FROM actors WHERE role = 'retailer' ORDER BY name")
        if user["role"] == "manager":
            stores = [s for s in stores if s["actor_id"] == user.get("actor_id")]
        if not stores:
            st.info("No stores linked to this account.")
            return

        store = st.selectbox("Select Store", stores, format_func=lambda s: f"{s['actor_id']} - {s['name']}")
        inv_df = db.df(
            "SELECT i.product_id, p.name, p.category, i.stock_kg, i.updated_on "
            "FROM inventory i JOIN products p ON p.product_id = i.product_id "
            "WHERE i.retailer_id = ? ORDER BY p.name",
            (store["actor_id"],),
        )
        st.subheader(f"Current Inventory at {store['name']}")
        st.dataframe(inv_df, hide_index=True)

        st.divider()
        st.subheader("Update Stock Level")
        prods = db.query("SELECT product_id, name FROM products ORDER BY name")
        with st.form("fm_update_stock_form"):
            picked_prod = st.selectbox("Product", prods, format_func=lambda p: f"{p['product_id']} - {p['name']}")
            new_kg = st.number_input("Set Stock (kg)", min_value=0.0, max_value=50000.0, value=50.0, step=5.0)
            submit_stock = st.form_submit_button("Update Stock")

        if submit_stock:
            if db.one("SELECT 1 FROM inventory WHERE retailer_id = ? AND product_id = ?", (store["actor_id"], picked_prod["product_id"])):
                db.execute(
                    "UPDATE inventory SET stock_kg = ?, updated_on = ? WHERE retailer_id = ? AND product_id = ?",
                    (float(new_kg), str(date.today()), store["actor_id"], picked_prod["product_id"]),
                )
            else:
                db.execute(
                    "INSERT INTO inventory (retailer_id, product_id, stock_kg, updated_on) VALUES (?,?,?,?)",
                    (store["actor_id"], picked_prod["product_id"], float(new_kg), str(date.today())),
                )
            refresh()
            st.success(f"Stock for {picked_prod['name']} updated to {new_kg} kg at {store['name']}.")
            st.rerun()


# ------------------------------------------------------------------ Farmer Portal
def page_farmer(svc, refresh, user: dict):
    st.title("🌾 Organic Farmer Portal")
    fid = user.get("actor_id")
    db = svc.db

    # If admin viewing farmer portal without linked farm, allow picking a farmer
    if not fid and user.get("role") == "admin":
        farmers = db.query("SELECT actor_id, name, location FROM actors WHERE role = 'farmer' ORDER BY actor_id")
        if farmers:
            picked = st.selectbox("Viewing farm on behalf of:", farmers, format_func=lambda f: f"{f['actor_id']} - {f['name']} ({f['location']})")
            fid = picked["actor_id"]

    if not fid:
        st.warning("This account is not linked to an organic farm. Please ask the administrator to link your profile.")
        return

    farmer = svc.get_actor(fid)
    if farmer:
        st.markdown(
            f"""
            <div style="background:#e6fcf5; border:1px solid #b2f2bb; border-radius:12px; padding:14px 18px; margin-bottom:14px;">
                <h3 style="margin:0; color:#0f5c3a;">🏡 {farmer['name']} Organic Farm</h3>
                <p style="margin:4px 0 0; color:#2b4334;"><b>Location:</b> {farmer['location']} | <b>Actor ID:</b> <code>{fid}</code></p>
            </div>
            """,
            unsafe_allow_html=True,
        )

    tab_batches, tab_reg, tab_event = st.tabs(["🌾 My Harvest Batches & Certs", "📝 Register New Harvest Batch", "🚜 Record Farm Event"])

    mine_batches = db.df(
        "SELECT b.batch_id, p.name AS product, b.quantity_kg, b.created_at, b.tx_hash "
        "FROM batches b JOIN products p ON p.product_id = b.product_id "
        "WHERE b.farmer_id = ? ORDER BY b.created_at DESC",
        (fid,),
    )

    with tab_batches:
        certs = db.df("SELECT cert_id, standard, issued_on, valid_until, status FROM certifications WHERE farmer_id = ?", (fid,))
        st.subheader("📜 Organic Certifications")
        if certs.empty:
            st.info("No active certifications on record. Contact an accredited certifier.")
        else:
            st.dataframe(certs, hide_index=True)

        st.divider()
        st.subheader("📦 Registered Harvest Batches")
        if mine_batches.empty:
            st.info("No batches registered yet. Switch to the 'Register New Harvest Batch' tab to add your first harvest.")
        else:
            st.dataframe(mine_batches, hide_index=True)

    with tab_reg:
        st.subheader("Register Organic Batch on Blockchain")
        prods = db.query("SELECT product_id, name FROM products ORDER BY name")
        with st.form("fm_farmer_batch_form"):
            picked_prod = st.selectbox("Product", prods, format_func=lambda p: p["name"])
            qty_kg = st.number_input("Harvest Quantity (kg)", min_value=1.0, max_value=50000.0, value=250.0, step=10.0)
            farm_loc = st.text_input("Farm Field Location", value=farmer.get("location") or "")
            submit_reg = st.form_submit_button("Register Batch on Blockchain Ledger")

        if submit_reg:
            try:
                b = svc.register_batch(fid, picked_prod["product_id"], qty_kg, farm_loc or None)
                refresh()
                st.success(f"✅ Batch `{b['batch_id']}` registered on the blockchain ledger!")
                st.image(svc.qr_png(b["batch_id"]), caption=f"Batch QR: {b['batch_id']}", width=160)
            except Exception as exc:
                st.error(f"Registration failed: {exc}")

    with tab_event:
        st.subheader("Record Farm Cultivation & Harvest Events")
        if mine_batches.empty:
            st.info("Register a batch first before recording farm lifecycle events.")
            return

        batch_id_pick = st.selectbox("Select Batch", mine_batches["batch_id"])
        try:
            allowed = [e for e in svc.batch_state(batch_id_pick)["next_events"] if e in ("CULTIVATED", "HARVESTED")]
        except Exception as exc:
            st.error(f"Cannot load batch state: {exc}")
            return

        if not allowed:
            st.info("Farm-level events (Cultivated & Harvested) are already completed for this batch. Next stages belong to Certifier and Processor.")
        else:
            with st.form("fm_farmer_event_form"):
                ev_type = st.selectbox("Event Type", allowed)
                ev_qty = st.number_input("Recorded Quantity (kg)", min_value=0.0, max_value=50000.0, value=float(qty_kg if 'qty_kg' in locals() else 100.0))
                ev_notes = st.text_area("Agricultural Notes (compost, irrigation, pest management)", placeholder="e.g. Organic Jeevamrutha applied, no chemical fertilizers used.")
                submit_ev = st.form_submit_button("Record Event on Blockchain")

            if submit_ev:
                try:
                    svc.add_event(batch_id_pick, ev_type, fid, ev_qty, farmer.get("location"), ev_notes)
                    refresh()
                    st.success(f"✅ **{ev_type}** successfully written to blockchain ledger with cryptographic proof!")
                    st.rerun()
                except Exception as exc:
                    st.error(f"Could not record event: {exc}")


# ------------------------------------------------------------------ Admin: Users & Access
def page_users(svc, refresh):
    st.title("👥 Users & Access Control")
    st.caption("Manage platform user credentials, role permissions, and linked entities.")

    db = svc.db
    users_df = db.df(
        "SELECT user_id, username, role, full_name, phone, address, actor_id, active, created_at "
        "FROM users ORDER BY role, username"
    )
    st.subheader(f"Registered User Accounts ({len(users_df)})")
    st.dataframe(users_df, hide_index=True)

    c1, c2 = st.columns(2)
    with c1:
        st.subheader("➕ Create New Account")
        with st.form("fm_create_user_admin"):
            un = st.text_input("Username", placeholder="e.g. farmer2")
            pw = st.text_input("Password", type="password", placeholder="At least 6 characters")
            role = st.selectbox("Role", ["admin", "manager", "farmer", "customer", "certifier", "processor", "distributor", "retailer"])
            fn = st.text_input("Full Name")
            ph = st.text_input("Phone Number")
            addr = st.text_input("Address")

            # Link to actor
            role_actor_map = {"farmer": "farmer", "manager": "retailer", "retailer": "retailer",
                              "processor": "processor", "distributor": "distributor", "certifier": "certifier"}
            needed_actor_role = role_actor_map.get(role)
            acts = db.query("SELECT actor_id, name, location FROM actors WHERE role = ? ORDER BY actor_id", (needed_actor_role,)) if needed_actor_role else []
            act = st.selectbox("Linked Entity", [None] + acts, format_func=lambda a: "-" if a is None else f"{a['actor_id']} - {a['name']}")

            submit_create = st.form_submit_button("Create User Account", use_container_width=True)

        if submit_create:
            try:
                auth.create_user(db, un, pw, role, fn, ph, addr, act["actor_id"] if act else None)
                refresh()
                st.success(f"User account `{un}` created successfully!")
                st.rerun()
            except ValueError as exc:
                st.error(str(exc))

    with c2:
        st.subheader("⚙️ Account Controls & Password Reset")
        if not users_df.empty:
            with st.form("fm_edit_user_admin"):
                pick_uid = st.selectbox("Select User", users_df["user_id"], format_func=lambda i: users_df.set_index("user_id").loc[i, "username"])
                new_pw = st.text_input("Reset Password (leave empty to keep current)", type="password")
                is_active = st.checkbox("Account Active", value=True)
                submit_edit = st.form_submit_button("Apply User Changes", use_container_width=True)

            if submit_edit:
                try:
                    if new_pw:
                        auth.set_password(db, int(pick_uid), new_pw)
                    db.execute("UPDATE users SET active = ? WHERE user_id = ?", (int(is_active), int(pick_uid)))
                    refresh()
                    st.success("User account settings updated successfully.")
                    st.rerun()
                except ValueError as exc:
                    st.error(str(exc))


# ------------------------------------------------------------------ My Profile Page
def page_my_profile(svc, user: dict):
    st.title("👤 My Profile")
    st.caption("View and update your personal account information and security settings.")

    db = svc.db
    u = db.one("SELECT * FROM users WHERE user_id = ?", (user["user_id"],)) or user

    st.markdown(
        f"""
        <div style="background:#f4fbf6; border:1px solid #c3edd5; border-radius:12px; padding:16px 20px; margin-bottom:16px;">
            <h3 style="margin:0; color:#0f5c3a;">{u.get('full_name') or u['username']}</h3>
            <p style="margin:4px 0 0; color:#3a5845;"><b>Role:</b> {u['role'].title()} | <b>Username:</b> <code>{u['username']}</code> | <b>Joined:</b> {str(u.get('created_at', '2026-01-01'))[:10]}</p>
        </div>
        """,
        unsafe_allow_html=True,
    )

    c1, c2 = st.columns(2)
    with c1:
        st.subheader("Personal Information")
        with st.form("fm_profile_info_form"):
            fn = st.text_input("Full Name", value=u.get("full_name") or "")
            ph = st.text_input("Phone Number", value=u.get("phone") or "")
            addr = st.text_area("Delivery / Work Address", value=u.get("address") or "")
            submit_info = st.form_submit_button("Save Profile Info", use_container_width=True)

        if submit_info:
            auth.update_profile(db, user["user_id"], fn, ph, addr)
            # Update session
            st.session_state["fm_user"].update({"full_name": fn, "phone": ph, "address": addr})
            st.success("✅ Profile information updated successfully!")
            st.rerun()

    with c2:
        st.subheader("Security & Password")
        with st.form("fm_change_password_form"):
            old_p = st.text_input("Current Password", type="password")
            new_p = st.text_input("New Password (6+ characters)", type="password")
            confirm_p = st.text_input("Confirm New Password", type="password")
            submit_pw = st.form_submit_button("Change Password", use_container_width=True)

        if submit_pw:
            if not auth.check_login(db, user["username"], old_p):
                st.error("Current password is incorrect.")
            elif len(new_p) < 6:
                st.error("New password must be at least 6 characters long.")
            elif new_p != confirm_p:
                st.error("New passwords do not match.")
            else:
                auth.set_password(db, user["user_id"], new_p)
                st.success("✅ Password changed successfully!")
