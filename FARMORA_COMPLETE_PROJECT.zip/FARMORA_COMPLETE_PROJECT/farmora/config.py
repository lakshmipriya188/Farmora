"""Central configuration. Values come from environment variables or a .env file in the project root."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def _load_env_file() -> None:
    path = ROOT / ".env"
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


_load_env_file()


@dataclass
class Settings:
    # Database: "mysql" (project default) or "sqlite" (zero-setup, used by tests)
    db_backend: str = "sqlite"
    db_host: str = "127.0.0.1"
    db_port: int = 3306
    db_user: str = "root"
    db_password: str = ""
    db_name: str = "farmora"
    sqlite_path: str = str(ROOT / "data" / "farmora.db")

    # Ledger: "web3" (real blockchain via Hardhat/Sepolia) or "local" (simulated, development only)
    ledger_backend: str = "local"
    rpc_url: str = "http://127.0.0.1:8545"
    network: str = "localhost"
    deployments_dir: str = str(ROOT / "blockchain" / "deployments")
    local_ledger_path: str = str(ROOT / "data" / "local_ledger.jsonl")
    explorer_tx_url: str = ""  # e.g. https://sepolia.etherscan.io/tx/

    app_base_url: str = "http://localhost:8501"

    @classmethod
    def from_env(cls) -> "Settings":
        e = os.environ.get
        d = cls()
        return cls(
            db_backend=e("DB_BACKEND", d.db_backend).lower(),
            db_host=e("DB_HOST", d.db_host),
            db_port=int(e("DB_PORT", str(d.db_port))),
            db_user=e("DB_USER", d.db_user),
            db_password=e("DB_PASSWORD", d.db_password),
            db_name=e("DB_NAME", d.db_name),
            sqlite_path=e("SQLITE_PATH", d.sqlite_path),
            ledger_backend=e("LEDGER_BACKEND", d.ledger_backend).lower(),
            rpc_url=e("WEB3_RPC_URL", d.rpc_url),
            network=e("WEB3_NETWORK", d.network),
            deployments_dir=e("DEPLOYMENTS_DIR", d.deployments_dir),
            local_ledger_path=e("LOCAL_LEDGER_PATH", d.local_ledger_path),
            explorer_tx_url=e("EXPLORER_TX_URL", d.explorer_tx_url),
            app_base_url=e("APP_BASE_URL", d.app_base_url).rstrip("/"),
        )


def private_keys() -> dict:
    """Optional signing keys (needed on public testnets). Role -> private key."""
    out = {}
    for role in ("admin", "certifier", "farmer", "processor", "distributor", "retailer"):
        value = os.environ.get(f"PK_{role.upper()}", "").strip()
        if value:
            out[role] = value
    return out
