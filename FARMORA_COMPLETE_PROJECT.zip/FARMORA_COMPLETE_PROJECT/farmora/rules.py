"""Business rules shared by the app, the simulated ledger and the tests.

These mirror the checks the Solidity contract enforces on-chain, so users get friendly
errors before a transaction is ever sent.
"""
from __future__ import annotations

ROLES = {"admin": 1, "certifier": 2, "farmer": 3, "processor": 4, "distributor": 5, "retailer": 6}

EVENT_TYPES = {
    "CULTIVATED": 1,
    "HARVESTED": 2,
    "CERTIFIED": 3,
    "PROCESSED": 4,
    "SHIPPED": 5,
    "RECEIVED": 6,
    "SOLD": 7,
    "REVOKED": 8,
}
EVENT_NAMES = {v: k for k, v in EVENT_TYPES.items()}

# Which actor role may record which event.
EVENT_ROLE = {
    1: "farmer",
    2: "farmer",
    3: "certifier",
    4: "processor",
    5: "distributor",
    6: "retailer",
    7: "retailer",
    8: "certifier",
}

REPEATABLE = {EVENT_TYPES["SHIPPED"], EVENT_TYPES["SOLD"]}

# Actor roles stored in the actors table (admin is a platform role, not a supply-chain actor).
ACTOR_ROLES = ("farmer", "processor", "distributor", "retailer", "certifier")


class RuleViolation(Exception):
    """Raised when a supply-chain rule is broken."""


def event_type_id(value) -> int:
    """Accepts 'harvested', 'HARVESTED' or 2 and returns the numeric id."""
    if isinstance(value, int):
        if value not in EVENT_NAMES:
            raise RuleViolation(f"Unknown event type id {value}")
        return value
    key = str(value).strip().upper()
    if key not in EVENT_TYPES:
        raise RuleViolation(f"Unknown event type '{value}'")
    return EVENT_TYPES[key]


def check_event_allowed(event_type: int, last_event: int, certified: bool, revoked: bool) -> None:
    """Raise RuleViolation if the event may not be appended to a batch in this state."""
    if revoked:
        raise RuleViolation("Batch certification has been revoked; no further events can be recorded")
    if event_type == EVENT_TYPES["REVOKED"]:
        if not certified:
            raise RuleViolation("Only a certified batch can be revoked")
        return
    in_order = event_type > last_event or (event_type == last_event and event_type in REPEATABLE)
    if not in_order:
        last = EVENT_NAMES.get(last_event, "none")
        raise RuleViolation(f"Event {EVENT_NAMES[event_type]} cannot follow {last}")
    if event_type >= EVENT_TYPES["PROCESSED"] and not certified:
        raise RuleViolation("Batch must be certified before it can be processed, shipped, received or sold")


def next_allowed_events(last_event: int, certified: bool, revoked: bool) -> list[str]:
    """Event names that may legally be recorded next (used by the UI to guide users)."""
    out = []
    for name, tid in EVENT_TYPES.items():
        try:
            check_event_allowed(tid, last_event, certified, revoked)
            out.append(name)
        except RuleViolation:
            continue
    return out
