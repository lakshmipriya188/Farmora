"""FARMORA storefront: organic grocery quick-commerce shop, weight variants (250g, 500g, 1kg),
multi-item cart keyed by <pid>::<grams>, checkout and blockchain farm-to-shelf trail."""
from __future__ import annotations

from datetime import date, datetime
from pathlib import Path

import pandas as pd
import streamlit as st

WEIGHT_OPTIONS = [250, 500, 1000]  # grams
DEFAULT_WEIGHT = 500
FREE_DELIVERY_ABOVE = 199.0
DELIVERY_FEE = 25.0

STATUS_ICON = {"VERIFIED": "✅", "TAMPERED": "❌", "MISSING_IN_DB": "⚠️", "NOT_ON_CHAIN": "⚠️"}

NAME_EMOJI = {
    "tomato": "🍅", "potato": "🥔", "onion": "🧅", "carrot": "🥕", "spinach": "🥬",
    "banana": "🍌", "mango": "🥭", "guava": "🍈", "apple": "🍎", "milk": "🥛",
    "paneer": "🧀", "ghee": "🧈", "butter": "🧈", "rice": "🍚", "ragi": "🌾",
    "wheat": "🌾", "millet": "🌾", "turmeric": "🟡", "spice": "🌶️", "honey": "🍯",
    "jaggery": "🍯", "coconut": "🥥", "oil": "🫒", "dal": "🫘", "gram": "🫘",
}

NAME_IMAGE = {
    "tomato": "Tomato.png",
    "spinach": "Spinach.png",
    "banana": "Banana.png",
    "mango": "Mango.png",
    "carrot": "Carrot.png",
    "guava": "Guava.png",
    "turmeric": "Turmeric_Powder.png",
    "coconut": "Coconut_Oil.png",
    "oil": "Coconut_Oil.png",
    "rice": "Brown_Rice.png",
    "ragi": "BrownTop_Millets.png",
    "millet": "BrownTop_Millets.png",
    "moong": "Chickpeas.png",
    "gram": "Chickpeas.png",
    "toor": "Toor_Dal.png",
    "ghee": "Butter.png",
    "butter": "Butter.png",
}

CSS = """<style>
.fm-hero {
    background: linear-gradient(135deg, #0f5c3a 0%, #1c8a57 60%, #2f9e44 100%);
    color: #ffffff;
    border-radius: 18px;
    padding: 30px 32px;
    margin-bottom: 20px;
    box-shadow: 0 8px 24px rgba(15, 92, 58, 0.15);
}
.fm-hero h1 { color: #ffffff !important; font-size: 2.1rem; line-height: 1.15; margin: 0 0 10px; font-weight: 800; }
.fm-hero p { max-width: 65ch; opacity: .94; margin: 0 0 14px; font-size: 0.98rem; }
.fm-pill {
    display: inline-block;
    background: #ffc83d;
    color: #3a2a00;
    border-radius: 99px;
    padding: 4px 12px;
    font-weight: 700;
    font-size: .82rem;
    margin-right: 8px;
}
.fm-pill-chain {
    display: inline-block;
    background: rgba(255,255,255,0.22);
    color: #ffffff;
    border: 1px solid rgba(255,255,255,0.4);
    border-radius: 99px;
    padding: 4px 12px;
    font-weight: 600;
    font-size: .82rem;
}
.fm-card-img {
    text-align: center;
    background: #fbf5ee;
    border-radius: 12px;
    padding: 12px;
    min-height: 90px;
    display: flex;
    align-items: center;
    justify-content: center;
}
.fm-price-tag {
    font-weight: 800;
    font-size: 1.15rem;
    color: #0f5c3a;
}
.fm-mrp-tag {
    text-decoration: line-through;
    opacity: 0.6;
    font-size: 0.85rem;
    margin-left: 6px;
}
.fm-badge-off {
    background: #ffe3e3;
    color: #d6336c;
    font-weight: 700;
    font-size: 0.75rem;
    border-radius: 6px;
    padding: 2px 6px;
    display: inline-block;
}
.fm-badge-prov {
    background: #e6fcf5;
    color: #0ca678;
    font-size: 0.78rem;
    border-radius: 6px;
    padding: 2px 6px;
    display: inline-block;
    font-weight: 600;
}
</style>"""


def _emoji(name: str, category: str = "") -> str:
    n = name.lower()
    for k, v in NAME_EMOJI.items():
        if k in n:
            return v
    return "🌿"


def _image_path(name: str) -> str | None:
    n = name.lower()
    for k, filename in NAME_IMAGE.items():
        if k in n:
            img = Path(__file__).resolve().parent.parent / "static" / "images" / "products" / filename
            if img.exists():
                return str(img)
    return None


def price_for(base_price_per_kg: float, grams: int) -> float:
    return round(float(base_price_per_kg) * grams / 1000.0, 2)


# ------------------------------------------------------------------ Catalog
@st.cache_data(ttl=60, show_spinner=False)
def load_catalog(_db, version: int):
    # Retrieve all active products with prices
    rows = _db.query(
        "SELECT p.product_id, p.name, p.category, p.shelf_life_days, "
        "COALESCE(pp.price_per_kg, p.price_per_kg, "
        "(SELECT AVG(s.price_per_kg) FROM sales_daily s WHERE s.product_id = p.product_id), 80.0) AS price_per_kg, "
        "COALESCE(p.mrp_per_kg, p.price_per_kg * 1.15, 95.0) AS mrp_per_kg, "
        "COALESCE(pp.active, p.active, 1) AS active "
        "FROM products p "
        "LEFT JOIN product_prices pp ON pp.product_id = p.product_id "
        "ORDER BY p.category, p.name"
    )
    catalog = []
    for r in rows:
        if not int(r["active"]):
            continue
        # Link latest batch for provenance and verification
        b = _db.one(
            "SELECT b.batch_id, b.farm_location, a.name AS farmer_name FROM batches b "
            "JOIN actors a ON a.actor_id = b.farmer_id WHERE b.product_id = ? AND EXISTS "
            "(SELECT 1 FROM trace_events e WHERE e.batch_id = b.batch_id AND e.event_type IN ('RECEIVED','SOLD')) "
            "ORDER BY b.created_at DESC LIMIT 1",
            (r["product_id"],),
        )
        if b is None:
            b = _db.one(
                "SELECT b.batch_id, b.farm_location, a.name AS farmer_name FROM batches b "
                "JOIN actors a ON a.actor_id = b.farmer_id WHERE b.product_id = ? "
                "ORDER BY b.created_at DESC LIMIT 1",
                (r["product_id"],),
            )
        base_price = round(float(r["price_per_kg"] or 80.0), 2)
        mrp_price = round(float(r["mrp_per_kg"] or base_price * 1.15), 2)
        catalog.append({
            "id": r["product_id"],
            "name": r["name"],
            "category": r["category"],
            "shelf": r["shelf_life_days"],
            "price_per_kg": base_price,
            "mrp_per_kg": mrp_price,
            "batch": b,
            "image": _image_path(r["name"]),
            "emoji": _emoji(r["name"], r["category"]),
        })
    return catalog


# ------------------------------------------------------------------ Blockchain Trail Dialog
def _trail_body(svc, batch_id: str):
    batch, report = svc.get_batch(batch_id), svc.verify_batch(batch_id)
    if not batch:
        st.error(f"Batch '{batch_id}' not found.")
        return
    if report["ok"]:
        st.success("✅ **LEDGER VERIFIED**: Every record and cryptographic hash perfectly matches the blockchain.")
    else:
        st.error("❌ **WARNING**: Cryptographic fingerprint mismatch detected. Record may have been tampered off-chain.")
        for issue in report["issues"]:
            st.write("•", issue)

    c1, c2 = st.columns([3, 1])
    with c1:
        st.markdown(
            f"### {batch['product_name']}\n"
            f"**Batch ID**: `{batch_id}`  \n"
            f"**Farmer**: {batch['farmer_name']} ({batch['farm_location']})  \n"
            f"**Harvest Quantity**: {float(batch['quantity_kg']):,.1f} kg  \n"
            f"**Registered on Ledger**: {str(batch['created_at'])[:10]}  \n"
            f"**Blockchain Tx**: `{str(batch.get('tx_hash') or 'N/A')[:22]}…`"
        )
    with c2:
        try:
            st.image(svc.qr_png(batch_id), caption="Scan on mobile to verify", width=140)
        except Exception:
            st.caption("QR Code ready")

    st.divider()
    st.markdown("#### Complete Supply-Chain Trail")
    status = {e["seq"]: e["status"] for e in report["events"]}
    events = svc.get_events(batch_id)
    if not events:
        st.info("No lifecycle events recorded for this batch yet.")
    for ev in events:
        icon = STATUS_ICON.get(status.get(int(ev["seq"])), "❔")
        st.markdown(
            f"{icon} **{ev['event_type'].title()}** · {ev['actor_name']} (*{ev['actor_role'].title()}*)  \n"
            f"<span style='opacity:.75;font-size:.85rem;'>⏱ {str(ev['event_time'])[:16]} "
            f"· 📍 {ev['location'] or 'N/A'} "
            f"· 📦 {float(ev['quantity_kg'] or 0):g} kg "
            f"· tx: `{str(ev['tx_hash'])[:16]}…`</span>",
            unsafe_allow_html=True,
        )


_dialog = getattr(st, "dialog", None) or getattr(st, "experimental_dialog", None)
if _dialog:
    try:
        open_trail = _dialog("Farm-to-Shelf Blockchain Trail", width="large")(_trail_body)
    except TypeError:
        open_trail = _dialog("Farm-to-Shelf Blockchain Trail")(_trail_body)
else:
    def open_trail(svc, batch_id):
        with st.expander(f"Farm-to-Shelf Blockchain Trail: {batch_id}", expanded=True):
            _trail_body(svc, batch_id)


# ------------------------------------------------------------------ Cart Helpers
def get_cart() -> dict:
    return st.session_state.setdefault("fm_cart", {})


def cart_add(product_id: str, grams: int, delta: int = 1):
    key = f"{product_id}::{grams}"
    cart = get_cart()
    if key in cart:
        cart[key]["qty"] += delta
        if cart[key]["qty"] <= 0:
            del cart[key]
    elif delta > 0:
        cart[key] = {"product_id": product_id, "grams": grams, "qty": delta}


def cart_set(product_id: str, grams: int, qty: int):
    key = f"{product_id}::{grams}"
    cart = get_cart()
    if qty <= 0:
        cart.pop(key, None)
    else:
        cart[key] = {"product_id": product_id, "grams": grams, "qty": qty}


def cart_clear():
    st.session_state["fm_cart"] = {}


# ------------------------------------------------------------------ Atomic Checkout
def place_order(db, user: dict, store_id: str, lines: list[dict], address: str, phone: str, customer_name: str):
    # Check total inventory requirements per product
    product_totals = {}
    for line in lines:
        pid = line["product_id"]
        needed_kg = (line["grams"] / 1000.0) * line["qty"]
        product_totals[pid] = product_totals.get(pid, 0.0) + needed_kg

    for pid, needed_kg in product_totals.items():
        row = db.one("SELECT stock_kg FROM inventory WHERE retailer_id = ? AND product_id = ?", (store_id, pid))
        avail = float(row["stock_kg"]) if row else 0.0
        if avail < needed_kg:
            pname = db.one("SELECT name FROM products WHERE product_id = ?", (pid,))
            name = pname["name"] if pname else pid
            return f"Insufficient stock: only {avail:.1f} kg of {name} available at this store (you requested {needed_kg:.1f} kg).", None

    subtotal = sum(l["line_total"] for l in lines)
    fee = 0.0 if subtotal >= FREE_DELIVERY_ABOVE else DELIVERY_FEE
    grand_total = round(subtotal + fee, 2)
    today = str(date.today())
    now_dt = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cid = f"U{user.get('user_id') or 'GUEST'}"

    # Insert into store_orders
    oid = db.execute(
        "INSERT INTO store_orders (customer_id, user_id, retailer_id, status, payment_mode, payment_status, "
        "total, customer_name, phone, address, order_date, placed_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
        (cid, user.get("user_id"), store_id, "Placed", "COD", "Pending", grand_total,
         customer_name.strip(), phone.strip(), address.strip(), today, now_dt)
    )

    # Insert line items and decrement inventory
    for line in lines:
        qty_kg = round((line["grams"] / 1000.0) * line["qty"], 3)
        db.execute(
            "INSERT INTO store_order_items (order_id, product_id, product_name, selected_weight, qty, qty_kg, unit_price, line_total) "
            "VALUES (?,?,?,?,?,?,?,?)",
            (oid, line["product_id"], line["name"], line["grams"], line["qty"], qty_kg, line["unit_price"], line["line_total"])
        )
        # Record in customer_orders for data science RFM pipeline
        db.execute(
            "INSERT INTO customer_orders (customer_id, order_date, retailer_id, product_id, qty_kg, amount) "
            "VALUES (?,?,?,?,?,?)",
            (cid, today, store_id, line["product_id"], qty_kg, line["line_total"])
        )
        # Deduct stock
        db.execute(
            "UPDATE inventory SET stock_kg = stock_kg - ?, updated_on = ? WHERE retailer_id = ? AND product_id = ?",
            (qty_kg, today, store_id, line["product_id"])
        )

    return None, oid


# ------------------------------------------------------------------ Storefront Renderer
def render_store(svc, refresh, user: dict):
    st.markdown(CSS, unsafe_allow_html=True)
    cat = load_catalog(svc.db, st.session_state.get("data_version", 0))
    if not cat:
        st.info("No organic products currently available in catalog. Click 'Refresh data' or re-seed.")
        return

    by_id = {p["id"]: p for p in cat}
    cart = get_cart()
    cart_count = sum(entry["qty"] for entry in cart.values())

    # Hero Banner
    st.markdown(
        """
        <div class="fm-hero">
            <span class="fm-pill">⚡ 12-Min Quick Delivery</span>
            <span class="fm-pill-chain">⛓ FarmoraTrace Blockchain Verified</span>
            <h1>Organic groceries, straight from the farm to your door.</h1>
            <p>Every product carries an authentic batch trail recorded cryptographically on the blockchain. 
            Click <b>Verify</b> on any product to audit its journey from cultivation to shelf.</p>
        </div>
        """,
        unsafe_allow_html=True,
    )

    tab_shop, tab_basket = st.tabs(["🛍 Browse Store", f"🧺 My Basket ({cart_count} items)"])

    # ------------------------------------------------- Browse Store Tab
    with tab_shop:
        f1, f2 = st.columns([3, 4])
        query = f1.text_input("Search groceries", placeholder="Search tomato, mango, rice, ghee...", label_visibility="collapsed")
        categories = ["All"] + sorted({p["category"] for p in cat})
        selected_cat = f2.radio("Category", categories, horizontal=True, label_visibility="collapsed")

        # Filter products
        filtered = [
            p for p in cat
            if (selected_cat == "All" or p["category"] == selected_cat)
            and (not query.strip() or query.lower() in p["name"].lower() or query.lower() in p["category"].lower())
        ]

        if not filtered:
            st.info("No products found matching your search. Try another query or select 'All'.")

        # Product Grid (4 items per row)
        for i in range(0, len(filtered), 4):
            cols = st.columns(4)
            for col, p in zip(cols, filtered[i:i + 4]):
                with col, st.container(border=True):
                    # Image or Emoji
                    if p["image"]:
                        st.image(p["image"], use_container_width=True)
                    else:
                        st.markdown(f"<div class='fm-card-img'><span style='font-size:3rem;'>{p['emoji']}</span></div>", unsafe_allow_html=True)

                    st.markdown(f"**{p['name']}**")
                    st.caption(f"{p['category']} · Shelf life {p['shelf']} d")

                    # Provenance badge
                    if p["batch"]:
                        st.markdown(
                            f"<span class='fm-badge-prov'>🌱 {p['batch']['farmer_name']}, {p['batch']['farm_location']}</span>",
                            unsafe_allow_html=True,
                        )

                    # Weight Selector Dropdown
                    weight_key = f"wsel_{p['id']}"
                    selected_w = st.selectbox(
                        "Weight",
                        WEIGHT_OPTIONS,
                        index=1,
                        format_func=lambda w: f"{w} g" if w < 1000 else "1 kg",
                        key=weight_key,
                        label_visibility="collapsed",
                    )

                    # Dynamic Price Calculation
                    item_price = price_for(p["price_per_kg"], selected_w)
                    item_mrp = price_for(p["mrp_per_kg"], selected_w)
                    off_pct = round((1 - (item_price / item_mrp)) * 100) if item_mrp > item_price else 0

                    p_html = f"<div style='margin: 6px 0;'><span class='fm-price-tag'>₹{item_price:.0f}</span>"
                    if off_pct > 0:
                        p_html += f"<span class='fm-mrp-tag'>₹{item_mrp:.0f}</span> <span class='fm-badge-off'>{off_pct}% OFF</span>"
                    p_html += "</div>"
                    st.markdown(p_html, unsafe_allow_html=True)

                    # Cart key for this specific product + weight combination
                    ckey = f"{p['id']}::{selected_w}"
                    current_qty = cart.get(ckey, {}).get("qty", 0)

                    # Action buttons: Add/Stepper and Verify
                    b1, b2 = st.columns([3, 2])
                    with b1:
                        if current_qty > 0:
                            s1, s2, s3 = st.columns([1, 1, 1])
                            if s1.button("−", key=f"dec_{ckey}"):
                                cart_add(p["id"], selected_w, -1)
                                st.rerun()
                            s2.markdown(f"<div style='text-align:center;font-weight:700;padding-top:4px;'>{current_qty}</div>", unsafe_allow_html=True)
                            if s3.button("+", key=f"inc_{ckey}"):
                                cart_add(p["id"], selected_w, 1)
                                st.rerun()
                        else:
                            if st.button("Add to cart", key=f"add_{ckey}", use_container_width=True):
                                cart_add(p["id"], selected_w, 1)
                                st.rerun()

                    with b2:
                        if p["batch"] and st.button("🔍 Verify", key=f"ver_{p['id']}"):
                            open_trail(svc, p["batch"]["batch_id"])

    # ------------------------------------------------- Basket / Cart Tab
    with tab_basket:
        if not cart:
            st.info("🛒 Your basket is currently empty. Browse our fresh organic products and add items to your cart!")
            return

        lines = []
        for key, entry in list(cart.items()):
            pid = entry["product_id"]
            if pid not in by_id:
                continue
            p = by_id[pid]
            grams = entry["grams"]
            qty = entry["qty"]
            uprice = price_for(p["price_per_kg"], grams)
            ltotal = round(uprice * qty, 2)
            lines.append({
                "key": key,
                "product_id": pid,
                "name": p["name"],
                "category": p["category"],
                "grams": grams,
                "qty": qty,
                "unit_price": uprice,
                "line_total": ltotal,
                "emoji": p["emoji"],
            })

        c_head, c_clear = st.columns([4, 1])
        c_head.subheader("Selected Items")
        if c_clear.button("🗑 Clear Basket"):
            cart_clear()
            st.rerun()

        for line in lines:
            c_prod, c_stepper, c_total = st.columns([4, 3, 2])
            with c_prod:
                st.markdown(f"**{line['emoji']} {line['name']}** ({line['grams']} g)")
                st.caption(f"₹{line['unit_price']:.0f} each")
            with c_stepper:
                m1, m2, m3 = st.columns([1, 1, 1])
                if m1.button("−", key=f"cart_dec_{line['key']}"):
                    cart_add(line["product_id"], line["grams"], -1)
                    st.rerun()
                m2.markdown(f"<div style='text-align:center;font-weight:700;padding-top:4px;'>{line['qty']}</div>", unsafe_allow_html=True)
                if m3.button("+", key=f"cart_inc_{line['key']}"):
                    cart_add(line["product_id"], line["grams"], 1)
                    st.rerun()
            with c_total:
                st.markdown(f"<div style='text-align:right;font-weight:800;font-size:1.05rem;'>₹{line['line_total']:.0f}</div>", unsafe_allow_html=True)

        subtotal = sum(l["line_total"] for l in lines)
        delivery = 0.0 if subtotal >= FREE_DELIVERY_ABOVE else DELIVERY_FEE
        grand_total = round(subtotal + delivery, 2)

        st.divider()
        b_c1, b_c2 = st.columns(2)
        with b_c1:
            st.markdown(f"**Items Subtotal**: ₹{subtotal:.0f}")
            if delivery == 0.0:
                st.markdown("<span style='color:#0ca678;font-weight:700;'>🎉 Free Delivery (Order above ₹199)</span>", unsafe_allow_html=True)
            else:
                st.markdown(f"**Delivery Charge**: ₹{delivery:.0f} *(Free on orders above ₹199)*")
        with b_c2:
            st.markdown(f"<h3 style='text-align:right; color:#0f5c3a;'>To Pay: ₹{grand_total:.0f}</h3>", unsafe_allow_html=True)

        st.divider()
        st.subheader("Fast Checkout")

        if user.get("role") == "guest":
            st.warning("Please sign in or register a customer account to place an order.")
            return

        stores = svc.db.query("SELECT actor_id, name, location FROM actors WHERE role = 'retailer' ORDER BY name")
        if not stores:
            st.error("No partner stores registered. Please contact support.")
            return

        with st.form("fm_checkout_form"):
            store = st.selectbox("Select Delivering Store", stores, format_func=lambda s: f"{s['name']} ({s['location']})")
            c_name = st.text_input("Customer Name", value=user.get("full_name") or user.get("username") or "")
            c_phone = st.text_input("Contact Phone Number", value=user.get("phone") or "")
            c_addr = st.text_area("Delivery Address", value=user.get("address") or "")

            st.info("💵 **Payment Mode**: Cash on Delivery (COD). Please keep exact cash ready upon delivery.")
            submit_order = st.form_submit_button("Place Order (Cash on Delivery)", use_container_width=True)

        if submit_order:
            if not c_name.strip():
                st.error("Please provide your name.")
            elif sum(ch.isdigit() for ch in c_phone) < 6:
                st.error("Please enter a valid phone number (at least 6 digits).")
            elif len(c_addr.strip()) < 8:
                st.error("Please provide a complete delivery address.")
            else:
                err, oid = place_order(svc.db, user, store["actor_id"], lines, c_addr.strip(), c_phone.strip(), c_name.strip())
                if err:
                    st.error(err)
                else:
                    cart_clear()
                    refresh()
                    st.success(f"🎉 **Order #{oid} Placed Successfully!** Delivery partner dispatched from {store['name']}.")
                    st.balloons()
                    st.info(f"Amount to pay on arrival: ₹{grand_total:.0f}. Track real-time progress under **My orders**.")
