@echo off
setlocal enabledelayedexpansion

title FARMORA - Hardhat Blockchain Launcher

echo =====================================================================
echo    FARMORA - Local Blockchain Node & Smart Contract Deployer
echo =====================================================================
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is not installed or not in PATH.
    echo Please install Node.js 18+ from https://nodejs.org/
    pause
    exit /b 1
)

cd blockchain

if not exist "node_modules" (
    echo [1/3] Installing blockchain dependencies (Hardhat, Ethers, Toolbox)...
    call npm install
) else (
    echo [1/3] Blockchain dependencies found.
)

echo [2/3] Starting local Hardhat blockchain node in background window...
start "FARMORA Hardhat Blockchain Node" cmd /k "npx hardhat node"

echo Waiting 5 seconds for the blockchain node to initialize...
timeout /t 5 /nobreak >nul

echo [3/3] Compiling and deploying FarmoraTrace smart contract to localhost...
call npx hardhat run scripts/deploy.js --network localhost
if %errorlevel% neq 0 (
    echo [ERROR] Contract deployment failed. Please make sure the Hardhat node window is running.
    cd ..
    pause
    exit /b 1
)

cd ..

echo.
echo =====================================================================
echo    FarmoraTrace Smart Contract Deployed Successfully!
echo.
echo    Switching configuration to real blockchain:
echo    Setting LEDGER_BACKEND=web3 in .env
echo.
echo    Re-seeding database against the live blockchain...
python -c "
from pathlib import Path
env_path = Path('.env')
lines = env_path.read_text().splitlines() if env_path.exists() else []
new_lines = []
found = False
for l in lines:
    if l.startswith('LEDGER_BACKEND='):
        new_lines.append('LEDGER_BACKEND=web3')
        found = True
    else:
        new_lines.append(l)
if not found:
    new_lines.append('LEDGER_BACKEND=web3')
env_path.write_text('\n'.join(new_lines))
"
python -m farmora.cli seed --reset

echo =====================================================================
echo    Real Blockchain is Connected and Ready for Demonstration!
echo    You can now run 'run_windows.bat' to launch the FARMORA app.
echo =====================================================================
pause
