// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/**
 * FARMORA - organic food traceability ledger.
 *
 * Stores, for every batch, an ordered trail of supply-chain events.
 * Only a SHA-256 fingerprint of each full record is stored on-chain;
 * the detailed record lives off-chain in MySQL. Anyone can recompute the
 * fingerprint from the database and compare it with the chain to detect tampering.
 */
contract FarmoraTrace {
    // ---------------------------------------------------------------- roles
    enum Role { None, Admin, Certifier, Farmer, Processor, Distributor, Retailer }

    // ---------------------------------------------------------- event types
    // Numbering starts at 1 so that 0 can mean "no event yet".
    enum EventType {
        None,        // 0
        Cultivated,  // 1  farmer
        Harvested,   // 2  farmer
        Certified,   // 3  certifier
        Processed,   // 4  processor
        Shipped,     // 5  distributor (repeatable: several transport legs)
        Received,    // 6  retailer
        Sold,        // 7  retailer    (repeatable: several sales records)
        Revoked      // 8  certifier   (certificate withdrawn, batch frozen)
    }

    struct Batch {
        address creator;
        uint64 createdAt;
        bytes32 dataHash;
        bool exists;
        bool certified;
        bool revoked;
        uint8 lastEvent;
    }

    struct TraceRecord {
        EventType eventType;
        address actor;
        uint64 timestamp;
        bytes32 dataHash;
    }

    mapping(address => uint8) private roleMask;
    mapping(string => Batch) private batches;
    mapping(string => TraceRecord[]) private trail;

    uint256 public totalBatches;
    uint256 public totalEvents;

    event RoleGranted(address indexed account, Role role);
    event RoleRevoked(address indexed account, Role role);
    event BatchRegistered(string batchId, address indexed creator, bytes32 dataHash);
    event TraceEventAdded(string batchId, EventType eventType, address indexed actor, uint256 index, bytes32 dataHash);

    constructor() {
        roleMask[msg.sender] = _bit(Role.Admin);
        emit RoleGranted(msg.sender, Role.Admin);
    }

    // ------------------------------------------------------------ access control
    function _bit(Role r) internal pure returns (uint8) {
        return uint8(1) << uint8(r);
    }

    function hasRole(address account, Role r) public view returns (bool) {
        return (roleMask[account] & _bit(r)) != 0;
    }

    modifier onlyRole(Role r) {
        require(hasRole(msg.sender, r), "FarmoraTrace: missing role");
        _;
    }

    function grantRole(address account, Role r) external onlyRole(Role.Admin) {
        require(r != Role.None, "FarmoraTrace: invalid role");
        roleMask[account] = roleMask[account] | _bit(r);
        emit RoleGranted(account, r);
    }

    function revokeRole(address account, Role r) external onlyRole(Role.Admin) {
        require(r != Role.None, "FarmoraTrace: invalid role");
        roleMask[account] = roleMask[account] & ~_bit(r);
        emit RoleRevoked(account, r);
    }

    function _requiredRole(EventType t) internal pure returns (Role) {
        if (t == EventType.Cultivated || t == EventType.Harvested) return Role.Farmer;
        if (t == EventType.Certified || t == EventType.Revoked) return Role.Certifier;
        if (t == EventType.Processed) return Role.Processor;
        if (t == EventType.Shipped) return Role.Distributor;
        if (t == EventType.Received || t == EventType.Sold) return Role.Retailer;
        revert("FarmoraTrace: invalid event type");
    }

    // ------------------------------------------------------------ writes
    function registerBatch(string calldata batchId, bytes32 dataHash) external onlyRole(Role.Farmer) {
        require(bytes(batchId).length > 0 && bytes(batchId).length <= 64, "FarmoraTrace: bad batch id");
        require(!batches[batchId].exists, "FarmoraTrace: batch exists");
        batches[batchId] = Batch({
            creator: msg.sender,
            createdAt: uint64(block.timestamp),
            dataHash: dataHash,
            exists: true,
            certified: false,
            revoked: false,
            lastEvent: 0
        });
        totalBatches += 1;
        emit BatchRegistered(batchId, msg.sender, dataHash);
    }

    function addEvent(string calldata batchId, EventType eventType, bytes32 dataHash) external {
        Batch storage b = batches[batchId];
        require(b.exists, "FarmoraTrace: batch not found");
        require(!b.revoked, "FarmoraTrace: batch revoked");
        require(hasRole(msg.sender, _requiredRole(eventType)), "FarmoraTrace: missing role for event");

        if (eventType == EventType.Revoked) {
            require(b.certified, "FarmoraTrace: batch not certified");
            b.revoked = true;
        } else {
            uint8 t = uint8(eventType);
            bool repeatable = (eventType == EventType.Shipped || eventType == EventType.Sold);
            require(t > b.lastEvent || (t == b.lastEvent && repeatable), "FarmoraTrace: invalid event order");
            if (eventType == EventType.Certified) {
                b.certified = true;
            }
            // Processing, shipping, receiving and selling are only allowed for certified batches.
            if (t >= uint8(EventType.Processed)) {
                require(b.certified, "FarmoraTrace: certification required");
            }
            b.lastEvent = t;
        }

        trail[batchId].push(TraceRecord(eventType, msg.sender, uint64(block.timestamp), dataHash));
        totalEvents += 1;
        emit TraceEventAdded(batchId, eventType, msg.sender, trail[batchId].length - 1, dataHash);
    }

    // ------------------------------------------------------------ reads
    function getBatch(string calldata batchId)
        external
        view
        returns (
            bool exists,
            address creator,
            uint64 createdAt,
            bytes32 dataHash,
            bool certified,
            bool revoked,
            uint32 eventCount
        )
    {
        Batch storage b = batches[batchId];
        return (b.exists, b.creator, b.createdAt, b.dataHash, b.certified, b.revoked, uint32(trail[batchId].length));
    }

    function getEvent(string calldata batchId, uint256 index)
        external
        view
        returns (uint8 eventType, address actor, uint64 timestamp, bytes32 dataHash)
    {
        require(index < trail[batchId].length, "FarmoraTrace: index out of range");
        TraceRecord storage r = trail[batchId][index];
        return (uint8(r.eventType), r.actor, r.timestamp, r.dataHash);
    }
}
