// Deploys FarmoraTrace, grants roles and writes deployments/<network>.json for the Python app.
const hre = require("hardhat");
const fs = require("fs");
const path = require("path");

// Must match the Role enum order in the contract.
const ROLE_IDS = { admin: 1, certifier: 2, farmer: 3, processor: 4, distributor: 5, retailer: 6 };

async function main() {
  const { ethers, network, artifacts } = hre;
  const signers = await ethers.getSigners();
  const admin = signers[0];

  const Trace = await ethers.getContractFactory("FarmoraTrace");
  const trace = await Trace.deploy();
  await trace.waitForDeployment();
  const address = await trace.getAddress();
  console.log(`FarmoraTrace deployed to ${address} on ${network.name}`);

  // Decide which address plays which role.
  const roleAddresses = { admin: admin.address };
  const names = ["certifier", "farmer", "processor", "distributor", "retailer"];
  if (network.name === "sepolia") {
    // One funded key is enough: the admin account receives every role.
    // If you set PK_<ROLE> variables, those accounts are used for the roles instead.
    for (const r of names) {
      const pk = process.env["PK_" + r.toUpperCase()];
      roleAddresses[r] = pk ? new ethers.Wallet(pk).address : admin.address;
    }
  } else {
    // Local Hardhat node: use accounts #1..#5, one per role (realistic multi-party demo).
    names.forEach((r, i) => (roleAddresses[r] = signers[i + 1].address));
  }

  const granted = new Set();
  for (const r of names) {
    const key = `${roleAddresses[r]}:${r}`;
    if (granted.has(key)) continue;
    granted.add(key);
    const tx = await trace.grantRole(roleAddresses[r], ROLE_IDS[r]);
    await tx.wait();
    console.log(`  granted ${r} -> ${roleAddresses[r]}`);
  }

  const artifact = await artifacts.readArtifact("FarmoraTrace");
  const block = await ethers.provider.getBlockNumber();
  const out = {
    network: network.name,
    address,
    deployer: admin.address,
    blockNumber: block,
    roleAddresses,
    abi: artifact.abi,
  };
  const dir = path.join(__dirname, "..", "deployments");
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, `${network.name}.json`);
  fs.writeFileSync(file, JSON.stringify(out, null, 2));
  console.log(`Saved ${file}`);
}

main().catch((e) => {
  console.error(e);
  process.exitCode = 1;
});
