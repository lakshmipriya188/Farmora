const { expect } = require("chai");
const { ethers } = require("hardhat");

// Role and event-type numbers must match the contract enums.
const Role = { Admin: 1, Certifier: 2, Farmer: 3, Processor: 4, Distributor: 5, Retailer: 6 };
const Ev = { Cultivated: 1, Harvested: 2, Certified: 3, Processed: 4, Shipped: 5, Received: 6, Sold: 7, Revoked: 8 };
const H = (n) => ethers.zeroPadValue(ethers.toBeHex(n), 32); // fake 32-byte hash

describe("FarmoraTrace", function () {
  let c, admin, certifier, farmer, processor, distributor, retailer, stranger;

  beforeEach(async function () {
    [admin, certifier, farmer, processor, distributor, retailer, stranger] = await ethers.getSigners();
    const F = await ethers.getContractFactory("FarmoraTrace");
    c = await F.deploy();
    await c.waitForDeployment();
    await c.grantRole(certifier.address, Role.Certifier);
    await c.grantRole(farmer.address, Role.Farmer);
    await c.grantRole(processor.address, Role.Processor);
    await c.grantRole(distributor.address, Role.Distributor);
    await c.grantRole(retailer.address, Role.Retailer);
  });

  async function fullFlowUntil(batchId, lastEvent) {
    await c.connect(farmer).registerBatch(batchId, H(1));
    const steps = [
      [farmer, Ev.Cultivated], [farmer, Ev.Harvested], [certifier, Ev.Certified],
      [processor, Ev.Processed], [distributor, Ev.Shipped], [retailer, Ev.Received], [retailer, Ev.Sold],
    ];
    for (const [who, ev] of steps) {
      if (ev > lastEvent) break;
      await c.connect(who).addEvent(batchId, ev, H(100 + ev));
    }
  }

  describe("roles", function () {
    it("deployer is admin", async function () {
      expect(await c.hasRole(admin.address, Role.Admin)).to.equal(true);
      expect(await c.hasRole(stranger.address, Role.Admin)).to.equal(false);
    });
    it("only admin can grant or revoke", async function () {
      await expect(c.connect(stranger).grantRole(stranger.address, Role.Farmer)).to.be.revertedWith("FarmoraTrace: missing role");
      await c.revokeRole(farmer.address, Role.Farmer);
      expect(await c.hasRole(farmer.address, Role.Farmer)).to.equal(false);
    });
    it("one address can hold several roles", async function () {
      await c.grantRole(admin.address, Role.Farmer);
      await c.grantRole(admin.address, Role.Certifier);
      expect(await c.hasRole(admin.address, Role.Farmer)).to.equal(true);
      expect(await c.hasRole(admin.address, Role.Certifier)).to.equal(true);
    });
  });

  describe("batches", function () {
    it("farmer registers a batch and the hash is stored", async function () {
      await c.connect(farmer).registerBatch("B1", H(7));
      const b = await c.getBatch("B1");
      expect(b.exists).to.equal(true);
      expect(b.creator).to.equal(farmer.address);
      expect(b.dataHash).to.equal(H(7));
      expect(b.eventCount).to.equal(0n);
      expect(await c.totalBatches()).to.equal(1n);
    });
    it("rejects duplicates, empty ids and non-farmers", async function () {
      await c.connect(farmer).registerBatch("B1", H(7));
      await expect(c.connect(farmer).registerBatch("B1", H(8))).to.be.revertedWith("FarmoraTrace: batch exists");
      await expect(c.connect(farmer).registerBatch("", H(8))).to.be.revertedWith("FarmoraTrace: bad batch id");
      await expect(c.connect(retailer).registerBatch("B2", H(8))).to.be.revertedWith("FarmoraTrace: missing role");
    });
    it("unknown batch reports exists=false", async function () {
      expect((await c.getBatch("nope")).exists).to.equal(false);
    });
  });

  describe("events", function () {
    it("records the full lifecycle in order", async function () {
      await fullFlowUntil("B1", Ev.Sold);
      const b = await c.getBatch("B1");
      expect(b.eventCount).to.equal(7n);
      expect(b.certified).to.equal(true);
      const e2 = await c.getFunction("getEvent")("B1", 2);
      expect(e2.eventType).to.equal(Ev.Certified);
      expect(e2.actor).to.equal(certifier.address);
      expect(e2.dataHash).to.equal(H(100 + Ev.Certified));
      expect(await c.totalEvents()).to.equal(7n);
    });
    it("enforces the role for each event type", async function () {
      await c.connect(farmer).registerBatch("B1", H(1));
      await expect(c.connect(retailer).addEvent("B1", Ev.Harvested, H(2))).to.be.revertedWith("FarmoraTrace: missing role for event");
      await expect(c.connect(stranger).addEvent("B1", Ev.Cultivated, H(2))).to.be.revertedWith("FarmoraTrace: missing role for event");
    });
    it("enforces event order", async function () {
      await fullFlowUntil("B1", Ev.Harvested);
      await expect(c.connect(farmer).addEvent("B1", Ev.Cultivated, H(5))).to.be.revertedWith("FarmoraTrace: invalid event order");
      await expect(c.connect(farmer).addEvent("B1", Ev.Harvested, H(5))).to.be.revertedWith("FarmoraTrace: invalid event order");
    });
    it("requires certification before processing, shipping, receiving or selling", async function () {
      await fullFlowUntil("B1", Ev.Harvested);
      await expect(c.connect(processor).addEvent("B1", Ev.Processed, H(5))).to.be.revertedWith("FarmoraTrace: certification required");
      await expect(c.connect(distributor).addEvent("B1", Ev.Shipped, H(5))).to.be.revertedWith("FarmoraTrace: certification required");
      await expect(c.connect(retailer).addEvent("B1", Ev.Received, H(5))).to.be.revertedWith("FarmoraTrace: certification required");
      await expect(c.connect(retailer).addEvent("B1", Ev.Sold, H(5))).to.be.revertedWith("FarmoraTrace: certification required");
    });
    it("allows repeated Shipped and Sold events only", async function () {
      await fullFlowUntil("B1", Ev.Shipped);
      await c.connect(distributor).addEvent("B1", Ev.Shipped, H(50));
      await c.connect(retailer).addEvent("B1", Ev.Received, H(51));
      await c.connect(retailer).addEvent("B1", Ev.Sold, H(52));
      await c.connect(retailer).addEvent("B1", Ev.Sold, H(53));
      await expect(c.connect(retailer).addEvent("B1", Ev.Received, H(54))).to.be.revertedWith("FarmoraTrace: invalid event order");
    });
    it("rejects events for unknown batches", async function () {
      await expect(c.connect(farmer).addEvent("zzz", Ev.Cultivated, H(1))).to.be.revertedWith("FarmoraTrace: batch not found");
    });
    it("rejects an out-of-range event index", async function () {
      await fullFlowUntil("B1", Ev.Cultivated);
      await expect(c.getFunction("getEvent")("B1", 5)).to.be.revertedWith("FarmoraTrace: index out of range");
    });
  });

  describe("revocation", function () {
    it("certifier can revoke a certified batch and it freezes the batch", async function () {
      await fullFlowUntil("B1", Ev.Received);
      await c.connect(certifier).addEvent("B1", Ev.Revoked, H(77));
      const b = await c.getBatch("B1");
      expect(b.revoked).to.equal(true);
      await expect(c.connect(retailer).addEvent("B1", Ev.Sold, H(78))).to.be.revertedWith("FarmoraTrace: batch revoked");
    });
    it("cannot revoke an uncertified batch", async function () {
      await fullFlowUntil("B1", Ev.Harvested);
      await expect(c.connect(certifier).addEvent("B1", Ev.Revoked, H(77))).to.be.revertedWith("FarmoraTrace: batch not certified");
    });
    it("only a certifier can revoke", async function () {
      await fullFlowUntil("B1", Ev.Certified);
      await expect(c.connect(farmer).addEvent("B1", Ev.Revoked, H(77))).to.be.revertedWith("FarmoraTrace: missing role for event");
    });
  });

  it("emits events for the dashboard", async function () {
    await expect(c.connect(farmer).registerBatch("B1", H(1))).to.emit(c, "BatchRegistered");
    await expect(c.connect(farmer).addEvent("B1", Ev.Cultivated, H(2))).to.emit(c, "TraceEventAdded");
  });
});
