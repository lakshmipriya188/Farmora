require("@nomicfoundation/hardhat-toolbox");
require("dotenv").config({ path: "../.env" });

// Private keys are only needed for public testnets (Sepolia). Local development uses
// the funded accounts that "npx hardhat node" provides.
const ROLE_KEYS = ["PK_ADMIN", "PK_CERTIFIER", "PK_FARMER", "PK_PROCESSOR", "PK_DISTRIBUTOR", "PK_RETAILER"];
const sepoliaAccounts = [...new Set(ROLE_KEYS.map((k) => process.env[k]).filter(Boolean))];

/** @type import('hardhat/config').HardhatUserConfig */
module.exports = {
  solidity: {
    version: "0.8.24",
    settings: {
      optimizer: { enabled: true, runs: 200 },
      viaIR: true,
    },
  },
  networks: {
    localhost: { url: "http://127.0.0.1:8545" },
    sepolia: {
      url: process.env.WEB3_RPC_URL || "",
      accounts: sepoliaAccounts,
    },
  },
};
